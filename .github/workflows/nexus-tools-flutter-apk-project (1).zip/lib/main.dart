import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'models/crosshair_config.dart';
import 'models/macro_config.dart';
import 'models/rog_overlay_config.dart';
import 'screens/game_space_screen.dart';
import 'screens/macro_screen.dart';
import 'screens/crosshair_screen.dart';
import 'widgets/crosshair_painter.dart';
import 'widgets/floating_macro_button.dart';
import 'widgets/rog_telemetry_hud.dart';
import 'services/overlay_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.landscapeLeft,
    DeviceOrientation.landscapeRight,
    DeviceOrientation.portraitUp,
  ]);
  runApp(const NexusToolsFlutterApp());
}

class NexusToolsFlutterApp extends StatelessWidget {
  const NexusToolsFlutterApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Nexus Tools - Free Fire Gaming Overlay',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF07090E),
        primaryColor: const Color(0xFFEF4444),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFFEF4444),
          secondary: Colors.cyanAccent,
        ),
      ),
      home: const MainGamingShell(),
    );
  }
}

class MainGamingShell extends StatefulWidget {
  const MainGamingShell({Key? key}) : super(key: key);

  @override
  State<MainGamingShell> createState() => _MainGamingShellState();
}

class _MainGamingShellState extends State<MainGamingShell> {
  final CrosshairConfig _crosshairConfig = CrosshairConfig(
    style: CrosshairStyle.gapCross,
    color: const Color(0xFF00E5FF),
    size: 28.0,
    thickness: 2.0,
    gap: 6.0,
  );

  final MacroConfig _macroConfig = MacroConfig(
    enabled: true,
    buttonSize: 56.0,
    speedMs: 15,
    comboType: MacroComboType.glooWall,
    posX: 25.0,
    posY: 220.0,
  );

  final RogOverlayConfig _rogConfig = RogOverlayConfig(
    enabled: true,
    mode: RogOverlayMode.compactBar,
    posX: 20.0,
    posY: 50.0,
  );

  bool _isFloatingOverlayActive = true;

  @override
  void initState() {
    super.initState();
    _initOverlay();
  }

  void _initOverlay() async {
    final hasPerm = await OverlayService.isPermissionGranted();
    if (!hasPerm) {
      // Prompt on device
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // 1. Core Gaming Hub / Game Space
          GameSpaceScreen(
            crosshairConfig: _crosshairConfig,
            macroConfig: _macroConfig,
            rogConfig: _rogConfig,
            onUpdateCrosshair: (cfg) => setState(() {}),
            onUpdateMacro: (cfg) => setState(() {}),
            onUpdateRog: (cfg) => setState(() {}),
          ),

          // 2. Floating ROG Armoury Crate Telemetry Overlay HUD
          if (_rogConfig.enabled)
            RogTelemetryHud(
              config: _rogConfig,
              onUpdateConfig: (cfg) => setState(() {}),
              onFlushRam: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('RAM Dibersihkan: 1.4 GB siap untuk Free Fire!'),
                    backgroundColor: Color(0xFF10B981),
                  ),
                );
              },
            ),

          // 3. Floating In-Game Crosshair Reticle (Center Screen)
          if (_isFloatingOverlayActive)
            Center(
              child: IgnorePointer(
                child: CustomPaint(
                  size: Size(_crosshairConfig.size, _crosshairConfig.size),
                  painter: CrosshairPainter(config: _crosshairConfig),
                ),
              ),
            ),

          // 4. Floating Draggable Macro Button with Configurable Size & Speed
          if (_macroConfig.enabled)
            FloatingMacroButton(
              config: _macroConfig,
              onUpdateConfig: (cfg) => setState(() {}),
              onOpenSettings: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => MacroScreen(
                      config: _macroConfig,
                      onUpdate: (cfg) => setState(() {}),
                    ),
                  ),
                );
              },
            ),
        ],
      ),
    );
  }
}
