import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/crosshair_config.dart';

class OverlayService {
  static const String _prefCrosshairKey = 'nexus_crosshair_config';
  static const String _prefOverlayActive = 'nexus_overlay_active';

  /// Request SYSTEM_ALERT_WINDOW permission
  static Future<bool> requestOverlayPermission() async {
    final status = await FlutterOverlayWindow.isPermissionGranted();
    if (!status) {
      final granted = await FlutterOverlayWindow.requestPermission();
      return granted ?? false;
    }
    return true;
  }

  /// Check if overlay permission is granted
  static Future<bool> isPermissionGranted() async {
    return await FlutterOverlayWindow.isPermissionGranted();
  }

  /// Show the floating gaming overlay over games
  static Future<void> showOverlay({
    int width = WindowSize.fullCover,
    int height = WindowSize.fullCover,
  }) async {
    final granted = await isPermissionGranted();
    if (!granted) {
      await requestOverlayPermission();
    }

    if (await FlutterOverlayWindow.isActive()) {
      return;
    }

    await FlutterOverlayWindow.showOverlay(
      enableDrag: false,
      overlayTitle: "Nexus Gaming Overlay",
      overlayContent: "Running in background for Free Fire",
      flag: OverlayFlag.defaultFlag,
      visibility: NotificationVisibility.visibilitySecret,
      positionGravity: PositionGravity.auto,
      height: height,
      width: width,
    );

    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_prefOverlayActive, true);
  }

  /// Close the overlay
  static Future<void> closeOverlay() async {
    if (await FlutterOverlayWindow.isActive()) {
      await FlutterOverlayWindow.closeOverlay();
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_prefOverlayActive, false);
  }

  /// Save crosshair configuration
  static Future<void> saveCrosshairConfig(CrosshairConfig config) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_prefCrosshairKey, jsonEncode(config.toJson()));
  }

  /// Load crosshair configuration
  static Future<CrosshairConfig> loadCrosshairConfig() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getString(_prefCrosshairKey);
    if (data != null) {
      try {
        return CrosshairConfig.fromJson(jsonDecode(data));
      } catch (_) {}
    }
    return CrosshairConfig();
  }
}
