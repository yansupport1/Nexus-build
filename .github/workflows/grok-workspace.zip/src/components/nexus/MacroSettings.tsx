import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { useNexus } from "@/lib/nexus/store";
import { MACRO_COMBOS } from "@/lib/nexus/types";
import { X, Zap } from "lucide-react";
import { useRef } from "react";

export function MacroSettings() {
  const open = useNexus((s) => s.macroOpen);
  const cfg = useNexus((s) => s.macro);
  const patch = useNexus((s) => s.patchMacro);
  const close = useNexus((s) => s.setMacroOpen);
  const firing = useNexus((s) => s.firing);
  const clicks = useNexus((s) => s.clicksThisHold);
  const startFire = useNexus((s) => s.startFire);
  const stopFire = useNexus((s) => s.stopFire);
  const holdRef = useRef<HTMLButtonElement>(null);

  if (!open) return null;

  return (
    <div className="nexus-sheet fixed inset-0 flex items-end justify-center bg-bg/80 sm:items-center sm:p-4">
      <div className="flex max-h-[92dvh] w-full max-w-lg flex-col rounded-t-[var(--radius-xl)] bg-surface shadow-[var(--shadow-border)] sm:rounded-[var(--radius-xl)]">
        <div className="flex items-center justify-between px-5 pt-5">
          <div>
            <p className="font-mono text-[11px] tracking-[0.16em] text-cyan uppercase">Makro overlay</p>
            <h2 className="font-display text-xl font-semibold text-fg">Hold to fire</h2>
          </div>
          <Button variant="ghost" size="icon" aria-label="Tutup" onClick={() => close(false)}>
            <X />
          </Button>
        </div>

        <div className="min-h-0 flex-1 overflow-y-auto px-5 py-4">
          <div className="mb-4 rounded-[var(--radius-lg)] bg-elevated p-4 shadow-[var(--shadow-border)]">
            <p className="text-sm font-medium text-fg">Tombol ditahan = klik beruntun</p>
            <p className="mt-1 text-xs text-muted text-pretty">
              Setiap tick menembak di arena sesuai delay. Lepas tombol, tembakan
              berhenti. Tidak menyentuh data pertandingan di luar NEXUS.
            </p>
          </div>

          <div className="mb-3 flex items-center justify-between text-sm">
            <span className="text-muted">Ukuran tombol</span>
            <span className="font-mono tabular-nums text-cyan">{Math.round(cfg.buttonSize)} px</span>
          </div>
          <Slider
            label="Ukuran tombol"
            min={40}
            max={96}
            value={cfg.buttonSize}
            onChange={(v) => patch({ buttonSize: v })}
          />

          <div className="my-4 flex justify-center">
            <div
              className="flex items-center justify-center rounded-full bg-cyan text-bg shadow-[var(--shadow-border)]"
              style={{ width: cfg.buttonSize, height: cfg.buttonSize }}
            >
              <Zap style={{ width: cfg.buttonSize * 0.42, height: cfg.buttonSize * 0.42 }} />
            </div>
          </div>

          <div className="mb-3 flex items-center justify-between text-sm">
            <span className="text-muted">Delay klik</span>
            <span className="font-mono tabular-nums text-cyan">{cfg.speedMs} ms</span>
          </div>
          <Slider
            label="Delay makro"
            min={5}
            max={150}
            step={5}
            value={cfg.speedMs}
            onChange={(v) => patch({ speedMs: v })}
          />
          <div className="mt-2 mb-4 grid grid-cols-4 gap-2">
            {[5, 15, 30, 60].map((ms) => (
              <button
                key={ms}
                type="button"
                onClick={() => patch({ speedMs: ms })}
                className="h-9 rounded-[var(--radius-sm)] font-mono text-xs shadow-[var(--shadow-border)]"
                style={{
                  background: cfg.speedMs === ms ? "var(--color-cyan)" : "var(--color-elevated)",
                  color: cfg.speedMs === ms ? "var(--color-bg)" : "var(--color-fg)",
                }}
              >
                {ms}ms
              </button>
            ))}
          </div>

          <p className="mb-2 font-mono text-[11px] font-medium tracking-[0.14em] text-muted uppercase">
            Preset combo
          </p>
          <div className="space-y-2">
            {MACRO_COMBOS.map((c) => {
              const on = cfg.combo === c.id;
              return (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => patch({ combo: c.id })}
                  className="w-full rounded-[var(--radius-md)] bg-elevated p-3 text-left shadow-[var(--shadow-border)]"
                  style={{
                    boxShadow: on
                      ? "0 0 0 1px color-mix(in oklab, var(--color-cyan) 55%, transparent)"
                      : undefined,
                  }}
                >
                  <p className="text-sm font-medium text-fg">{c.title}</p>
                  <p className="font-mono text-[10px] text-muted">{c.sequence}</p>
                </button>
              );
            })}
          </div>

          <Button
            ref={holdRef}
            variant="cyan"
            className="mt-5 h-14 w-full"
            onPointerDown={(e) => {
              e.preventDefault();
              (e.currentTarget as HTMLButtonElement).setPointerCapture(e.pointerId);
              startFire();
            }}
            onPointerUp={stopFire}
            onPointerCancel={stopFire}
          >
            <Zap />
            {firing ? `MENEMBAK ${clicks} klik` : "TAHAN UNTUK TES MAKRO"}
          </Button>
        </div>
      </div>
    </div>
  );
}
