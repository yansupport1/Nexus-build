package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.model.CrosshairConfig
import com.example.model.CrosshairStyle
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun CrosshairCanvas(
    config: CrosshairConfig,
    modifier: Modifier = Modifier,
    boxSize: Dp = 120.dp
) {
    val crossColor = Color(config.colorHex).copy(alpha = config.alpha)

    Canvas(modifier = modifier.size(boxSize)) {
        val center = Offset(size.width / 2f, size.height / 2f)

        rotate(degrees = config.rotation, pivot = center) {
            drawCrosshairReticle(
                scope = this,
                config = config,
                center = center,
                color = crossColor
            )
        }
    }
}

fun drawCrosshairReticle(
    scope: DrawScope,
    config: CrosshairConfig,
    center: Offset,
    color: Color
) {
    val cX = center.x
    val cY = center.y
    val size = config.size
    val thickness = config.thickness
    val gap = config.gap

    // Outer Ring if enabled
    if (config.hasOuterRing) {
        scope.drawCircle(
            color = color.copy(alpha = (config.alpha * 0.7f)),
            radius = config.ringRadius,
            center = center,
            style = Stroke(width = maxOf(1.5f, thickness * 0.75f))
        )
    }

    // Center Dot if enabled
    if (config.hasCenterDot) {
        scope.drawCircle(
            color = color,
            radius = config.centerDotSize,
            center = center
        )
    }

    when (config.style) {
        CrosshairStyle.DOT -> {
            scope.drawCircle(
                color = color,
                radius = size * 0.35f,
                center = center
            )
        }

        CrosshairStyle.CLASSIC_CROSS -> {
            // 4 solid cross arms from center
            val armLength = size
            // Horizontal
            scope.drawLine(color, Offset(cX - armLength, cY), Offset(cX + armLength, cY), strokeWidth = thickness)
            // Vertical
            scope.drawLine(color, Offset(cX, cY - armLength), Offset(cX, cY + armLength), strokeWidth = thickness)
        }

        CrosshairStyle.GAP_CROSS -> {
            // Competitive gap cross (4 separated lines)
            val armLength = size
            // Left
            scope.drawLine(color, Offset(cX - gap - armLength, cY), Offset(cX - gap, cY), strokeWidth = thickness)
            // Right
            scope.drawLine(color, Offset(cX + gap, cY), Offset(cX + gap + armLength, cY), strokeWidth = thickness)
            // Top
            scope.drawLine(color, Offset(cX, cY - gap - armLength), Offset(cX, cY - gap), strokeWidth = thickness)
            // Bottom
            scope.drawLine(color, Offset(cX, cY + gap), Offset(cX, cY + gap + armLength), strokeWidth = thickness)
        }

        CrosshairStyle.CIRCLE_DOT -> {
            // Shotgun ring + 4 small tick marks
            scope.drawCircle(color, radius = size * 0.7f, center = center, style = Stroke(width = thickness))
            scope.drawCircle(color, radius = maxOf(2f, thickness * 0.9f), center = center)
            // 4 micro ticks
            val tick = size * 0.25f
            val r = size * 0.7f
            scope.drawLine(color, Offset(cX - r - tick, cY), Offset(cX - r, cY), strokeWidth = thickness)
            scope.drawLine(color, Offset(cX + r, cY), Offset(cX + r + tick, cY), strokeWidth = thickness)
            scope.drawLine(color, Offset(cX, cY - r - tick), Offset(cX, cY - r), strokeWidth = thickness)
            scope.drawLine(color, Offset(cX, cY + r), Offset(cX, cY + r + tick), strokeWidth = thickness)
        }

        CrosshairStyle.SHOTGUN_RING -> {
            // Free Fire shotgun ring
            scope.drawCircle(color, radius = size, center = center, style = Stroke(width = thickness))
            scope.drawCircle(color, radius = size * 0.45f, center = center, style = Stroke(width = thickness * 0.8f))
            scope.drawCircle(color, radius = maxOf(2f, thickness * 0.8f), center = center)
        }

        CrosshairStyle.HOLLOW_DIAMOND -> {
            val path = Path().apply {
                moveTo(cX, cY - size)
                lineTo(cX + size, cY)
                lineTo(cX, cY + size)
                lineTo(cX - size, cY)
                close()
            }
            scope.drawPath(path, color, style = Stroke(width = thickness))
        }

        CrosshairStyle.CHEVRON_SNIPER -> {
            // AWM sniper chevron arrow ^
            val path = Path().apply {
                moveTo(cX - size * 0.8f, cY + size * 0.5f)
                lineTo(cX, cY - size * 0.6f)
                lineTo(cX + size * 0.8f, cY + size * 0.5f)
            }
            scope.drawPath(path, color, style = Stroke(width = thickness))
            // Horizon line
            scope.drawLine(color, Offset(cX - size * 1.2f, cY), Offset(cX - size * 0.4f, cY), strokeWidth = thickness * 0.7f)
            scope.drawLine(color, Offset(cX + size * 0.4f, cY), Offset(cX + size * 1.2f, cY), strokeWidth = thickness * 0.7f)
        }

        CrosshairStyle.TRIANGLE_AIM -> {
            val path = Path().apply {
                moveTo(cX, cY - size)
                lineTo(cX + size * 0.866f, cY + size * 0.5f)
                lineTo(cX - size * 0.866f, cY + size * 0.5f)
                close()
            }
            scope.drawPath(path, color, style = Stroke(width = thickness))
        }

        CrosshairStyle.T_SHAPE -> {
            // Headshot meta: no top prong so head is clearly visible!
            val armLength = size
            // Left
            scope.drawLine(color, Offset(cX - gap - armLength, cY), Offset(cX - gap, cY), strokeWidth = thickness)
            // Right
            scope.drawLine(color, Offset(cX + gap, cY), Offset(cX + gap + armLength, cY), strokeWidth = thickness)
            // Bottom only
            scope.drawLine(color, Offset(cX, cY + gap), Offset(cX, cY + gap + armLength), strokeWidth = thickness)
        }

        CrosshairStyle.PLUS_DOT -> {
            val arm = size * 0.7f
            scope.drawLine(color, Offset(cX - arm, cY), Offset(cX + arm, cY), strokeWidth = thickness)
            scope.drawLine(color, Offset(cX, cY - arm), Offset(cX, cY + arm), strokeWidth = thickness)
            scope.drawCircle(color, radius = thickness * 1.6f, center = center)
        }

        CrosshairStyle.PREDATOR_TRI -> {
            // 3 lines at 120 degrees
            for (i in 0 until 3) {
                val angle = Math.toRadians((i * 120.0) - 90.0)
                val startX = cX + (gap * cos(angle)).toFloat()
                val startY = cY + (gap * sin(angle)).toFloat()
                val endX = cX + ((gap + size) * cos(angle)).toFloat()
                val endY = cY + ((gap + size) * sin(angle)).toFloat()
                scope.drawLine(color, Offset(startX, startY), Offset(endX, endY), strokeWidth = thickness)
            }
        }

        CrosshairStyle.TACTICAL_SCOPE -> {
            scope.drawCircle(color, radius = size, center = center, style = Stroke(width = thickness))
            // Crosshairs extending past circle
            val ext = size * 1.4f
            scope.drawLine(color, Offset(cX - ext, cY), Offset(cX - gap, cY), strokeWidth = thickness * 0.8f)
            scope.drawLine(color, Offset(cX + gap, cY), Offset(cX + ext, cY), strokeWidth = thickness * 0.8f)
            scope.drawLine(color, Offset(cX, cY - ext), Offset(cX, cY - gap), strokeWidth = thickness * 0.8f)
            scope.drawLine(color, Offset(cX, cY + gap), Offset(cX, cY + ext), strokeWidth = thickness * 0.8f)
        }

        CrosshairStyle.SQUARE_BOX -> {
            scope.drawRect(
                color = color,
                topLeft = Offset(cX - size * 0.6f, cY - size * 0.6f),
                size = Size(size * 1.2f, size * 1.2f),
                style = Stroke(width = thickness)
            )
        }

        CrosshairStyle.X_CROSS -> {
            val arm = size * 0.7f
            scope.drawLine(color, Offset(cX - arm, cY - arm), Offset(cX + arm, cY + arm), strokeWidth = thickness)
            scope.drawLine(color, Offset(cX + arm, cY - arm), Offset(cX - arm, cY + arm), strokeWidth = thickness)
        }

        CrosshairStyle.DUAL_CIRCLE -> {
            scope.drawCircle(color, radius = size, center = center, style = Stroke(width = thickness))
            scope.drawCircle(color, radius = size * 0.4f, center = center, style = Stroke(width = thickness))
        }

        CrosshairStyle.HEART_AIM -> {
            val scale = size * 0.05f
            val path = Path().apply {
                moveTo(cX, cY + (10f * scale))
                cubicTo(
                    cX - (20f * scale), cY - (10f * scale),
                    cX - (20f * scale), cY - (30f * scale),
                    cX, cY - (15f * scale)
                )
                cubicTo(
                    cX + (20f * scale), cY - (30f * scale),
                    cX + (20f * scale), cY - (10f * scale),
                    cX, cY + (10f * scale)
                )
            }
            scope.drawPath(path, color, style = Stroke(width = thickness))
        }
    }
}
