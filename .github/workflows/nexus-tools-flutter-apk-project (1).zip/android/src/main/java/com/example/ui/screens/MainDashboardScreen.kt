package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ALL_ENGINEER_TOOLS
import com.example.model.CrosshairConfig
import com.example.model.CrosshairStyle
import com.example.model.EngineerTool
import com.example.model.PRESET_CROSSHAIR_COLORS
import com.example.model.ToolCategory
import com.example.service.OverlayService
import com.example.ui.components.CrosshairCanvas
import com.example.ui.components.CyberCard
import com.example.ui.components.PermissionStatusRow
import com.example.ui.components.StatusBadge
import com.example.ui.theme.CarbonDark
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberRed
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TacticalAmber
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.utils.DpiHelper
import com.example.utils.HardwareMonitor

@Composable
fun MainDashboardScreen() {
    val context = LocalContext.current
    var crosshairConfig by remember { mutableStateOf(OverlayService.activeConfig) }
    var isOverlayRunning by remember { mutableStateOf(OverlayService.isRunning) }
    var hasOverlayPermission by remember { mutableStateOf(Settings.canDrawOverlays(context)) }

    // Screen and Hardware specs
    val screenSpecs = remember { DpiHelper.getScreenSpecs(context) }
    var currentTargetDpi by remember { mutableIntStateOf(screenSpecs.currentDpi) }
    val batteryInfo = remember { HardwareMonitor.getBatteryInfo(context) }

    // Selected Tab
    var selectedTabIndex by remember { mutableIntStateOf(0) }
    val tabs = listOf("DPI ENGINE", "CROSSHAIR", "15+ TOOLS", "PERMISSIONS")

    // Active tool modal
    var activeModalTool by remember { mutableStateOf<EngineerTool?>(null) }

    // Lifecycle observer for ON_RESUME: automatically detect when user grants permissions in settings
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                hasOverlayPermission = Settings.canDrawOverlays(context)
                isOverlayRunning = OverlayService.isRunning
                crosshairConfig = OverlayService.activeConfig
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    // Sync with OverlayService updates
    LaunchedEffect(Unit) {
        OverlayService.onConfigChangedListener = { updated ->
            crosshairConfig = updated
        }
    }

    fun requestOverlayPermission() {
        try {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${context.packageName}")
            )
            context.startActivity(intent)
        } catch (_: Exception) {
            try {
                val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
                context.startActivity(intent)
            } catch (_: Exception) {
                Toast.makeText(context, "Buka Pengaturan HP > Aplikasi > Izin Khusus > Tampilkan di Atas Aplikasi", Toast.LENGTH_LONG).show()
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CarbonDark)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Top Cyber Header
            CyberHeader(
                isOverlayRunning = isOverlayRunning,
                batteryTemp = batteryInfo.temperatureCelsius,
                refreshRate = screenSpecs.refreshRateHz.toInt(),
                onToggleOverlay = {
                    if (!Settings.canDrawOverlays(context)) {
                        Toast.makeText(context, "Berikan izin Tampilkan di Atas Aplikasi Lain terlebih dahulu!", Toast.LENGTH_LONG).show()
                        requestOverlayPermission()
                        return@CyberHeader
                    }

                    if (isOverlayRunning) {
                        val stopIntent = Intent(context, OverlayService::class.java).apply {
                            action = OverlayService.ACTION_STOP
                        }
                        context.stopService(stopIntent)
                        isOverlayRunning = false
                        Toast.makeText(context, "Overlay Service dinonaktifkan", Toast.LENGTH_SHORT).show()
                    } else {
                        val startIntent = Intent(context, OverlayService::class.java).apply {
                            action = OverlayService.ACTION_START
                        }
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            context.startForegroundService(startIntent)
                        } else {
                            context.startService(startIntent)
                        }
                        isOverlayRunning = true
                        Toast.makeText(context, "Overlay Nexus Tools AKTIF! Buka Free Fire sekarang.", Toast.LENGTH_SHORT).show()
                    }
                }
            )

            // Permission Warning Banner if overlay permission is not granted yet
            if (!hasOverlayPermission) {
                CyberCard(
                    backgroundColor = CyberRed.copy(alpha = 0.15f),
                    borderColor = CyberRed
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("IZIN OVERLAY BELUM AKTIF", color = CyberRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text(
                                "Aktifkan 'Tampilkan di atas aplikasi' agar Crosshair & HUD muncul di Free Fire.",
                                color = TextSecondary,
                                fontSize = 10.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = { requestOverlayPermission() },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberRed, contentColor = Color.White),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text("AKTIFKAN", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // 2. Navigation Tabs
            TabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = SurfaceDark,
                contentColor = CyberCyan,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                        color = CyberCyan
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTabIndex == index,
                        onClick = { selectedTabIndex = index },
                        text = {
                            Text(
                                text = title,
                                fontSize = 11.sp,
                                fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTabIndex == index) CyberCyan else TextSecondary
                            )
                        }
                    )
                }
            }

            // 3. Tab Content
            when (selectedTabIndex) {
                0 -> DpiEngineSection(
                    screenSpecs = screenSpecs,
                    currentTargetDpi = currentTargetDpi,
                    onDpiChange = { currentTargetDpi = it }
                )
                1 -> CrosshairStudioSection(
                    config = crosshairConfig,
                    onConfigChange = { newConfig ->
                        crosshairConfig = newConfig
                        OverlayService.updateConfig(newConfig, context)
                    }
                )
                2 -> EngineerToolsSuiteSection(
                    currentDpi = currentTargetDpi,
                    onOpenTool = { activeModalTool = it }
                )
                3 -> PermissionAndDebugSection(
                    hasOverlayPermission = hasOverlayPermission,
                    onGrantOverlay = { requestOverlayPermission() }
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
        }

        // Active Tool Dialog
        activeModalTool?.let { tool ->
            ToolDetailDialog(
                tool = tool,
                currentDpi = currentTargetDpi,
                onDismiss = { activeModalTool = null }
            )
        }
    }
}

@Composable
fun CyberHeader(
    isOverlayRunning: Boolean,
    batteryTemp: Float,
    refreshRate: Int,
    onToggleOverlay: () -> Unit
) {
    CyberCard(
        borderColor = if (isOverlayRunning) CyberCyan else SurfaceBorder,
        backgroundColor = SurfaceDark
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "NEXUS TOOLS",
                            color = CyberCyan,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(CyberRed)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text("PRO FF", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Text(
                        text = "Gaming Engineer & Crosshair Suite for Free Fire / MAX",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }

                StatusBadge(
                    text = if (isOverlayRunning) "OVERLAY ON" else "STANDBY",
                    isActive = isOverlayRunning
                )
            }

            // Quick Info Pill Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuickStatChip(label = "REFRESH", value = "$refreshRate Hz", color = NeonGreen, modifier = Modifier.weight(1f))
                QuickStatChip(label = "SUHU", value = "$batteryTemp°C", color = if (batteryTemp > 40f) CyberRed else TacticalAmber, modifier = Modifier.weight(1f))
                QuickStatChip(label = "LATENSI", value = "24 ms", color = CyberCyan, modifier = Modifier.weight(1f))
            }

            // Primary Toggle Button
            Button(
                onClick = onToggleOverlay,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isOverlayRunning) CyberRed else CyberCyan,
                    contentColor = if (isOverlayRunning) Color.White else CarbonDark
                ),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(
                    imageVector = if (isOverlayRunning) Icons.Default.Stop else Icons.Default.PlayArrow,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isOverlayRunning) "MATIKAN OVERLAY SERVICE" else "AKTIFKAN OVERLAY MENU & CROSSHAIR",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 12.sp,
                    letterSpacing = 0.5.sp
                )
            }
        }
    }
}

@Composable
fun QuickStatChip(label: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(SurfaceElevated)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = label, color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
            Text(text = value, color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun DpiEngineSection(
    screenSpecs: com.example.utils.ScreenSpecs,
    currentTargetDpi: Int,
    onDpiChange: (Int) -> Unit
) {
    val context = LocalContext.current

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        CyberCard {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("DPI ENGINE (OVERLAY)", color = CyberCyan, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Text("Ubah DPI tanpa buka opsi pengembang via Wireless Debug / Shizuku", color = TextSecondary, fontSize = 11.sp)
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(CyberCyan.copy(alpha = 0.15f))
                            .border(1.dp, CyberCyan, RoundedCornerShape(8.dp))
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "$currentTargetDpi DPI",
                            color = CyberCyan,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }

                Text(
                    text = "DPI bawaan HP: ${screenSpecs.currentDpi} DPI | Resolusi: ${screenSpecs.widthPx} x ${screenSpecs.heightPx}",
                    color = TextMuted,
                    fontSize = 11.sp
                )
            }
        }

        // Preset List
        Text("Rekomendasi Preset DPI Free Fire:", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            DpiHelper.FREE_FIRE_PRESETS.forEach { preset ->
                val isSelected = currentTargetDpi == preset.dpi
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isSelected) CyberCyan.copy(alpha = 0.15f) else SurfaceElevated)
                        .border(1.dp, if (isSelected) CyberCyan else SurfaceBorder, RoundedCornerShape(10.dp))
                        .clickable { onDpiChange(preset.dpi) }
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(preset.label, color = if (isSelected) CyberCyan else TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(SurfaceDark)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(preset.tag, color = if (isSelected) CyberCyan else TacticalAmber, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Text(preset.description, color = TextSecondary, fontSize = 11.sp)
                    }

                    if (isSelected) {
                        Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = CyberCyan)
                    }
                }
            }
        }

        // Custom Slider
        CyberCard {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Kustom DPI Manual", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    Text("$currentTargetDpi DPI", color = CyberCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Slider(
                    value = currentTargetDpi.toFloat(),
                    onValueChange = { onDpiChange(it.toInt()) },
                    valueRange = 320f..800f,
                    steps = 48,
                    colors = SliderDefaults.colors(
                        thumbColor = CyberCyan,
                        activeTrackColor = CyberCyan,
                        inactiveTrackColor = SurfaceElevated
                    )
                )
            }
        }

        // ADB / Wireless Debugging Quick Command Box
        CyberCard(backgroundColor = SurfaceElevated) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Perintah Shell ADB / Debug Nirkabel:", color = TacticalAmber, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text(
                    text = DpiHelper.getAdbCommand(currentTargetDpi),
                    color = CyberCyan,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CarbonDark)
                        .padding(10.dp)
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("ADB Command", DpiHelper.getAdbCommand(currentTargetDpi)))
                            Toast.makeText(context, "Perintah ADB berhasil disalin!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = CarbonDark)
                    ) {
                        Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("SALIN PERINTAH", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            onDpiChange(screenSpecs.currentDpi)
                            Toast.makeText(context, "DPI di-reset ke bawaan HP (${screenSpecs.currentDpi})", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = SurfaceDark, contentColor = TextSecondary)
                    ) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("RESET BAWAAN", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun CrosshairStudioSection(
    config: CrosshairConfig,
    onConfigChange: (CrosshairConfig) -> Unit
) {
    var tapCounter by remember { mutableIntStateOf(0) }
    var lastTapMillis by remember { mutableStateOf(0L) }
    val context = LocalContext.current

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // Preview Box with Target & Triple Tap Detector
        CyberCard(borderColor = CyberCyan) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("PRATINJAU RETICLE RETIKEL CROSSHAIR", color = CyberCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)

                // Interactive Crosshair Preview Target Box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF070A0F))
                        .border(1.dp, SurfaceBorder, RoundedCornerShape(12.dp))
                        .clickable {
                            val now = System.currentTimeMillis()
                            if (now - lastTapMillis < 500) {
                                tapCounter++
                            } else {
                                tapCounter = 1
                            }
                            lastTapMillis = now

                            if (tapCounter >= 3) {
                                tapCounter = 0
                                val nextMode = !config.quickSettingMode
                                onConfigChange(config.copy(quickSettingMode = nextMode))
                                Toast.makeText(context, "Mode Setting Cepat Aktif via Tap 3×!", Toast.LENGTH_SHORT).show()
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    // Subtle background cross lines
                    Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF161E2E)))
                    Box(modifier = Modifier.width(1.dp).height(200.dp).background(Color(0xFF161E2E)))

                    CrosshairCanvas(config = config, boxSize = 140.dp)

                    // Triple-Tap Status Tag inside preview
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .padding(top = 8.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .background(if (config.quickSettingMode) CyberCyan.copy(alpha = 0.2f) else CarbonDark.copy(alpha = 0.8f))
                            .border(0.5.dp, if (config.quickSettingMode) CyberCyan else SurfaceBorder, RoundedCornerShape(20.dp))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = if (config.quickSettingMode) "QUICK SETTING MODE AKTIF (Tap 3×)" else "Uji Fitur: Tap Crosshair 3× Cepat",
                            color = if (config.quickSettingMode) CyberCyan else TextSecondary,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                // Quick Mode Mini HUD (when toggled via tap 3x)
                if (config.quickSettingMode) {
                    CyberCard(backgroundColor = SurfaceElevated, borderColor = CyberCyan) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("⚡ MODE SETTING CEPAT OVERLAY", color = CyberCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text(
                                    "TUTUP (✕)",
                                    color = CyberRed,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.clickable {
                                        onConfigChange(config.copy(quickSettingMode = false))
                                    }
                                )
                            }
                            Text("Ukuran Cepat: ${config.size.toInt()}px", color = TextPrimary, fontSize = 11.sp)
                            Slider(
                                value = config.size,
                                onValueChange = { onConfigChange(config.copy(size = it)) },
                                valueRange = 10f..80f,
                                colors = SliderDefaults.colors(thumbColor = CyberCyan, activeTrackColor = CyberCyan)
                            )
                        }
                    }
                }
            }
        }

        // 16 Crosshair Styles Gallery
        Text("Pilih Style Reticle Crosshair (16 Pilihan):", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(CrosshairStyle.values()) { style ->
                val isSelected = config.style == style
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) CyberCyan.copy(alpha = 0.2f) else SurfaceElevated)
                        .border(1.dp, if (isSelected) CyberCyan else SurfaceBorder, RoundedCornerShape(8.dp))
                        .clickable { onConfigChange(config.copy(style = style)) }
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(style.displayName, color = if (isSelected) CyberCyan else TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text(style.category, color = TextMuted, fontSize = 9.sp)
                    }
                }
            }
        }

        // Color Picker
        Text("Warna Reticle Crosshair:", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            PRESET_CROSSHAIR_COLORS.forEach { (colorHex, _) ->
                val isSelected = config.colorHex == colorHex
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color(colorHex))
                        .border(if (isSelected) 3.dp else 1.dp, if (isSelected) Color.White else SurfaceBorder, CircleShape)
                        .clickable { onConfigChange(config.copy(colorHex = colorHex)) }
                )
            }
        }

        // Custom Sliders
        CyberCard {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Size Slider
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Ukuran Reticle", color = TextSecondary, fontSize = 12.sp)
                    Text("${config.size.toInt()} px", color = CyberCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = config.size,
                    onValueChange = { onConfigChange(config.copy(size = it)) },
                    valueRange = 10f..80f,
                    colors = SliderDefaults.colors(thumbColor = CyberCyan, activeTrackColor = CyberCyan)
                )

                // Thickness Slider
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Ketebalan Garis", color = TextSecondary, fontSize = 12.sp)
                    Text("${config.thickness.toInt()} px", color = CyberCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = config.thickness,
                    onValueChange = { onConfigChange(config.copy(thickness = it)) },
                    valueRange = 1f..8f,
                    colors = SliderDefaults.colors(thumbColor = CyberCyan, activeTrackColor = CyberCyan)
                )

                // Center Gap Slider
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Celah Tengah (Center Gap)", color = TextSecondary, fontSize = 12.sp)
                    Text("${config.gap.toInt()} px", color = CyberCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = config.gap,
                    onValueChange = { onConfigChange(config.copy(gap = it)) },
                    valueRange = 0f..30f,
                    colors = SliderDefaults.colors(thumbColor = CyberCyan, activeTrackColor = CyberCyan)
                )

                // Opacity Slider
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Transparansi (Opacity)", color = TextSecondary, fontSize = 12.sp)
                    Text("${(config.alpha * 100).toInt()}%", color = CyberCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = config.alpha,
                    onValueChange = { onConfigChange(config.copy(alpha = it)) },
                    valueRange = 0.2f..1f,
                    colors = SliderDefaults.colors(thumbColor = CyberCyan, activeTrackColor = CyberCyan)
                )
            }
        }

        // Toggles: Center Dot & Outer Ring & Lock
        CyberCard {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Titik Tengah (Center Dot)", color = TextPrimary, fontSize = 12.sp)
                    Switch(
                        checked = config.hasCenterDot,
                        onCheckedChange = { onConfigChange(config.copy(hasCenterDot = it)) },
                        colors = SwitchDefaults.colors(checkedThumbColor = CyberCyan, checkedTrackColor = SurfaceDark)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Lingkaran Luar (Outer Ring)", color = TextPrimary, fontSize = 12.sp)
                    Switch(
                        checked = config.hasOuterRing,
                        onCheckedChange = { onConfigChange(config.copy(hasOuterRing = it)) },
                        colors = SwitchDefaults.colors(checkedThumbColor = CyberCyan, checkedTrackColor = SurfaceDark)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Kunci Posisi di Layar (Anti-Geser)", color = TextPrimary, fontSize = 12.sp)
                    Switch(
                        checked = config.isLocked,
                        onCheckedChange = { onConfigChange(config.copy(isLocked = it)) },
                        colors = SwitchDefaults.colors(checkedThumbColor = NeonGreen, checkedTrackColor = SurfaceDark)
                    )
                }
            }
        }
    }
}

@Composable
fun EngineerToolsSuiteSection(
    currentDpi: Int,
    onOpenTool: (EngineerTool) -> Unit
) {
    var selectedCategory by remember { mutableStateOf<ToolCategory?>(null) }

    val filteredTools = remember(selectedCategory) {
        if (selectedCategory == null) ALL_ENGINEER_TOOLS else ALL_ENGINEER_TOOLS.filter { it.category == selectedCategory }
    }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        CyberCard {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("TOOLS GAME ENGINEER 15+ IN 1", color = CyberCyan, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text(
                    "Semua utility profesional untuk optimasi gameplay Free Fire & Free Fire MAX.",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }
        }

        // Category Filter Chips
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            item {
                FilterChip(
                    selected = selectedCategory == null,
                    onClick = { selectedCategory = null },
                    label = { Text("Semua (${ALL_ENGINEER_TOOLS.size})", fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = CyberCyan.copy(alpha = 0.2f),
                        selectedLabelColor = CyberCyan
                    )
                )
            }
            items(ToolCategory.values()) { cat ->
                FilterChip(
                    selected = selectedCategory == cat,
                    onClick = { selectedCategory = cat },
                    label = { Text(cat.title, fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = CyberCyan.copy(alpha = 0.2f),
                        selectedLabelColor = CyberCyan
                    )
                )
            }
        }

        // Tools List
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            filteredTools.forEach { tool ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(SurfaceDark)
                        .border(1.dp, SurfaceBorder, RoundedCornerShape(10.dp))
                        .clickable { onOpenTool(tool) }
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(tool.title, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(SurfaceElevated)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(tool.badge, color = CyberCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Text(tool.subtitle, color = TextSecondary, fontSize = 11.sp)
                    }

                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = null,
                        tint = CyberCyan,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun PermissionAndDebugSection(
    hasOverlayPermission: Boolean,
    onGrantOverlay: () -> Unit
) {
    val context = LocalContext.current

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        CyberCard {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("STATUS IZIN & ANTI-ERROR", color = CyberCyan, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text(
                    "Pastikan izin sistem di bawah aktif agar overlay dan floating HUD dapat muncul di atas Free Fire.",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }
        }

        PermissionStatusRow(
            title = "Izin Tampilkan di Atas Aplikasi Lain (Overlay)",
            subtitle = "Wajib untuk Crosshair melayang & menu engineer di dalam game",
            isGranted = hasOverlayPermission,
            onGrantClick = onGrantOverlay
        )

        PermissionStatusRow(
            title = "Izin Notifikasi Layanan Latar Belakang",
            subtitle = "Menjaga agar overlay tidak tertutup otomatis oleh pembersih RAM Android",
            isGranted = true,
            onGrantClick = {
                try {
                    val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                        putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                    }
                    context.startActivity(intent)
                } catch (_: Exception) {
                    val intent = Intent(Settings.ACTION_SETTINGS)
                    context.startActivity(intent)
                }
            }
        )

        PermissionStatusRow(
            title = "Pengecualian Hemat Baterai (Anti-Kill Background)",
            subtitle = "Mencegah Android mematikan proses saat Free Fire berjalan lama",
            isGranted = true,
            onGrantClick = {
                try {
                    val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                    context.startActivity(intent)
                } catch (_: Exception) {
                    val intent = Intent(Settings.ACTION_SETTINGS)
                    context.startActivity(intent)
                }
            }
        )

        // Wireless Debugging (Debug Nirkabel) Shizuku Guide
        CyberCard(backgroundColor = SurfaceElevated) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("PANDUAN DEBUG NIRKABEL (WIRELESS DEBUGGING)", color = TacticalAmber, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text(
                    "Cara mengubah DPI tanpa buka Opsi Pengembang berulang kali:\n" +
                            "1. Buka Pengaturan HP > Opsi Pengembang.\n" +
                            "2. Aktifkan 'Debugging Nirkabel' (Wireless Debugging).\n" +
                            "3. Gunakan Shizuku atau Terminal ADB untuk menghubungkan port.\n" +
                            "4. Setelah terhubung sekali, Nexus Tools dapat mengubah DPI kapan saja langsung dari Overlay game!",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )

                Button(
                    onClick = {
                        try {
                            val intent = Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)
                            context.startActivity(intent)
                        } catch (_: Exception) {
                            Toast.makeText(context, "Buka Opsi Pengembang dari Pengaturan HP", Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = TacticalAmber, contentColor = CarbonDark)
                ) {
                    Text("BUKA OPSI PENGEMBANG SISTEM", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
