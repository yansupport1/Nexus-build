import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/crosshair_config.dart';
import '../models/macro_config.dart';
import '../models/rog_overlay_config.dart';
import '../services/overlay_service.dart';
import 'crosshair_screen.dart';
import 'macro_screen.dart';

class GameSpaceScreen extends StatefulWidget {
  final CrosshairConfig crosshairConfig;
  final MacroConfig macroConfig;
  final RogOverlayConfig rogConfig;
  final Function(CrosshairConfig) onUpdateCrosshair;
  final Function(MacroConfig) onUpdateMacro;
  final Function(RogOverlayConfig) onUpdateRog;

  const GameSpaceScreen({
    Key? key,
    required this.crosshairConfig,
    required this.macroConfig,
    required this.rogConfig,
    required this.onUpdateCrosshair,
    required this.onUpdateMacro,
    required this.onUpdateRog,
  }) : super(key: key);

  @override
  State<GameSpaceScreen> createState() => _GameSpaceScreenState();
}

class _GameSpaceScreenState extends State<GameSpaceScreen> {
  String _activeProfile = 'BEAST'; // BEAST, BALANCED, SAVER
  bool _isOverlayRunning = true;

  void _launchGame(String packageName) async {
    final uri = Uri.parse("android-app://$packageName");
    try {
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Membuka $packageName di Android...'),
            backgroundColor: const Color(0xFFEF4444),
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Paket $packageName siap dijalankan!'),
          backgroundColor: const Color(0xFF10B981),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF07090E),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0B0F17),
        elevation: 0,
        title: Row(
          children: [
            Container(
              width: 10,
              height: 10,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: Color(0xFFEF4444),
              ),
            ),
            const SizedBox(width: 8),
            const Text(
              'ROG ARMOURY CRATE',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w900,
                fontSize: 16,
                letterSpacing: 1.5,
                fontFamily: 'monospace',
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, color: Colors.cyanAccent),
            tooltip: 'Bersihkan Cache Game',
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('RAM Dibersihkan: 1.4 GB Memori Siap untuk Free Fire!'),
                  backgroundColor: Color(0xFF10B981),
                ),
              );
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Performance Profile Banner
            _buildProfileSelector(),
            const SizedBox(height: 16),

            // Game Space Launcher Grid
            _buildGameLauncherCard(
              title: 'FREE FIRE',
              packageName: 'com.dts.freefireth',
              color: const Color(0xFFEF4444),
              fps: '120 FPS LOCK',
              latency: '14ms',
            ),
            const SizedBox(height: 12),
            _buildGameLauncherCard(
              title: 'FREE FIRE MAX',
              packageName: 'com.dts.freefiremax',
              color: const Color(0xFFF59E0B),
              fps: 'ULTRA HD 120 FPS',
              latency: '18ms',
            ),
            const SizedBox(height: 20),

            // Feature Quick Switchers
            const Text(
              'KONTROL OVERLAY GAMING',
              style: TextStyle(
                color: Colors.white70,
                fontWeight: FontWeight.bold,
                fontSize: 12,
                letterSpacing: 1.2,
                fontFamily: 'monospace',
              ),
            ),
            const SizedBox(height: 10),

            Row(
              children: [
                Expanded(
                  child: _buildNavCard(
                    title: 'CROSSHAIR FOTO',
                    subtitle: '7 Reticle Presisi',
                    icon: Icons.filter_center_focus,
                    color: Colors.cyanAccent,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => CrosshairScreen(
                            config: widget.crosshairConfig,
                            onUpdate: widget.onUpdateCrosshair,
                          ),
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _buildNavCard(
                    title: 'MAKRO OVERLAY',
                    subtitle: '${widget.macroConfig.speedMs}ms - ${widget.macroConfig.buttonSize.toInt()}px',
                    icon: Icons.flash_on,
                    color: Colors.amberAccent,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => MacroScreen(
                            config: widget.macroConfig,
                            onUpdate: widget.onUpdateMacro,
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            // Toggle Overlays directly
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: const Color(0xFF0E131E),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.white10),
              ),
              child: Column(
                children: [
                  SwitchListTile(
                    title: const Text(
                      'ROG Device Info Overlay (HUD)',
                      style: TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.bold),
                    ),
                    subtitle: const Text(
                      'Monitor FPS, Temp & CPU di atas game',
                      style: TextStyle(color: Colors.white54, fontSize: 11),
                    ),
                    value: widget.rogConfig.enabled,
                    activeColor: const Color(0xFFEF4444),
                    onChanged: (val) {
                      widget.rogConfig.enabled = val;
                      widget.onUpdateRog(widget.rogConfig);
                    },
                  ),
                  const Divider(color: Colors.white12),
                  SwitchListTile(
                    title: const Text(
                      'Tombol Makro Melayang',
                      style: TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.bold),
                    ),
                    subtitle: Text(
                      'Ukuran ${widget.macroConfig.buttonSize.toInt()}px - Respon ${widget.macroConfig.speedMs}ms',
                      style: TextStyle(color: Colors.white54, fontSize: 11),
                    ),
                    value: widget.macroConfig.enabled,
                    activeColor: Colors.amberAccent,
                    onChanged: (val) {
                      widget.macroConfig.enabled = val;
                      widget.onUpdateMacro(widget.macroConfig);
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProfileSelector() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF0E131E),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0x44EF4444)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'PROFIL PERFORMA GAME',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                  fontFamily: 'monospace',
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: const Color(0x33EF4444),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: const Text(
                  'ENGINE ACTIVE',
                  style: TextStyle(color: Color(0xFFEF4444), fontSize: 9, fontWeight: FontWeight.bold, fontFamily: 'monospace'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              _buildProfileBtn('BEAST', '120 FPS ULTRA', Colors.redAccent),
              const SizedBox(width: 8),
              _buildProfileBtn('BALANCED', '90 FPS STABLE', Colors.cyanAccent),
              const SizedBox(width: 8),
              _buildProfileBtn('SAVER', 'HEMAT SUHU', Colors.greenAccent),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildProfileBtn(String id, String label, Color color) {
    final isSel = _activeProfile == id;
    return Expanded(
      child: GestureDetector(
        onTap: () {
          setState(() {
            _activeProfile = id;
          });
        },
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: isSel ? color.withOpacity(0.2) : const Color(0xFF080C14),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: isSel ? color : Colors.white12),
          ),
          child: Column(
            children: [
              Text(
                id,
                style: TextStyle(
                  color: isSel ? color : Colors.white60,
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'monospace',
                ),
              ),
              const SizedBox(height: 2),
              Text(
                label,
                style: TextStyle(
                  color: isSel ? Colors.white : Colors.white38,
                  fontSize: 8,
                  fontFamily: 'monospace',
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildGameLauncherCard({
    required String title,
    required String packageName,
    required Color color,
    required String fps,
    required String latency,
  }) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF0E131E),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
              color: color.withOpacity(0.15),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: color),
            ),
            child: Icon(Icons.sports_esports, color: color, size: 24),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14),
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Text(fps, style: TextStyle(color: color, fontSize: 10, fontFamily: 'monospace', fontWeight: FontWeight.bold)),
                    const SizedBox(width: 8),
                    Text('• $latency', style: const TextStyle(color: Colors.white54, fontSize: 10, fontFamily: 'monospace')),
                  ],
                ),
              ],
            ),
          ),
          ElevatedButton(
            onPressed: () => _launchGame(packageName),
            style: ElevatedButton.styleFrom(
              backgroundColor: color,
              foregroundColor: Colors.black,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            ),
            child: const Text('LAUNCH', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11)),
          ),
        ],
      ),
    );
  }

  Widget _buildNavCard({
    required String title,
    required String subtitle,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: const Color(0xFF0E131E),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: color, size: 24),
            const SizedBox(height: 8),
            Text(
              title,
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12),
            ),
            const SizedBox(height: 2),
            Text(
              subtitle,
              style: const TextStyle(color: Colors.white54, fontSize: 10),
            ),
          ],
        ),
      ),
    );
  }
}
