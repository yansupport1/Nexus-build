import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'package:permission_handler/permission_handler.dart';

import 'models/crosshair_config.dart';
import 'models/macro_config.dart';
import 'models/rog_overlay_config.dart';
import 'screens/game_space_screen.dart';
import 'screens/macro_screen.dart';
import 'screens/crosshair_screen.dart';
import 'widgets/crosshair_painter.dart';
import 'widgets/floating_macro_button.dart';
import 'widgets/rog_telemetry_hud.dart';
import 'services/overlay_service.dart';
import 'screens/true_overlay_screen.dart';

// ENTRY POINT FOR OVERLAY
@pragma("vm:entry-point")
void overlayMain() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: TrueOverlayScreen(),
  ));
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.landscapeLeft,
    DeviceOrientation.landscapeRight,
    DeviceOrientation.portraitUp,
  ]);
  runApp(const NexusToolsFlutterApp());
}

class NexusToolsFlutterApp extends StatelessWidget {
  const NexusToolsFlutterApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Nexus Tools - Free Fire Gaming Overlay',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF07090E),
        primaryColor: const Color(0xFFEF4444),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFFEF4444),
          secondary: Colors.cyanAccent,
        ),
      ),
      home: const MainGamingShell(),
    );
  }
}

class MainGamingShell extends StatefulWidget {
  const MainGamingShell({Key? key}) : super(key: key);

  @override
  State<MainGamingShell> createState() => _MainGamingShellState();
}

class _MainGamingShellState extends State<MainGamingShell> {
  final CrosshairConfig _crosshairConfig = CrosshairConfig(
    style: CrosshairStyle.gapCross,
    color: const Color(0xFF00E5FF),
    size: 28.0,
    thickness: 2.0,
    gap: 6.0,
  );

  final MacroConfig _macroConfig = MacroConfig(
    enabled: true,
    buttonSize: 56.0,
    speedMs: 15,
    comboType: MacroComboType.glooWall,
    posX: 25.0,
    posY: 220.0,
  );

  final RogOverlayConfig _rogConfig = RogOverlayConfig(
    enabled: true,
    mode: RogOverlayMode.compactBar,
    posX: 20.0,
    posY: 50.0,
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('NEXUS GAME SPACE', style: TextStyle(fontFamily: 'monospace', fontWeight: FontWeight.bold)),
        backgroundColor: const Color(0xFF0E131E),
        actions: [
          IconButton(
            icon: const Icon(Icons.rocket_launch, color: Colors.cyanAccent),
            onPressed: () async {
              // Minta izin
              await Permission.notification.request();
              final granted = await FlutterOverlayWindow.isPermissionGranted();
              if (!granted) {
                await FlutterOverlayWindow.requestPermission();
              }
              
              if (await FlutterOverlayWindow.isPermissionGranted()) {
                if (await FlutterOverlayWindow.isActive()) return;
                await FlutterOverlayWindow.showOverlay(
                  enableDrag: true,
                  overlayTitle: "Nexus Tools",
                  overlayContent: "Floating Menu Active",
                  flag: OverlayFlag.defaultFlag,
                  visibility: NotificationVisibility.visibilityPublic,
                  positionGravity: PositionGravity.auto,
                  height: 180,
                  width: 180,
                );
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Overlay berhasil dijalankan!'), backgroundColor: Colors.green),
                );
              } else {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Izin overlay ditolak!'), backgroundColor: Colors.red),
                );
              }
            },
          ),
        ],
      ),
      body: GameSpaceScreen(
        crosshairConfig: _crosshairConfig,
        macroConfig: _macroConfig,
        rogConfig: _rogConfig,
        onUpdateCrosshair: (cfg) => setState(() {}),
        onUpdateMacro: (cfg) => setState(() {}),
        onUpdateRog: (cfg) => setState(() {}),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          // Minta izin notification & overlay
          await Permission.notification.request();
          final granted = await FlutterOverlayWindow.isPermissionGranted();
          if (!granted) {
            await FlutterOverlayWindow.requestPermission();
          }
          
          if (await FlutterOverlayWindow.isPermissionGranted()) {
            if (await FlutterOverlayWindow.isActive()) return;
            await FlutterOverlayWindow.showOverlay(
              enableDrag: true,
              overlayTitle: "Nexus Tools",
              overlayContent: "Floating Menu Active",
              flag: OverlayFlag.defaultFlag,
              visibility: NotificationVisibility.visibilityPublic,
              positionGravity: PositionGravity.auto,
              height: 180,
              width: 180,
            );
          }
        },
        backgroundColor: const Color(0xFFEF4444),
        icon: const Icon(Icons.play_arrow, color: Colors.white),
        label: const Text('START OVERLAY', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
      ),
    );
  }
}
