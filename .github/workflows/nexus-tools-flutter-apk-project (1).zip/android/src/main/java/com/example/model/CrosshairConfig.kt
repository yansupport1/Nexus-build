package com.example.model

enum class CrosshairStyle(val displayName: String, val category: String) {
    DOT("Precision Dot", "Minimal"),
    CLASSIC_CROSS("Classic Cross", "Standard"),
    GAP_CROSS("Tactical Gap Cross", "Competitive"),
    CIRCLE_DOT("Circle + Dot", "Pro Shotgun"),
    SHOTGUN_RING("Shotgun Spread Ring", "Close Range"),
    HOLLOW_DIAMOND("Hollow Diamond", "Modern"),
    CHEVRON_SNIPER("Chevron Arrow", "Sniper AWM"),
    TRIANGLE_AIM("Tri-Force Aim", "Futuristic"),
    T_SHAPE("T-Shape (No Top)", "Headshot Meta"),
    PLUS_DOT("Plus & Core Dot", "Hybrid"),
    PREDATOR_TRI("Predator 3-Prong", "Assault"),
    TACTICAL_SCOPE("Tactical Scope Cross", "Precision"),
    SQUARE_BOX("Hollow Square", "Cyber"),
    X_CROSS("X-Diagonal Cross", "Reflex"),
    DUAL_CIRCLE("Dual Concentric Ring", "Hipfire"),
    HEART_AIM("Chibi Heart Reticle", "Custom")
}

data class CrosshairConfig(
    val style: CrosshairStyle = CrosshairStyle.GAP_CROSS,
    val size: Float = 36f, // 10f to 100f
    val thickness: Float = 3f, // 1f to 10f
    val gap: Float = 10f, // 0f to 40f
    val colorHex: Long = 0xFF00F0FF, // Cyan default
    val alpha: Float = 0.95f, // 0.2f to 1.0f
    val rotation: Float = 0f, // 0 to 90 degrees
    val hasCenterDot: Boolean = true,
    val centerDotSize: Float = 4f,
    val hasOuterRing: Boolean = false,
    val ringRadius: Float = 28f,
    val offsetX: Float = 0f, // fine-tuning offset
    val offsetY: Float = 0f,
    val isLocked: Boolean = false, // prevent accidental dragging in game
    val isVisible: Boolean = true,
    val quickSettingMode: Boolean = false // opened via 3x tap on crosshair!
)

val PRESET_CROSSHAIR_COLORS = listOf(
    0xFF00F0FF to "Cyber Cyan",
    0xFFFF1744 to "Crimson Red",
    0xFF00E676 to "Neon Green",
    0xFFFFEA00 to "Toxic Yellow",
    0xFFFFFFFF to "Pure White",
    0xFFD500F9 to "Electric Violet",
    0xFFFF6D00 to "Blaze Orange",
    0xFF00B0FF to "Sky Blue"
)
