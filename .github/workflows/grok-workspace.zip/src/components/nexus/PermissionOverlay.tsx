import { Button } from "@/components/ui/button";
import { useNexus } from "@/lib/nexus/store";
import { Bell, Layers } from "lucide-react";

export function PermissionOverlay() {
  const open = useNexus((s) => s.permOpen);
  const step = useNexus((s) => s.permStep);
  const overlayPerm = useNexus((s) => s.overlayPerm);
  const grantOverlay = useNexus((s) => s.grantOverlay);
  const denyOverlay = useNexus((s) => s.denyOverlay);
  const grantNotif = useNexus((s) => s.grantNotif);
  const skipNotif = useNexus((s) => s.skipNotif);

  if (!open) return null;

  const overlayStep = step === "overlay" && overlayPerm !== "granted";

  return (
    <div className="nexus-perm fixed inset-0 flex items-end justify-center bg-bg/85 p-4 sm:items-center">
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="perm-title"
        className="w-full max-w-md rounded-[var(--radius-xl)] bg-surface p-5 shadow-[var(--shadow-border)] sm:p-6"
      >
        <div className="mb-4 flex size-12 items-center justify-center rounded-[var(--radius-md)] bg-elevated shadow-[var(--shadow-border)]">
          {overlayStep ? (
            <Layers className="size-5 text-cyan" />
          ) : (
            <Bell className="size-5 text-cyan" />
          )}
        </div>

        {overlayStep ? (
          <>
            <p className="mb-1 font-mono text-[11px] font-medium tracking-[0.18em] text-cyan uppercase">
              Izin overlay
            </p>
            <h2 id="perm-title" className="font-display text-2xl font-semibold tracking-tight text-fg text-balance">
              Tampilkan di atas arena
            </h2>
            <p className="mt-2 text-sm leading-relaxed text-muted text-pretty">
              Izin ini satu-satunya tujuan overlay: supaya{" "}
              <span className="text-fg">crosshair</span> dan{" "}
              <span className="text-fg">menu overlay</span> bisa muncul di atas
              pertandingan. Tanpa izin, keduanya tidak ditampilkan. Tidak
              mengubah data pertandingan.
            </p>
            <ul className="mt-4 space-y-2 text-sm text-muted">
              <li className="flex gap-2">
                <span className="mt-1.5 size-1.5 shrink-0 rounded-full bg-cyan" />
                Crosshair reticle di atas medan
              </li>
              <li className="flex gap-2">
                <span className="mt-1.5 size-1.5 shrink-0 rounded-full bg-cyan" />
                Tombol overlay membuka mod menu
              </li>
              <li className="flex gap-2">
                <span className="mt-1.5 size-1.5 shrink-0 rounded-full bg-cyan" />
                Makro hold-to-fire di lapisan yang sama
              </li>
            </ul>
            <div className="mt-5 flex flex-col gap-2 sm:flex-row-reverse">
              <Button className="flex-1" variant="cyan" onClick={grantOverlay}>
                Izinkan overlay
              </Button>
              <Button className="flex-1" variant="secondary" onClick={denyOverlay}>
                Nanti
              </Button>
            </div>
          </>
        ) : (
          <>
            <p className="mb-1 font-mono text-[11px] font-medium tracking-[0.18em] text-cyan uppercase">
              Izin notifikasi
            </p>
            <h2 id="perm-title" className="font-display text-2xl font-semibold tracking-tight text-fg text-balance">
              Kode pairing DPI
            </h2>
            <p className="mt-2 text-sm leading-relaxed text-muted text-pretty">
              Notifikasi dipakai untuk mengirim kode pairing debug — membuka
              tuner DPI tanpa masuk opsi pengembang. Kode 6 digit muncul di
              banner, lalu kamu masukkan di panel DPI.
            </p>
            <div className="mt-5 flex flex-col gap-2 sm:flex-row-reverse">
              <Button className="flex-1" variant="cyan" onClick={() => void grantNotif()}>
                Izinkan notifikasi
              </Button>
              <Button className="flex-1" variant="secondary" onClick={skipNotif}>
                Lewati
              </Button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
