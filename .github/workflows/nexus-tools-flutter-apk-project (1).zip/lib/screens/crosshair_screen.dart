import 'package:flutter/material.dart';
import '../models/crosshair_config.dart';
import '../widgets/crosshair_painter.dart';

class CrosshairScreen extends StatefulWidget {
  final CrosshairConfig config;
  final Function(CrosshairConfig) onUpdate;

  const CrosshairScreen({
    Key? key,
    required this.config,
    required this.onUpdate,
  }) : super(key: key);

  @override
  State<CrosshairScreen> createState() => _CrosshairScreenState();
}

class _CrosshairScreenState extends State<CrosshairScreen> {
  late CrosshairConfig _config;

  final List<Map<String, dynamic>> _catalog = [
    {
      'style': CrosshairStyle.gapCross,
      'name': 'Tactical Gap Aim',
      'weapon': 'Semua Senjata / AR & SMG',
      'desc': '4 garis taktis dengan celah tengah presisi.',
    },
    {
      'style': CrosshairStyle.shotgunRing,
      'name': 'Shotgun M1887 Ring',
      'weapon': 'Shotgun M1887 & SPAS12',
      'desc': 'Lingkaran akurat sebaran peluru pellet shotgun.',
    },
    {
      'style': CrosshairStyle.chevronSniper,
      'name': 'AWM Chevron Sniper',
      'weapon': 'AWM, Barret M82B, Kar98k',
      'desc': 'Panah chevron V terbalik untuk 1-tap headshot.',
    },
    {
      'style': CrosshairStyle.dot,
      'name': 'Precision Red Dot',
      'weapon': 'Desert Eagle & Woodpecker',
      'desc': 'Titik tunggal pixel-perfect tanpa menghalangi visual.',
    },
    {
      'style': CrosshairStyle.classicCross,
      'name': 'Classic CS Cross',
      'weapon': 'MP40 & UMP Fast Drag',
      'desc': 'Silang klasik dengan kestabilan visual tinggi.',
    },
    {
      'style': CrosshairStyle.predatorAim,
      'name': 'Predator Tri-HUD',
      'weapon': 'Groza, SCAR, M4A1',
      'desc': 'HUD 3-sudut segitiga taktis untuk tracking kepala lawan.',
    },
    {
      'style': CrosshairStyle.cyberQuad,
      'name': 'Cyber Quad Brackets',
      'weapon': 'Bizon, Thompson & AC80',
      'desc': 'Kurung 4 sudut futuristik untuk frame target.',
    },
  ];

  final List<Color> _colors = const [
    Color(0xFF00E5FF), // Cyan
    Color(0xFFEF4444), // Crimson Red
    Color(0xFF10B981), // Emerald Green
    Color(0xFFF59E0B), // Amber Gold
    Color(0xFFEC4899), // Neon Pink
    Color(0xFFFFFFFF), // Pure White
  ];

  @override
  void initState() {
    super.initState();
    _config = widget.config;
  }

  void _notifyUpdate() {
    setState(() {});
    widget.onUpdate(_config);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF07090E),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0B0F17),
        title: const Text(
          'KATALOG RETICLE CROSSHAIR',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 14,
            fontFamily: 'monospace',
          ),
        ),
      ),
      body: Column(
        children: [
          // Live Crosshair Target Simulator Box
          Container(
            width: double.infinity,
            height: 140,
            margin: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.black,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Colors.cyanAccent.withOpacity(0.3)),
              image: const DecorationImage(
                image: NetworkImage('https://images.unsplash.com/photo-1542751371-adc38448a05e?q=80&w=600&auto=format&fit=crop'),
                fit: BoxFit.cover,
                opacity: 0.35,
              ),
            ),
            child: Center(
              child: CustomPaint(
                size: Size(_config.size, _config.size),
                painter: CrosshairPainter(config: _config),
              ),
            ),
          ),

          // Config Sliders & Catalog List
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: [
                // Color Picker Chips
                const Text(
                  'WARNA RETICLE',
                  style: TextStyle(color: Colors.white70, fontSize: 11, fontFamily: 'monospace', fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                Row(
                  children: _colors.map((c) {
                    final isSel = _config.color.value == c.value;
                    return GestureDetector(
                      onTap: () {
                        _config.color = c;
                        _notifyUpdate();
                      },
                      child: Container(
                        margin: const EdgeInsets.only(right: 10),
                        width: 32,
                        height: 32,
                        decoration: BoxDecoration(
                          color: c,
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: isSel ? Colors.white : Colors.transparent,
                            width: 2.5,
                          ),
                          boxShadow: isSel ? [BoxShadow(color: c.withOpacity(0.6), blurRadius: 10)] : null,
                        ),
                      ),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 16),

                // Size Slider
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Ukuran Crosshair', style: TextStyle(color: Colors.white70, fontSize: 12)),
                    Text('${_config.size.toInt()}px', style: const TextStyle(color: Colors.cyanAccent, fontFamily: 'monospace', fontWeight: FontWeight.bold)),
                  ],
                ),
                Slider(
                  value: _config.size,
                  min: 12,
                  max: 64,
                  activeColor: Colors.cyanAccent,
                  inactiveColor: Colors.white12,
                  onChanged: (val) {
                    _config.size = val;
                    _notifyUpdate();
                  },
                ),

                // Catalog Cards
                const SizedBox(height: 12),
                const Text(
                  'PILIH FOTO DESAIN RETICLE',
                  style: TextStyle(color: Colors.white70, fontSize: 11, fontFamily: 'monospace', fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 10),

                ..._catalog.map((item) {
                  final style = item['style'] as CrosshairStyle;
                  final isSel = _config.style == style;

                  return GestureDetector(
                    onTap: () {
                      _config.style = style;
                      _notifyUpdate();
                    },
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 10),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: isSel ? const Color(0x3300E5FF) : const Color(0xFF0E131E),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: isSel ? Colors.cyanAccent : Colors.white10,
                          width: isSel ? 1.5 : 1,
                        ),
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 48,
                            height: 48,
                            decoration: BoxDecoration(
                              color: Colors.black,
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: Colors.white24),
                            ),
                            child: Center(
                              child: CustomPaint(
                                size: const Size(26, 26),
                                painter: CrosshairPainter(
                                  config: CrosshairConfig(
                                    style: style,
                                    color: _config.color,
                                    size: 26,
                                    thickness: 2,
                                    gap: 5,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  item['name'],
                                  style: TextStyle(
                                    color: isSel ? Colors.cyanAccent : Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 13,
                                  ),
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  item['weapon'],
                                  style: const TextStyle(color: Colors.amberAccent, fontSize: 10, fontFamily: 'monospace'),
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  item['desc'],
                                  style: const TextStyle(color: Colors.white54, fontSize: 10),
                                ),
                              ],
                            ),
                          ),
                          if (isSel)
                            const Icon(Icons.check_circle, color: Colors.cyanAccent, size: 20),
                        ],
                      ),
                    ),
                  );
                }).toList(),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
