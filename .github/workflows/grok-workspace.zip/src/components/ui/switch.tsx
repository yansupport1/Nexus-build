import { cn } from "@/lib/utils";

export function Switch({
  checked,
  onCheckedChange,
  id,
  label,
}: {
  checked: boolean;
  onCheckedChange: (v: boolean) => void;
  id?: string;
  label?: string;
}) {
  return (
    <button
      id={id}
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={() => onCheckedChange(!checked)}
      className={cn(
        "relative h-7 w-12 shrink-0 rounded-full transition-colors duration-[var(--motion-quick)] ease-[var(--ease-out)]",
        checked ? "bg-cyan" : "bg-elevated shadow-[var(--shadow-border)]",
      )}
    >
      <span
        className={cn(
          "absolute top-0.5 size-6 rounded-full bg-fg transition-transform duration-[var(--motion-quick)] ease-[var(--ease-out)]",
          checked ? "translate-x-5" : "translate-x-0.5",
        )}
      />
    </button>
  );
}
