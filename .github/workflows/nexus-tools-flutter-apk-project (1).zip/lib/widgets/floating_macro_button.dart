import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/macro_config.dart';

class FloatingMacroButton extends StatefulWidget {
  final MacroConfig config;
  final VoidCallback onOpenSettings;
  final Function(MacroConfig) onUpdateConfig;

  const FloatingMacroButton({
    Key? key,
    required this.config,
    required this.onOpenSettings,
    required this.onUpdateConfig,
  }) : super(key: key);

  @override
  State<FloatingMacroButton> createState() => _FloatingMacroButtonState();
}

class _FloatingMacroButtonState extends State<FloatingMacroButton> with SingleTickerProviderStateMixin {
  late double _x;
  late double _y;
  bool _isExecuting = false;
  String? _lastExecutionStatus;
  late AnimationController _animController;

  @override
  void initState() {
    super.initState();
    _x = widget.config.posX;
    _y = widget.config.posY;
    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 200),
    );
  }

  @override
  void dispose() {
    _animController.dispose();
    super.dispose();
  }

  void _executeMacro() async {
    if (_isExecuting) return;

    setState(() {
      _isExecuting = true;
      _lastExecutionStatus = '${widget.config.speedMs}ms Combo Triggered';
    });

    if (widget.config.hapticEnabled) {
      HapticFeedback.heavyImpact();
    }

    _animController.forward(from: 0.0);

    // Simulate multi-tap macro speed burst
    await Future.delayed(Duration(milliseconds: widget.config.speedMs * 3));

    if (mounted) {
      if (widget.config.hapticEnabled) {
        HapticFeedback.lightImpact();
      }
      setState(() {
        _isExecuting = false;
      });

      Timer(const Duration(seconds: 2), () {
        if (mounted) {
          setState(() {
            _lastExecutionStatus = null;
          });
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.config.enabled) return const SizedBox.shrink();

    final size = widget.config.buttonSize;

    return Positioned(
      left: _x,
      top: _y,
      child: GestureDetector(
        onPanUpdate: (details) {
          setState(() {
            _x += details.delta.dx;
            _y += details.delta.dy;
          });
          widget.config.posX = _x;
          widget.config.posY = _y;
          widget.onUpdateConfig(widget.config);
        },
        onTap: _executeMacro,
        onLongPress: widget.onOpenSettings,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 150),
              width: size,
              height: size,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: _isExecuting
                      ? [const Color(0xFFF59E0B), const Color(0xFFEF4444)]
                      : [const Color(0xFFD97706), const Color(0xFFB45309)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                boxShadow: [
                  BoxShadow(
                    color: (_isExecuting ? const Color(0xFFF59E0B) : const Color(0xFFD97706)).withOpacity(0.6),
                    blurRadius: _isExecuting ? 16 : 8,
                    spreadRadius: _isExecuting ? 2 : 0,
                  )
                ],
                border: Border.all(
                  color: Colors.amberAccent,
                  width: 2.0,
                ),
              ),
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.flash_on,
                      color: Colors.white,
                      size: size * 0.45,
                    ),
                    if (size >= 50)
                      Text(
                        '${widget.config.speedMs}ms',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: size * 0.18,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'monospace',
                        ),
                      ),
                  ],
                ),
              ),
            ),
            if (_lastExecutionStatus != null)
              Container(
                margin: const EdgeInsets.only(top: 4),
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.8),
                  borderRadius: BorderRadius.circular(4),
                  border: Border.all(color: Colors.amberAccent.withOpacity(0.5)),
                ),
                child: Text(
                  _lastExecutionStatus!,
                  style: const TextStyle(
                    color: Colors.amberAccent,
                    fontSize: 9,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'monospace',
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
