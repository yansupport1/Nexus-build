//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BA1jJXUA.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-B6OBvO0q.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-B6OBvO0q.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-D0XppsWL.js"]
	}
} });
//#endregion
export { tsrStartManifest };
