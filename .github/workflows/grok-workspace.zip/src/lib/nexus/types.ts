export type CrosshairStyle =
  | "gapCross"
  | "shotgunRing"
  | "chevronSniper"
  | "dot"
  | "classicCross"
  | "predatorAim"
  | "cyberQuad";

export type MacroCombo = "glooWall" | "jumpShot" | "autoDragBurst" | "quickScope";

export type ProfileId = "BEAST" | "BALANCED" | "SAVER";

export type PermState = "needed" | "granted" | "denied";

export type AppView = "hub" | "arena";

export interface CrosshairConfig {
  enabled: boolean;
  style: CrosshairStyle;
  color: string;
  size: number;
  thickness: number;
  gap: number;
  opacity: number;
  locked: boolean;
  x: number;
  y: number;
}

export interface MacroConfig {
  enabled: boolean;
  buttonSize: number;
  speedMs: number;
  combo: MacroCombo;
  x: number;
  y: number;
}

export interface HudConfig {
  enabled: boolean;
  expanded: boolean;
  x: number;
  y: number;
}

export interface OverlayOrb {
  x: number;
  y: number;
}

export const CROSSHAIR_COLORS = [
  { id: "cyan", value: "#00D4FF", label: "Cyan" },
  { id: "ice", value: "#E8EEF8", label: "Ice" },
  { id: "crimson", value: "#EF4444", label: "Crimson" },
  { id: "emerald", value: "#34D399", label: "Emerald" },
  { id: "steel", value: "#7DD3FC", label: "Steel" },
  { id: "white", value: "#FFFFFF", label: "White" },
] as const;

export const CROSSHAIR_CATALOG: {
  style: CrosshairStyle;
  name: string;
  weapon: string;
  desc: string;
}[] = [
  {
    style: "gapCross",
    name: "Tactical Gap Aim",
    weapon: "Semua senjata / AR & SMG",
    desc: "Empat garis dengan celah tengah presisi.",
  },
  {
    style: "shotgunRing",
    name: "Shotgun Ring",
    weapon: "Spread close-range",
    desc: "Lingkaran sebaran pellet plus bead tengah.",
  },
  {
    style: "chevronSniper",
    name: "Chevron Sniper",
    weapon: "Long range / 1-tap",
    desc: "Chevron V terbalik untuk titik kepala.",
  },
  {
    style: "dot",
    name: "Precision Dot",
    weapon: "Pistol & burst",
    desc: "Titik tunggal tanpa menghalangi target.",
  },
  {
    style: "classicCross",
    name: "Classic Cross",
    weapon: "SMG drag",
    desc: "Silang klasik, kestabilan visual tinggi.",
  },
  {
    style: "predatorAim",
    name: "Predator Tri-HUD",
    weapon: "AR tracking",
    desc: "Tiga jari taktis untuk follow target.",
  },
  {
    style: "cyberQuad",
    name: "Cyber Quad Brackets",
    weapon: "Frame target",
    desc: "Kurung empat sudut untuk mengunci siluet.",
  },
];

export const MACRO_COMBOS: {
  id: MacroCombo;
  title: string;
  sequence: string;
}[] = [
  {
    id: "glooWall",
    title: "Fast Cover Drop",
    sequence: "Tembak → jongkok → taruh cover → ganti senjata",
  },
  {
    id: "jumpShot",
    title: "Jump Shot Swap",
    sequence: "Lompat → tembak → ganti senjata instan",
  },
  {
    id: "autoDragBurst",
    title: "Auto Drag Burst",
    sequence: "Burst vertikal beruntun saat tombol ditahan",
  },
  {
    id: "quickScope",
    title: "Quick Scope Swap",
    sequence: "Scope on → tembak → scope off cepat",
  },
];

export const DEFAULT_CROSSHAIR: CrosshairConfig = {
  enabled: true,
  style: "gapCross",
  color: "#00D4FF",
  size: 32,
  thickness: 2,
  gap: 6,
  opacity: 1,
  locked: false,
  x: 0.5,
  y: 0.48,
};

export const DEFAULT_MACRO: MacroConfig = {
  enabled: true,
  buttonSize: 64,
  speedMs: 15,
  combo: "autoDragBurst",
  x: 0.86,
  y: 0.72,
};

export const DEFAULT_HUD: HudConfig = {
  enabled: true,
  expanded: false,
  x: 0.04,
  y: 0.08,
};

export const DEFAULT_ORB: OverlayOrb = { x: 0.08, y: 0.72 };
