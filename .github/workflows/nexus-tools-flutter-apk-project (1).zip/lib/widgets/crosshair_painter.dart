import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../models/crosshair_config.dart';

class CrosshairPainter extends CustomPainter {
  final CrosshairConfig config;

  CrosshairPainter({required this.config});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final paint = Paint()
      ..color = config.color.withOpacity(config.opacity)
      ..strokeWidth = config.thickness
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    final fillPaint = Paint()
      ..color = config.color.withOpacity(config.opacity)
      ..style = PaintingStyle.fill;

    final half = config.size / 2;
    final gap = config.gap;

    switch (config.style) {
      case CrosshairStyle.dot:
        canvas.drawCircle(center, math.max(1.5, config.thickness), fillPaint);
        break;

      case CrosshairStyle.classicCross:
        // Horizontal
        canvas.drawLine(Offset(center.dx - half, center.dy), Offset(center.dx + half, center.dy), paint);
        // Vertical
        canvas.drawLine(Offset(center.dx, center.dy - half), Offset(center.dx, center.dy + half), paint);
        break;

      case CrosshairStyle.gapCross:
        // Left
        canvas.drawLine(Offset(center.dx - half, center.dy), Offset(center.dx - gap, center.dy), paint);
        // Right
        canvas.drawLine(Offset(center.dx + gap, center.dy), Offset(center.dx + half, center.dy), paint);
        // Top
        canvas.drawLine(Offset(center.dx, center.dy - half), Offset(center.dx, center.dy - gap), paint);
        // Bottom
        canvas.drawLine(Offset(center.dx, center.dy + gap), Offset(center.dx, center.dy + half), paint);
        // Small center dot
        canvas.drawCircle(center, 1.2, fillPaint);
        break;

      case CrosshairStyle.shotgunRing:
        // Outer circular ring for Shotgun M1887 spread
        canvas.drawCircle(center, half, paint);
        // Center precision bead
        canvas.drawCircle(center, config.thickness + 0.5, fillPaint);
        // Cardinal ticks
        canvas.drawLine(Offset(center.dx - half - 3, center.dy), Offset(center.dx - half + 2, center.dy), paint);
        canvas.drawLine(Offset(center.dx + half - 2, center.dy), Offset(center.dx + half + 3, center.dy), paint);
        break;

      case CrosshairStyle.chevronSniper:
        // Inverted V chevron for AWM / Barret M82B
        final path = Path();
        path.moveTo(center.dx - half * 0.7, center.dy + half * 0.5);
        path.lineTo(center.dx, center.dy);
        path.lineTo(center.dx + half * 0.7, center.dy + half * 0.5);
        canvas.drawPath(path, paint);
        // Subtle center dot
        canvas.drawCircle(center, 1.0, fillPaint);
        break;

      case CrosshairStyle.predatorAim:
        // Triangular 3-point tactical HUD
        for (int i = 0; i < 3; i++) {
          final angle = (i * 120 - 90) * math.pi / 180;
          final px = center.dx + half * math.cos(angle);
          final py = center.dy + half * math.sin(angle);
          canvas.drawLine(center, Offset(px, py), paint);
        }
        canvas.drawCircle(center, 1.5, fillPaint);
        break;

      case CrosshairStyle.cyberQuad:
        // 4 corner brackets
        final cornerSize = half * 0.4;
        final d = half * 0.8;
        // Top Left
        canvas.drawLine(Offset(center.dx - d, center.dy - d), Offset(center.dx - d + cornerSize, center.dy - d), paint);
        canvas.drawLine(Offset(center.dx - d, center.dy - d), Offset(center.dx - d, center.dy - d + cornerSize), paint);
        // Top Right
        canvas.drawLine(Offset(center.dx + d, center.dy - d), Offset(center.dx + d - cornerSize, center.dy - d), paint);
        canvas.drawLine(Offset(center.dx + d, center.dy - d), Offset(center.dx + d, center.dy - d + cornerSize), paint);
        // Bottom Left
        canvas.drawLine(Offset(center.dx - d, center.dy + d), Offset(center.dx - d + cornerSize, center.dy + d), paint);
        canvas.drawLine(Offset(center.dx - d, center.dy + d), Offset(center.dx - d, center.dy + d - cornerSize), paint);
        // Bottom Right
        canvas.drawLine(Offset(center.dx + d, center.dy + d), Offset(center.dx + d - cornerSize, center.dy + d), paint);
        canvas.drawLine(Offset(center.dx + d, center.dy + d), Offset(center.dx + d, center.dy + d - cornerSize), paint);
        break;
    }
  }

  @override
  bool shouldRepaint(covariant CrosshairPainter oldDelegate) {
    return oldDelegate.config != config;
  }
}
