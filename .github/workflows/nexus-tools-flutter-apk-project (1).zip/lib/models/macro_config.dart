enum MacroComboType {
  glooWall,
  jumpShot,
  autoDragBurst,
  quickScope,
}

class MacroConfig {
  bool enabled;
  double buttonSize; // 36 to 96
  int speedMs; // 5 to 200 ms
  MacroComboType comboType;
  double opacity;
  double posX;
  double posY;
  int loopCount;
  bool hapticEnabled;

  MacroConfig({
    this.enabled = true,
    this.buttonSize = 56.0,
    this.speedMs = 15,
    this.comboType = MacroComboType.glooWall,
    this.opacity = 0.95,
    this.posX = 30.0,
    this.posY = 240.0,
    this.loopCount = 1,
    this.hapticEnabled = true,
  });

  String get comboTitle {
    switch (comboType) {
      case MacroComboType.glooWall:
        return 'Fast Gloo Wall (Es Kepal Cepat)';
      case MacroComboType.jumpShot:
        return 'Jump Shot Quick Swap';
      case MacroComboType.autoDragBurst:
        return 'Auto Drag Fire Burst';
      case MacroComboType.quickScope:
        return 'AWM Quick Scope & Swap';
    }
  }

  String get comboSequence {
    switch (comboType) {
      case MacroComboType.glooWall:
        return 'Tembak Drag -> Jongkok -> Taruh Gloo Wall -> Ganti Senjata';
      case MacroComboType.jumpShot:
        return 'Lompat -> Tembak Headshot -> Ganti Senjata Instan';
      case MacroComboType.autoDragBurst:
        return 'Simulasi Drag Vertikal Beruntun Anti Recoil';
      case MacroComboType.quickScope:
        return 'Scope On -> Tembak AWM -> Scope Off Cepat';
    }
  }
}
