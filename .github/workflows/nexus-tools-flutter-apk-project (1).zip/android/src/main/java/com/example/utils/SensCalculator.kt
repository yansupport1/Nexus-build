package com.example.utils

data class FreeFireSensitivity(
    val general: Int,
    val redDot: Int,
    val scope2x: Int,
    val scope4x: Int,
    val sniperScope: Int,
    val freeLook: Int,
    val fireButtonSize: Int,
    val profileName: String
)

object SensCalculator {
    fun calculate(dpi: Int, style: String = "HEADSHOT_DRAG"): FreeFireSensitivity {
        return when (style) {
            "HEADSHOT_DRAG" -> {
                // Optimized for swift upward drag shots (One Tap)
                val base = if (dpi >= 600) 95 else if (dpi >= 480) 98 else 100
                FreeFireSensitivity(
                    general = base,
                    redDot = minOf(100, base + 2),
                    scope2x = (base * 0.94f).toInt(),
                    scope4x = (base * 0.88f).toInt(),
                    sniperScope = (base * 0.65f).toInt(),
                    freeLook = (base * 0.80f).toInt(),
                    fireButtonSize = if (dpi >= 500) 42 else 48,
                    profileName = "One-Tap Headshot Meta"
                )
            }
            "SNIPER_PRECISION" -> {
                // Optimized for AWM/Barrett double sniper flick
                FreeFireSensitivity(
                    general = 90,
                    redDot = 88,
                    scope2x = 85,
                    scope4x = 82,
                    sniperScope = 72,
                    freeLook = 65,
                    fireButtonSize = 52,
                    profileName = "Double Sniper Fast Flick"
                )
            }
            else -> {
                // Balanced Claw
                FreeFireSensitivity(
                    general = 96,
                    redDot = 94,
                    scope2x = 90,
                    scope4x = 85,
                    sniperScope = 60,
                    freeLook = 75,
                    fireButtonSize = 45,
                    profileName = "Balanced Competitive Claw"
                )
            }
        }
    }
}
