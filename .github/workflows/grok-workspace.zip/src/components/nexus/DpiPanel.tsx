import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { useNexus } from "@/lib/nexus/store";
import { Bell, X } from "lucide-react";

export function DpiPanel() {
  const open = useNexus((s) => s.dpiOpen);
  const close = useNexus((s) => s.setDpiOpen);
  const dpi = useNexus((s) => s.dpi);
  const setDpi = useNexus((s) => s.setDpi);
  const unlocked = useNexus((s) => s.dpiUnlocked);
  const pairingInput = useNexus((s) => s.pairingInput);
  const setPairingInput = useNexus((s) => s.setPairingInput);
  const requestPairing = useNexus((s) => s.requestPairing);
  const submitPairing = useNexus((s) => s.submitPairing);
  const banner = useNexus((s) => s.pairingBanner);
  const notifPerm = useNexus((s) => s.notifPerm);

  if (!open) return null;

  return (
    <div className="nexus-sheet fixed inset-0 flex items-end justify-center bg-bg/80 sm:items-center sm:p-4">
      <div className="w-full max-w-lg rounded-t-[var(--radius-xl)] bg-surface p-5 shadow-[var(--shadow-border)] sm:rounded-[var(--radius-xl)]">
        <div className="flex items-center justify-between">
          <div>
            <p className="font-mono text-[11px] tracking-[0.16em] text-cyan uppercase">
              Pairing debug
            </p>
            <h2 className="font-display text-xl font-semibold text-fg">Tuner DPI</h2>
          </div>
          <Button variant="ghost" size="icon" aria-label="Tutup" onClick={() => close(false)}>
            <X />
          </Button>
        </div>

        <p className="mt-3 text-sm text-muted text-pretty">
          DPI di sini mengubah kepadatan HUD dan sebaran tembakan di arena —
          tanpa membuka opsi pengembang perangkat. Minta kode lewat notifikasi,
          lalu masukkan 6 digit.
        </p>

        {banner ? (
          <div className="mt-4 flex items-start gap-3 rounded-[var(--radius-md)] bg-elevated p-3 shadow-[var(--shadow-border)]">
            <Bell className="mt-0.5 size-4 shrink-0 text-cyan" />
            <div>
              <p className="text-xs font-medium text-fg">Notifikasi NEXUS</p>
              <p className="font-mono text-sm tracking-[0.2em] text-cyan">{banner}</p>
            </div>
          </div>
        ) : null}

        {!unlocked ? (
          <div className="mt-4 space-y-3">
            <Button variant="cyan" className="w-full" onClick={() => void requestPairing()}>
              <Bell />
              Minta kode pairing
            </Button>
            <p className="text-xs text-subtle">
              Status notifikasi: {notifPerm === "granted" ? "aktif" : notifPerm === "denied" ? "diblokir, kode tetap di banner" : "belum diminta"}
            </p>
            <label className="block text-xs text-muted" htmlFor="pair-code">
              Masukkan kode
            </label>
            <input
              id="pair-code"
              inputMode="numeric"
              autoComplete="one-time-code"
              value={pairingInput}
              onChange={(e) => setPairingInput(e.target.value)}
              placeholder="000000"
              className="h-12 w-full rounded-[var(--radius-md)] bg-elevated px-4 text-center font-mono text-lg tracking-[0.4em] text-fg outline-none shadow-[var(--shadow-border)] placeholder:text-subtle"
            />
            <Button className="w-full" onClick={submitPairing} disabled={pairingInput.length !== 6}>
              Buka tuner
            </Button>
          </div>
        ) : (
          <div className="mt-5">
            <div className="mb-2 flex items-center justify-between text-sm">
              <span className="text-muted">DPI arena</span>
              <span className="font-mono tabular-nums text-cyan">{dpi}</span>
            </div>
            <Slider label="DPI" min={280} max={640} step={10} value={dpi} onChange={setDpi} />
            <div className="mt-3 grid grid-cols-3 gap-2">
              {[320, 420, 560].map((v) => (
                <button
                  key={v}
                  type="button"
                  onClick={() => setDpi(v)}
                  className="h-9 rounded-[var(--radius-sm)] font-mono text-xs shadow-[var(--shadow-border)]"
                  style={{
                    background: dpi === v ? "var(--color-cyan)" : "var(--color-elevated)",
                    color: dpi === v ? "var(--color-bg)" : "var(--color-fg)",
                  }}
                >
                  {v}
                </button>
              ))}
            </div>
            <p className="mt-3 text-xs text-subtle">
              Lebih tinggi = overlay lebih rapat, sebaran tembakan lebih ketat.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
