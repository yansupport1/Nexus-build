import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/macro_config.dart';

class MacroScreen extends StatefulWidget {
  final MacroConfig config;
  final Function(MacroConfig) onUpdate;

  const MacroScreen({
    Key? key,
    required this.config,
    required this.onUpdate,
  }) : super(key: key);

  @override
  State<MacroScreen> createState() => _MacroScreenState();
}

class _MacroScreenState extends State<MacroScreen> {
  late MacroConfig _config;
  bool _isTesting = false;
  String? _testLog;

  @override
  void initState() {
    super.initState();
    _config = widget.config;
  }

  void _notifyUpdate() {
    setState(() {});
    widget.onUpdate(_config);
  }

  void _testTrigger() async {
    setState(() {
      _isTesting = true;
      _testLog = 'Mengeksekusi combo ${_config.comboTitle}...';
    });

    HapticFeedback.heavyImpact();
    await Future.delayed(Duration(milliseconds: _config.speedMs * 4));

    if (mounted) {
      HapticFeedback.mediumImpact();
      setState(() {
        _isTesting = false;
        _testLog = '✓ Sukses! Selesai dalam ${_config.speedMs}ms latency!';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF07090E),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0B0F17),
        title: const Text(
          'PENGATURAN MAKRO OVERLAY',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 14,
            fontFamily: 'monospace',
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Banner
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: const Color(0xFF2B1805),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: Colors.amberAccent.withOpacity(0.5)),
            ),
            child: Row(
              children: [
                const Icon(Icons.flash_on, color: Colors.amberAccent, size: 32),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const [
                      Text(
                        'FLOATING MACRO ENGINE',
                        style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13, fontFamily: 'monospace'),
                      ),
                      SizedBox(height: 2),
                      Text(
                        'Tombol melayang di atas Free Fire. Atur kebesaran tombol dan milidetik kecepatan respon.',
                        style: TextStyle(color: Colors.white70, fontSize: 11),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),

          // 1. Kebesaran Button Slider
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: const Color(0xFF0E131E),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.white12),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'KE BESARAN BUTTON MAKRO',
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12, fontFamily: 'monospace'),
                    ),
                    Text(
                      '${_config.buttonSize.toInt()}px',
                      style: const TextStyle(color: Colors.amberAccent, fontWeight: FontWeight.bold, fontFamily: 'monospace'),
                    ),
                  ],
                ),
                Slider(
                  value: _config.buttonSize,
                  min: 36,
                  max: 96,
                  activeColor: Colors.amberAccent,
                  inactiveColor: Colors.white12,
                  onChanged: (val) {
                    _config.buttonSize = val;
                    _notifyUpdate();
                  },
                ),
                Center(
                  child: Container(
                    width: _config.buttonSize,
                    height: _config.buttonSize,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: const LinearGradient(
                        colors: [Color(0xFFF59E0B), Color(0xFFD97706)],
                      ),
                      border: Border.all(color: Colors.amberAccent, width: 2),
                    ),
                    child: Center(
                      child: Icon(Icons.flash_on, color: Colors.white, size: _config.buttonSize * 0.45),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          // 2. Kecepatan Makro (Delay ms)
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: const Color(0xFF0E131E),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.white12),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'KECEPATAN MAKRO (SPEED DELAY)',
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12, fontFamily: 'monospace'),
                    ),
                    Text(
                      '${_config.speedMs} ms',
                      style: const TextStyle(color: Colors.amberAccent, fontWeight: FontWeight.bold, fontFamily: 'monospace'),
                    ),
                  ],
                ),
                Slider(
                  value: _config.speedMs.toDouble(),
                  min: 5,
                  max: 150,
                  divisions: 29,
                  activeColor: Colors.amberAccent,
                  inactiveColor: Colors.white12,
                  onChanged: (val) {
                    _config.speedMs = val.toInt();
                    _notifyUpdate();
                  },
                ),
                Row(
                  children: [5, 15, 30, 60].map((ms) {
                    final isSel = _config.speedMs == ms;
                    return Expanded(
                      child: GestureDetector(
                        onTap: () {
                          _config.speedMs = ms;
                          _notifyUpdate();
                        },
                        child: Container(
                          margin: const EdgeInsets.symmetric(horizontal: 4),
                          padding: const EdgeInsets.symmetric(vertical: 6),
                          decoration: BoxDecoration(
                            color: isSel ? Colors.amberAccent.withOpacity(0.2) : Colors.black,
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(color: isSel ? Colors.amberAccent : Colors.white12),
                          ),
                          child: Center(
                            child: Text(
                              '${ms}ms',
                              style: TextStyle(
                                color: isSel ? Colors.amberAccent : Colors.white60,
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'monospace',
                              ),
                            ),
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          // 3. Preset Combo
          const Text(
            'PRESET COMBO FREE FIRE',
            style: TextStyle(color: Colors.white70, fontSize: 11, fontFamily: 'monospace', fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),

          ...MacroComboType.values.map((combo) {
            final isSel = _config.comboType == combo;
            final itemConfig = MacroConfig(comboType: combo);

            return GestureDetector(
              onTap: () {
                _config.comboType = combo;
                _notifyUpdate();
              },
              child: Container(
                margin: const EdgeInsets.only(bottom: 8),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: isSel ? const Color(0x33F59E0B) : const Color(0xFF0E131E),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: isSel ? Colors.amberAccent : Colors.white12),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          itemConfig.comboTitle,
                          style: TextStyle(
                            color: isSel ? Colors.amberAccent : Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 12,
                          ),
                        ),
                        if (isSel) const Icon(Icons.check, color: Colors.amberAccent, size: 16),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      itemConfig.comboSequence,
                      style: const TextStyle(color: Colors.white54, fontSize: 10, fontFamily: 'monospace'),
                    ),
                  ],
                ),
              ),
            );
          }).toList(),
          const SizedBox(height: 16),

          // 4. Test Button
          ElevatedButton.icon(
            onPressed: _testTrigger,
            icon: Icon(_isTesting ? Icons.hourglass_top : Icons.flash_on),
            label: Text(_isTesting ? 'MENGEKSEKUSI ${_config.speedMs}ms...' : 'TES RESPON TOMBOL MAKRO'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.amberAccent,
              foregroundColor: Colors.black,
              padding: const EdgeInsets.symmetric(vertical: 14),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              textStyle: const TextStyle(fontWeight: FontWeight.bold, fontFamily: 'monospace'),
            ),
          ),
          if (_testLog != null)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text(
                _testLog!,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Color(0xFF10B981), fontSize: 11, fontFamily: 'monospace', fontWeight: FontWeight.bold),
              ),
            ),
        ],
      ),
    );
  }
}
