enum RogOverlayMode {
  compactBar,
  expandedHud,
}

class RogOverlayConfig {
  bool enabled;
  RogOverlayMode mode;
  bool showFps;
  bool showCpu;
  bool showGpu;
  bool showThermals;
  bool showRam;
  bool showPing;
  bool showTouchRate;
  double opacity;
  double posX;
  double posY;

  RogOverlayConfig({
    this.enabled = true,
    this.mode = RogOverlayMode.compactBar,
    this.showFps = true,
    this.showCpu = true,
    this.showGpu = true,
    this.showThermals = true,
    this.showRam = true,
    this.showPing = true,
    this.showTouchRate = true,
    this.opacity = 0.94,
    this.posX = 20.0,
    this.posY = 60.0,
  });
}
