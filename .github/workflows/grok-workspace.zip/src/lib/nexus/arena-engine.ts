import { drawCrosshair } from "./crosshair-draw";
import type { CrosshairConfig } from "./types";

export type ArenaStats = {
  score: number;
  hits: number;
  shots: number;
  combo: number;
  cps: number;
  wave: number;
  alive: number;
  firing: boolean;
};

type Enemy = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  hp: number;
  kind: 0 | 1 | 2;
  spin: number;
};

type Shot = { x: number; y: number; vx: number; vy: number; life: number };
type Spark = { x: number; y: number; vx: number; vy: number; life: number; max: number; hue: number };

export type ArenaApi = {
  setAim: (x: number, y: number) => void;
  startFire: () => void;
  stopFire: () => void;
  setDpi: (dpi: number) => void;
  setSpeedMs: (ms: number) => void;
  setCrosshair: (cfg: CrosshairConfig | null) => void;
  resize: () => void;
  destroy: () => void;
  getStats: () => ArenaStats;
  pulse: () => void;
};

type Listener = (stats: ArenaStats) => void;

export function createArena(
  canvas: HTMLCanvasElement,
  bg: HTMLImageElement | null,
  onStats?: Listener,
): ArenaApi {
  const raw = canvas.getContext("2d");
  if (!raw) {
    throw new Error("Canvas 2D tidak tersedia");
  }
  const ctx: CanvasRenderingContext2D = raw;

  let w = 1;
  let h = 1;
  let dpr = 1;
  let running = true;
  let last = performance.now();
  let accFire = 0;
  let firing = false;
  let dpi = 420;
  let speedMs = 15;
  let aimX = 0.5;
  let aimY = 0.45;
  let crosshair: CrosshairConfig | null = null;
  let spawnAcc = 0;
  let wave = 1;
  let waveAcc = 0;
  let score = 0;
  let hits = 0;
  let shots = 0;
  let combo = 0;
  let cpsWindow: number[] = [];
  let pulse = 0;
  let shipX = 0.5;
  const enemies: Enemy[] = [];
  const bullets: Shot[] = [];
  const sparks: Spark[] = [];
  const stars = Array.from({ length: 90 }, () => ({
    x: Math.random(),
    y: Math.random(),
    z: 0.25 + Math.random() * 0.75,
    p: Math.random() * Math.PI * 2,
  }));

  function resize() {
    const rect = canvas.getBoundingClientRect();
    dpr = Math.min(2, window.devicePixelRatio || 1);
    w = Math.max(1, rect.width);
    h = Math.max(1, rect.height);
    canvas.width = Math.floor(w * dpr);
    canvas.height = Math.floor(h * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  function spread() {
    return Math.max(0, (520 - dpi) / 28);
  }

  function emitSparks(x: number, y: number, n: number, hue: number) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const s = 40 + Math.random() * 160;
      sparks.push({
        x,
        y,
        vx: Math.cos(a) * s,
        vy: Math.sin(a) * s,
        life: 0.18 + Math.random() * 0.28,
        max: 0.4,
        hue,
      });
    }
  }

  function fireOnce() {
    const px = shipX * w;
    const py = h - 72;
    const tx = aimX * w;
    const ty = aimY * h;
    const dx = tx - px;
    const dy = ty - py;
    const len = Math.hypot(dx, dy) || 1;
    const sp = spread();
    const jx = (Math.random() - 0.5) * sp;
    const jy = (Math.random() - 0.5) * sp;
    const vx = (dx / len) * 920 + jx * 12;
    const vy = (dy / len) * 920 + jy * 12;
    bullets.push({ x: px, y: py - 8, vx, vy, life: 0.9 });
    shots += 1;
    const now = performance.now();
    cpsWindow.push(now);
    emitSparks(px, py - 10, 3, 190);
  }

  function spawnEnemy() {
    const fromTop = Math.random() > 0.35;
    const kind = (Math.random() < 0.15 ? 2 : Math.random() < 0.45 ? 1 : 0) as 0 | 1 | 2;
    const r = kind === 2 ? 18 : kind === 1 ? 14 : 11;
    const x = fromTop ? 0.08 + Math.random() * 0.84 : Math.random() < 0.5 ? -0.04 : 1.04;
    const y = fromTop ? -0.06 : 0.08 + Math.random() * 0.45;
    const tx = 0.2 + Math.random() * 0.6;
    const ty = 0.25 + Math.random() * 0.4;
    const speed = (38 + wave * 8 + Math.random() * 30) * (kind === 2 ? 0.7 : 1);
    const dx = tx - x;
    const dy = ty - y;
    const len = Math.hypot(dx, dy) || 1;
    enemies.push({
      x,
      y,
      vx: (dx / len) * (speed / Math.max(w, 1)),
      vy: (dy / len) * (speed / Math.max(h, 1)),
      r,
      hp: kind === 2 ? 4 : kind === 1 ? 2 : 1,
      kind,
      spin: Math.random() * Math.PI * 2,
    });
  }

  function stats(): ArenaStats {
    const now = performance.now();
    cpsWindow = cpsWindow.filter((t) => now - t < 1000);
    return {
      score,
      hits,
      shots,
      combo,
      cps: cpsWindow.length,
      wave,
      alive: enemies.length,
      firing,
    };
  }

  function hitTest() {
    for (let i = bullets.length - 1; i >= 0; i--) {
      const b = bullets[i];
      for (let j = enemies.length - 1; j >= 0; j--) {
        const e = enemies[j];
        const ex = e.x * w;
        const ey = e.y * h;
        if (Math.hypot(b.x - ex, b.y - ey) < e.r + 4) {
          e.hp -= 1;
          bullets.splice(i, 1);
          emitSparks(b.x, b.y, 6, 180);
          if (e.hp <= 0) {
            enemies.splice(j, 1);
            hits += 1;
            combo += 1;
            score += 10 + combo * 2 + e.kind * 8;
            emitSparks(ex, ey, 16, e.kind === 2 ? 12 : 175);
          }
          break;
        }
      }
    }
  }

  function drawShip(t: number) {
    const x = shipX * w;
    const y = h - 64;
    ctx.save();
    ctx.translate(x, y);
    ctx.strokeStyle = "rgba(0, 212, 255, 0.85)";
    ctx.fillStyle = "rgba(8, 14, 24, 0.9)";
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.moveTo(0, -22);
    ctx.lineTo(16, 14);
    ctx.lineTo(0, 6);
    ctx.lineTo(-16, 14);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(-10, 10);
    ctx.lineTo(-18, 20);
    ctx.moveTo(10, 10);
    ctx.lineTo(18, 20);
    ctx.stroke();
    if (firing) {
      ctx.globalAlpha = 0.55 + Math.sin(t * 40) * 0.25;
      ctx.fillStyle = "#7DD3FC";
      ctx.beginPath();
      ctx.moveTo(-4, 8);
      ctx.lineTo(0, 22 + Math.random() * 8);
      ctx.lineTo(4, 8);
      ctx.fill();
    }
    ctx.restore();
  }

  function drawEnemy(e: Enemy, t: number) {
    const x = e.x * w;
    const y = e.y * h;
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(e.spin + t * (e.kind === 2 ? 0.6 : 1.4));
    ctx.strokeStyle = e.kind === 2 ? "rgba(239,68,68,0.9)" : "rgba(125,211,252,0.85)";
    ctx.fillStyle = "rgba(10, 14, 22, 0.72)";
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    if (e.kind === 2) {
      for (let i = 0; i < 6; i++) {
        const a = (i / 6) * Math.PI * 2;
        const px = Math.cos(a) * e.r;
        const py = Math.sin(a) * e.r;
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.closePath();
    } else if (e.kind === 1) {
      ctx.moveTo(0, -e.r);
      ctx.lineTo(e.r, e.r * 0.7);
      ctx.lineTo(-e.r, e.r * 0.7);
      ctx.closePath();
    } else {
      ctx.rect(-e.r, -e.r * 0.55, e.r * 2, e.r * 1.1);
    }
    ctx.fill();
    ctx.stroke();
    ctx.restore();
  }

  function frame(now: number) {
    if (!running) return;
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;

    if (firing) {
      accFire += dt * 1000;
      const interval = Math.max(5, speedMs);
      while (accFire >= interval) {
        accFire -= interval;
        fireOnce();
      }
    } else {
      accFire = 0;
      combo = Math.max(0, combo - dt * 2);
    }

    spawnAcc += dt;
    const spawnEvery = Math.max(0.45, 1.15 - wave * 0.06);
    if (spawnAcc >= spawnEvery && enemies.length < 10 + wave) {
      spawnAcc = 0;
      spawnEnemy();
    }
    waveAcc += dt;
    if (waveAcc > 18) {
      waveAcc = 0;
      wave += 1;
    }

    shipX += (aimX - shipX) * Math.min(1, dt * 3.2);

    for (const e of enemies) {
      e.x += e.vx * dt * 60;
      e.y += e.vy * dt * 60;
      e.spin += dt;
      if (e.x < -0.12 || e.x > 1.12 || e.y > 1.12) {
        e.x = 0.1 + Math.random() * 0.8;
        e.y = -0.08;
        e.vy = Math.abs(e.vy);
      }
    }

    for (let i = bullets.length - 1; i >= 0; i--) {
      const b = bullets[i];
      b.x += b.vx * dt;
      b.y += b.vy * dt;
      b.life -= dt;
      if (b.life <= 0 || b.x < -40 || b.x > w + 40 || b.y < -40 || b.y > h + 40) {
        bullets.splice(i, 1);
      }
    }
    hitTest();

    for (let i = sparks.length - 1; i >= 0; i--) {
      const s = sparks[i];
      s.x += s.vx * dt;
      s.y += s.vy * dt;
      s.vx *= 0.96;
      s.vy *= 0.96;
      s.life -= dt;
      if (s.life <= 0) sparks.splice(i, 1);
    }

    pulse = Math.max(0, pulse - dt);

    ctx.clearRect(0, 0, w, h);
    if (bg && bg.complete && bg.naturalWidth) {
      const iw = bg.naturalWidth;
      const ih = bg.naturalHeight;
      const scale = Math.max(w / iw, h / ih);
      const dw = iw * scale;
      const dh = ih * scale;
      ctx.globalAlpha = 0.55;
      ctx.drawImage(bg, (w - dw) / 2, (h - dh) / 2, dw, dh);
      ctx.globalAlpha = 1;
    } else {
      ctx.fillStyle = "#07090E";
      ctx.fillRect(0, 0, w, h);
    }

    const g = ctx.createRadialGradient(w * 0.5, h * 0.35, 20, w * 0.5, h * 0.5, Math.max(w, h) * 0.7);
    g.addColorStop(0, "rgba(7,10,16,0.15)");
    g.addColorStop(1, "rgba(4,6,10,0.72)");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, h);

    ctx.save();
    for (const s of stars) {
      const tw = 0.35 + Math.sin(now * 0.002 + s.p) * 0.25;
      ctx.globalAlpha = tw * s.z;
      ctx.fillStyle = "#E8EEF8";
      ctx.fillRect(s.x * w, (s.y * h + now * 0.006 * s.z) % h, s.z * 1.6, s.z * 1.6);
    }
    ctx.restore();

    for (const e of enemies) drawEnemy(e, now / 1000);
    ctx.save();
    ctx.strokeStyle = "rgba(0,212,255,0.85)";
    ctx.lineWidth = 1.4;
    for (const b of bullets) {
      ctx.beginPath();
      ctx.moveTo(b.x, b.y);
      ctx.lineTo(b.x - b.vx * 0.018, b.y - b.vy * 0.018);
      ctx.stroke();
    }
    ctx.restore();

    for (const s of sparks) {
      ctx.globalAlpha = Math.max(0, s.life / s.max);
      ctx.fillStyle = `hsl(${s.hue} 90% 70%)`;
      ctx.fillRect(s.x, s.y, 2.2, 2.2);
    }
    ctx.globalAlpha = 1;

    drawShip(now / 1000);

    if (crosshair) {
      drawCrosshair(ctx, aimX * w, aimY * h, crosshair);
    }

    if (pulse > 0) {
      ctx.fillStyle = `rgba(232,238,248,${pulse * 0.08})`;
      ctx.fillRect(0, 0, w, h);
    }

    onStats?.(stats());
    requestAnimationFrame(frame);
  }

  resize();
  requestAnimationFrame(frame);

  return {
    setAim: (x, y) => {
      aimX = Math.min(0.96, Math.max(0.04, x));
      aimY = Math.min(0.9, Math.max(0.08, y));
    },
    startFire: () => {
      firing = true;
      accFire = speedMs;
    },
    stopFire: () => {
      firing = false;
    },
    setDpi: (v) => {
      dpi = v;
    },
    setSpeedMs: (v) => {
      speedMs = v;
    },
    setCrosshair: (cfg) => {
      crosshair = cfg;
    },
    resize,
    destroy: () => {
      running = false;
    },
    getStats: stats,
    pulse: () => {
      pulse = 1;
    },
  };
}
