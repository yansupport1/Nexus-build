import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import '../models/rog_overlay_config.dart';

class RogTelemetryHud extends StatefulWidget {
  final RogOverlayConfig config;
  final Function(RogOverlayConfig) onUpdateConfig;
  final VoidCallback onFlushRam;

  const RogTelemetryHud({
    Key? key,
    required this.config,
    required this.onUpdateConfig,
    required this.onFlushRam,
  }) : super(key: key);

  @override
  State<RogTelemetryHud> createState() => _RogTelemetryHudState();
}

class _RogTelemetryHudState extends State<RogTelemetryHud> {
  late double _x;
  late double _y;
  int _fps = 119;
  double _temp = 36.4;
  double _cpu = 18.2;
  int _ping = 18;
  Timer? _ticker;

  @override
  void initState() {
    super.initState();
    _x = widget.config.posX;
    _y = widget.config.posY;

    // Simulate real-time hardware telemetry variations
    _ticker = Timer.periodic(const Duration(milliseconds: 1200), (timer) {
      if (mounted) {
        setState(() {
          final rand = Random();
          _fps = 118 + rand.nextInt(3); // 118-120 FPS
          _temp = 36.2 + rand.nextDouble() * 0.5;
          _cpu = 16.0 + rand.nextDouble() * 4.0;
          _ping = 16 + rand.nextInt(5);
        });
      }
    });
  }

  @override
  void dispose() {
    _ticker?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.config.enabled) return const SizedBox.shrink();

    return Positioned(
      left: _x,
      top: _y,
      child: GestureDetector(
        onPanUpdate: (details) {
          setState(() {
            _x += details.delta.dx;
            _y += details.delta.dy;
          });
          widget.config.posX = _x;
          widget.config.posY = _y;
          widget.onUpdateConfig(widget.config);
        },
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(
            color: const Color(0xE60A0D14),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: const Color(0x66EF4444), width: 1),
            boxShadow: const [
              BoxShadow(
                color: Color(0x33EF4444),
                blurRadius: 10,
                spreadRadius: 1,
              )
            ],
          ),
          child: widget.config.mode == RogOverlayMode.compactBar
              ? Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: Color(0xFFEF4444),
                      ),
                    ),
                    const SizedBox(width: 6),
                    _buildStatItem('FPS', '$_fps', const Color(0xFF10B981)),
                    _buildDivider(),
                    _buildStatItem('CPU', '${_cpu.toStringAsFixed(0)}%', Colors.cyanAccent),
                    _buildDivider(),
                    _buildStatItem('TEMP', '${_temp.toStringAsFixed(1)}°C', Colors.amberAccent),
                    _buildDivider(),
                    _buildStatItem('PING', '${_ping}ms', const Color(0xFF38BDF8)),
                  ],
                )
              : Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.shield, color: Color(0xFFEF4444), size: 12),
                        const SizedBox(width: 4),
                        const Text(
                          'ROG ARMOURY CRATE',
                          style: TextStyle(
                            color: Color(0xFFEF4444),
                            fontSize: 9,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'monospace',
                          ),
                        ),
                        const SizedBox(width: 8),
                        GestureDetector(
                          onTap: widget.onFlushRam,
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                            decoration: BoxDecoration(
                              color: const Color(0x3310B981),
                              borderRadius: BorderRadius.circular(4),
                              border: Border.all(color: const Color(0xFF10B981), width: 0.5),
                            ),
                            child: const Text(
                              'FLUSH RAM',
                              style: TextStyle(color: Color(0xFF10B981), fontSize: 8, fontFamily: 'monospace'),
                            ),
                          ),
                        )
                      ],
                    ),
                    const SizedBox(height: 6),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        _buildStatItem('FPS', '$_fps', const Color(0xFF10B981)),
                        const SizedBox(width: 10),
                        _buildStatItem('CPU', '${_cpu.toStringAsFixed(1)}%', Colors.cyanAccent),
                        const SizedBox(width: 10),
                        _buildStatItem('TEMP', '${_temp.toStringAsFixed(1)}°C', Colors.amberAccent),
                        const SizedBox(width: 10),
                        _buildStatItem('RAM', '342MB', Colors.white70),
                      ],
                    ),
                  ],
                ),
        ),
      ),
    );
  }

  Widget _buildStatItem(String label, String value, Color valColor) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          '$label: ',
          style: const TextStyle(
            color: Colors.white54,
            fontSize: 10,
            fontFamily: 'monospace',
          ),
        ),
        Text(
          value,
          style: TextStyle(
            color: valColor,
            fontSize: 10,
            fontWeight: FontWeight.bold,
            fontFamily: 'monospace',
          ),
        ),
      ],
    );
  }

  Widget _buildDivider() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 8),
      width: 1,
      height: 10,
      color: Colors.white24,
    );
  }
}
