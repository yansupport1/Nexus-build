# Nexus Tools — Status Proyek & Cara Build APK

## Yang sudah saya perbaiki
1. **Struktur Flutter Android tidak lengkap** — folder `android/` di ZIP asli ternyata isinya proyek Kotlin/Jetpack Compose lain yang tidak nyambung sama sekali dengan kode Dart di `lib/` (tidak ada `android/app`, `AndroidManifest.xml`, `gradlew`, dll — jadi memang belum bisa di-build). File-file lama itu saya pindah ke folder `_unused_leftover_android_native_project/` (tidak dipakai build, aman diabaikan/dihapus).
2. Saya buat ulang struktur `android/app/` yang benar: `AndroidManifest.xml`, `MainActivity.kt`, `build.gradle`, `settings.gradle`, dll — dengan `applicationId com.yanz.nexustools` dan izin `SYSTEM_ALERT_WINDOW` + `FOREGROUND_SERVICE` (sesuai kebutuhan overlay di guide kamu).
3. **Icon aplikasi** sudah dipasang dari logo NEXUS yang kamu kirim — icon biasa (semua densitas mdpi–xxxhdpi) + adaptive icon (Android 8+).
4. **Tampilan saja** yang saya ubah: warna tema di `lib/main.dart` (merah → biru/cyan sesuai logo). Semua logic overlay, macro, crosshair, HUD (`overlay_service.dart`, `floating_macro_button.dart`, `rog_telemetry_hud.dart`, dst) **tidak saya sentuh sama sekali**.

## Yang TIDAK bisa saya lakukan di sini
Saya tidak punya Flutter SDK, Android SDK, ataupun akses internet di environment ini — jadi saya **tidak bisa mengompilasi file .apk jadi** untuk dikirim langsung. Yang saya kirim adalah **source project yang sudah lengkap dan siap build**, bukan file .apk.

## Cara build APK (1 perintah, di laptop/PC kamu)
1. Install Flutter SDK (flutter.dev) kalau belum ada.
2. Extract ZIP ini, buka terminal di folder project.
3. Jalankan:
```bash
flutter pub get
flutter build apk --release
```
4. APK ada di: `build/app/outputs/flutter-apk/app-release.apk`

Build ini pakai debug signing key sementara supaya langsung jalan — kalau mau upload ke Play Store, ganti `signingConfig` di `android/app/build.gradle` dengan keystore rilis kamu sendiri.

Alternatif kalau tidak mau install Flutter: pakai layanan build cloud seperti Codemagic, atau GitHub Actions dengan Flutter action.
