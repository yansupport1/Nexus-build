package com.example.utils

import android.content.Context
import android.util.DisplayMetrics
import android.view.WindowManager

data class ScreenSpecs(
    val currentDpi: Int,
    val widthPx: Int,
    val heightPx: Int,
    val refreshRateHz: Float,
    val densityMultiplier: Float,
    val smallestScreenWidthDp: Int
)

data class DpiPreset(
    val dpi: Int,
    val label: String,
    val description: String,
    val tag: String
)

object DpiHelper {
    val FREE_FIRE_PRESETS = listOf(
        DpiPreset(360, "Default Stock (360)", "Bawaan pabrik standar Android", "NORMAL"),
        DpiPreset(411, "Smooth Balanced (411)", "Gerakan kamera stabil untuk pemula", "STABLE"),
        DpiPreset(480, "Fast Drag Shot (480)", "Sensitivitas licin untuk swipe ke atas", "HEADSHOT"),
        DpiPreset(540, "One-Tap Precision (540)", "Rekomendasi pro player SG2 & Desert Eagle", "PRO META"),
        DpiPreset(600, "Ultra Speed Drag (600)", "Tarikan peluru ringan dan responsif", "ULTRA"),
        DpiPreset(720, "Insane 4-Finger Claw (720)", "Ruang pandang maksimal untuk refleks dewa", "HYPER")
    )

    fun getScreenSpecs(context: Context): ScreenSpecs {
        val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)

        @Suppress("DEPRECATION")
        val refreshRate = windowManager.defaultDisplay.refreshRate

        val widthDp = (metrics.widthPixels / metrics.density).toInt()
        val heightDp = (metrics.heightPixels / metrics.density).toInt()
        val smallestWidthDp = minOf(widthDp, heightDp)

        return ScreenSpecs(
            currentDpi = metrics.densityDpi,
            widthPx = metrics.widthPixels,
            heightPx = metrics.heightPixels,
            refreshRateHz = refreshRate,
            densityMultiplier = metrics.density,
            smallestScreenWidthDp = smallestWidthDp
        )
    }

    fun getAdbCommand(dpi: Int): String {
        return "adb shell wm density $dpi"
    }

    fun getResetAdbCommand(): String {
        return "adb shell wm density reset"
    }

    fun getShizukuCommand(dpi: Int): String {
        return "shizuku -c 'wm density $dpi'"
    }
}
