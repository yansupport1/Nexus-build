import { CrosshairMark } from "@/components/nexus/CrosshairMark";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { useNexus } from "@/lib/nexus/store";
import { CROSSHAIR_CATALOG, CROSSHAIR_COLORS } from "@/lib/nexus/types";
import { X } from "lucide-react";
import type { ReactNode } from "react";

export function CrosshairSettings() {
  const open = useNexus((s) => s.crosshairOpen);
  const cfg = useNexus((s) => s.crosshair);
  const patch = useNexus((s) => s.patchCrosshair);
  const close = useNexus((s) => s.setCrosshairOpen);

  if (!open) return null;

  return (
    <div className="nexus-sheet fixed inset-0 flex items-end justify-center bg-bg/80 sm:items-center sm:p-4">
      <div className="flex max-h-[92dvh] w-full max-w-lg flex-col rounded-t-[var(--radius-xl)] bg-surface shadow-[var(--shadow-border)] sm:rounded-[var(--radius-xl)]">
        <div className="flex items-center justify-between px-5 pt-5">
          <div>
            <p className="font-mono text-[11px] tracking-[0.16em] text-cyan uppercase">
              Triple-tap crosshair
            </p>
            <h2 className="font-display text-xl font-semibold text-fg">
              Full setting reticle
            </h2>
          </div>
          <Button variant="ghost" size="icon" aria-label="Tutup" onClick={() => close(false)}>
            <X />
          </Button>
        </div>

        <div className="relative mx-5 mt-4 flex h-32 items-center justify-center overflow-hidden rounded-[var(--radius-lg)] bg-bg shadow-[var(--shadow-border)]">
          <img
            src="/space-arena.jpg"
            alt=""
            className="absolute inset-0 h-full w-full object-cover opacity-40 outline-none"
          />
          <div className="relative">
            <CrosshairMark config={cfg} size={88} />
          </div>
        </div>

        <div className="min-h-0 flex-1 overflow-y-auto px-5 py-4">
          <p className="mb-2 font-mono text-[11px] font-medium tracking-[0.14em] text-muted uppercase">
            Warna
          </p>
          <div className="mb-5 flex gap-2">
            {CROSSHAIR_COLORS.map((c) => {
              const on = cfg.color.toLowerCase() === c.value.toLowerCase();
              return (
                <button
                  key={c.id}
                  type="button"
                  aria-label={c.label}
                  onClick={() => patch({ color: c.value })}
                  className="size-8 rounded-full shadow-[var(--shadow-border)]"
                  style={{
                    background: c.value,
                    outline: on ? "2px solid var(--color-fg)" : "2px solid transparent",
                    outlineOffset: 2,
                  }}
                />
              );
            })}
          </div>

          <Row label="Ukuran" value={`${Math.round(cfg.size)} px`}>
            <Slider label="Ukuran" min={12} max={72} value={cfg.size} onChange={(v) => patch({ size: v })} />
          </Row>
          <Row label="Tebal" value={`${cfg.thickness.toFixed(1)}`}>
            <Slider
              label="Tebal"
              min={1}
              max={5}
              step={0.5}
              value={cfg.thickness}
              onChange={(v) => patch({ thickness: v })}
            />
          </Row>
          <Row label="Celah" value={`${Math.round(cfg.gap)} px`}>
            <Slider label="Gap" min={0} max={16} value={cfg.gap} onChange={(v) => patch({ gap: v })} />
          </Row>
          <Row label="Opacity" value={`${Math.round(cfg.opacity * 100)}%`}>
            <Slider
              label="Opacity"
              min={0.35}
              max={1}
              step={0.05}
              value={cfg.opacity}
              onChange={(v) => patch({ opacity: v })}
            />
          </Row>

          <div className="mb-4 flex items-center justify-between rounded-[var(--radius-md)] bg-elevated px-3 py-3 shadow-[var(--shadow-border)]">
            <div>
              <p className="text-sm font-medium text-fg">Kunci posisi</p>
              <p className="text-xs text-muted">Off = geser reticle. On = pin.</p>
            </div>
            <Switch checked={cfg.locked} onCheckedChange={(v) => patch({ locked: v })} label="Kunci" />
          </div>

          <p className="mb-2 font-mono text-[11px] font-medium tracking-[0.14em] text-muted uppercase">
            Katalog reticle
          </p>
          <div className="space-y-2 pb-4">
            {CROSSHAIR_CATALOG.map((item) => {
              const on = cfg.style === item.style;
              return (
                <button
                  key={item.style}
                  type="button"
                  onClick={() => patch({ style: item.style })}
                  className="flex w-full items-center gap-3 rounded-[var(--radius-md)] bg-elevated p-3 text-left shadow-[var(--shadow-border)]"
                  style={{
                    boxShadow: on
                      ? "0 0 0 1px color-mix(in oklab, var(--color-cyan) 55%, transparent)"
                      : undefined,
                  }}
                >
                  <div className="flex size-12 items-center justify-center rounded-[var(--radius-sm)] bg-bg">
                    <CrosshairMark
                      config={{ ...cfg, style: item.style, size: 26, thickness: 2, gap: 5 }}
                      size={40}
                    />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium text-fg">{item.name}</p>
                    <p className="font-mono text-[10px] text-cyan">{item.weapon}</p>
                    <p className="text-xs text-muted">{item.desc}</p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

function Row({
  label,
  value,
  children,
}: {
  label: string;
  value: string;
  children: ReactNode;
}) {
  return (
    <div className="mb-3">
      <div className="mb-1 flex items-center justify-between text-sm">
        <span className="text-muted">{label}</span>
        <span className="font-mono tabular-nums text-cyan">{value}</span>
      </div>
      {children}
    </div>
  );
}
