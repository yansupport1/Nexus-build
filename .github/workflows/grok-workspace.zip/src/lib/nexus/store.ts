import { create } from "zustand";
import {
  DEFAULT_CROSSHAIR,
  DEFAULT_HUD,
  DEFAULT_MACRO,
  DEFAULT_ORB,
  type AppView,
  type CrosshairConfig,
  type HudConfig,
  type MacroCombo,
  type MacroConfig,
  type OverlayOrb,
  type PermState,
  type ProfileId,
} from "./types";

const STORAGE_KEY = "nexus-tools-v1";

export interface Toast {
  id: number;
  text: string;
  tone: "ok" | "warn" | "info";
}

interface PersistShape {
  overlayPerm: PermState;
  notifPerm: PermState;
  overlayActive: boolean;
  dpiUnlocked: boolean;
  dpi: number;
  profile: ProfileId;
  crosshair: CrosshairConfig;
  macro: MacroConfig;
  hud: HudConfig;
  orb: OverlayOrb;
}

interface NexusState extends PersistShape {
  view: AppView;
  permOpen: boolean;
  permStep: "overlay" | "notif";
  menuOpen: boolean;
  crosshairOpen: boolean;
  macroOpen: boolean;
  dpiOpen: boolean;
  pairingCode: string | null;
  pairingInput: string;
  pairingBanner: string | null;
  firing: boolean;
  clickCount: number;
  clicksThisHold: number;
  toasts: Toast[];
  hydrated: boolean;

  hydrate: () => void;
  persist: () => void;
  setView: (view: AppView) => void;
  openPermissions: (step?: "overlay" | "notif") => void;
  closePermissions: () => void;
  grantOverlay: () => void;
  denyOverlay: () => void;
  grantNotif: () => Promise<void>;
  skipNotif: () => void;
  toggleOverlay: () => void;
  setOverlayActive: (on: boolean) => void;
  setMenuOpen: (open: boolean) => void;
  toggleMenu: () => void;
  setCrosshairOpen: (open: boolean) => void;
  setMacroOpen: (open: boolean) => void;
  setDpiOpen: (open: boolean) => void;
  patchCrosshair: (patch: Partial<CrosshairConfig>) => void;
  patchMacro: (patch: Partial<MacroConfig>) => void;
  patchHud: (patch: Partial<HudConfig>) => void;
  setOrb: (orb: OverlayOrb) => void;
  setProfile: (profile: ProfileId) => void;
  startFire: () => void;
  stopFire: () => void;
  registerClicks: (n: number) => void;
  requestPairing: () => Promise<void>;
  setPairingInput: (v: string) => void;
  submitPairing: () => void;
  setDpi: (dpi: number) => void;
  toast: (text: string, tone?: Toast["tone"]) => void;
  dismissToast: (id: number) => void;
  flushRam: () => void;
}

function readPersist(): Partial<PersistShape> | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as Partial<PersistShape>;
  } catch {
    return null;
  }
}

function pickPersist(s: NexusState): PersistShape {
  return {
    overlayPerm: s.overlayPerm,
    notifPerm: s.notifPerm,
    overlayActive: s.overlayActive,
    dpiUnlocked: s.dpiUnlocked,
    dpi: s.dpi,
    profile: s.profile,
    crosshair: s.crosshair,
    macro: s.macro,
    hud: s.hud,
    orb: s.orb,
  };
}

let toastSeq = 1;
let toastTimers = new Map<number, number>();

function sixDigit() {
  return String(100000 + Math.floor(Math.random() * 900000));
}

export const useNexus = create<NexusState>((set, get) => ({
  overlayPerm: "needed",
  notifPerm: "needed",
  overlayActive: false,
  dpiUnlocked: false,
  dpi: 420,
  profile: "BEAST",
  crosshair: { ...DEFAULT_CROSSHAIR },
  macro: { ...DEFAULT_MACRO },
  hud: { ...DEFAULT_HUD },
  orb: { ...DEFAULT_ORB },
  view: "hub",
  permOpen: true,
  permStep: "overlay",
  menuOpen: false,
  crosshairOpen: false,
  macroOpen: false,
  dpiOpen: false,
  pairingCode: null,
  pairingInput: "",
  pairingBanner: null,
  firing: false,
  clickCount: 0,
  clicksThisHold: 0,
  toasts: [],
  hydrated: false,

  hydrate: () => {
    const saved = readPersist();
    if (!saved) {
      set({
        hydrated: true,
        permOpen: true,
        permStep: "overlay",
      });
      return;
    }
    set({
      overlayPerm: saved.overlayPerm ?? "needed",
      notifPerm: saved.notifPerm ?? "needed",
      overlayActive: saved.overlayActive ?? false,
      dpiUnlocked: saved.dpiUnlocked ?? false,
      dpi: saved.dpi ?? 420,
      profile: saved.profile ?? "BEAST",
      crosshair: { ...DEFAULT_CROSSHAIR, ...saved.crosshair },
      macro: { ...DEFAULT_MACRO, ...saved.macro },
      hud: { ...DEFAULT_HUD, ...saved.hud },
      orb: { ...DEFAULT_ORB, ...saved.orb },
      permOpen: saved.overlayPerm !== "granted",
      permStep: "overlay",
      hydrated: true,
    });
  },

  persist: () => {
    if (typeof window === "undefined") return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(pickPersist(get())));
    } catch {
      /* ignore quota */
    }
  },

  setView: (view) => set({ view, menuOpen: false }),

  openPermissions: (step = "overlay") => set({ permOpen: true, permStep: step }),
  closePermissions: () => set({ permOpen: false }),

  grantOverlay: () => {
    set({
      overlayPerm: "granted",
      overlayActive: true,
      permStep: "notif",
    });
    get().persist();
    get().toast("Overlay diizinkan. Crosshair dan menu siap muncul.", "ok");
  },

  denyOverlay: () => {
    set({ overlayPerm: "denied", overlayActive: false, permOpen: false });
    get().persist();
    get().toast("Tanpa izin overlay, crosshair dan menu tidak bisa tampil.", "warn");
  },

  grantNotif: async () => {
    let granted = false;
    try {
      if (typeof Notification !== "undefined") {
        const res = await Notification.requestPermission();
        granted = res === "granted";
      }
    } catch {
      granted = false;
    }
    set({
      notifPerm: granted ? "granted" : "denied",
      permOpen: false,
    });
    get().persist();
    get().toast(
      granted
        ? "Notifikasi aktif. Kode pairing DPI bisa dikirim ke banner."
        : "Notifikasi diblokir. Kode pairing tetap muncul di dalam app.",
      granted ? "ok" : "info",
    );
  },

  skipNotif: () => {
    set({ permOpen: false });
    get().toast("Bisa aktifkan notifikasi nanti dari panel DPI.", "info");
  },

  toggleOverlay: () => {
    const s = get();
    if (s.overlayPerm !== "granted") {
      set({ permOpen: true, permStep: "overlay" });
      return;
    }
    const next = !s.overlayActive;
    set({
      overlayActive: next,
      menuOpen: next ? s.menuOpen : false,
    });
    get().persist();
    get().toast(
      next
        ? "Overlay ON — crosshair, menu, dan makro muncul."
        : "Overlay OFF.",
      next ? "ok" : "info",
    );
  },

  setOverlayActive: (on) => {
    const s = get();
    if (on && s.overlayPerm !== "granted") {
      set({ permOpen: true, permStep: "overlay" });
      return;
    }
    set({ overlayActive: on, menuOpen: on ? s.menuOpen : false });
    get().persist();
  },

  setMenuOpen: (menuOpen) => set({ menuOpen }),
  toggleMenu: () => set({ menuOpen: !get().menuOpen }),
  setCrosshairOpen: (crosshairOpen) => set({ crosshairOpen, menuOpen: false }),
  setMacroOpen: (macroOpen) => set({ macroOpen, menuOpen: false }),
  setDpiOpen: (dpiOpen) => set({ dpiOpen, menuOpen: false }),

  patchCrosshair: (patch) => {
    set({ crosshair: { ...get().crosshair, ...patch } });
    get().persist();
  },
  patchMacro: (patch) => {
    set({ macro: { ...get().macro, ...patch } });
    get().persist();
  },
  patchHud: (patch) => {
    set({ hud: { ...get().hud, ...patch } });
    get().persist();
  },
  setOrb: (orb) => {
    set({ orb });
    get().persist();
  },
  setProfile: (profile) => {
    set({ profile });
    get().persist();
  },

  startFire: () => set({ firing: true, clicksThisHold: 0 }),
  stopFire: () => set({ firing: false }),
  registerClicks: (n) =>
    set((s) => ({
      clickCount: s.clickCount + n,
      clicksThisHold: s.clicksThisHold + n,
    })),

  requestPairing: async () => {
    const code = sixDigit();
    set({ pairingCode: code, pairingInput: "", pairingBanner: `Kode pairing DPI: ${code}` });
    const s = get();
    if (s.notifPerm === "granted" && typeof Notification !== "undefined") {
      try {
        new Notification("NEXUS Pairing Debug", {
          body: `Masukkan kode ${code} untuk membuka tuner DPI.`,
        });
      } catch {
        /* iframe / insecure */
      }
    } else if (typeof Notification !== "undefined") {
      try {
        const res = await Notification.requestPermission();
        const ok = res === "granted";
        set({ notifPerm: ok ? "granted" : "denied" });
        get().persist();
        if (ok) {
          new Notification("NEXUS Pairing Debug", {
            body: `Masukkan kode ${code} untuk membuka tuner DPI.`,
          });
        }
      } catch {
        set({ notifPerm: "denied" });
      }
    }
    get().toast("Kode pairing dikirim ke notifikasi.", "info");
  },

  setPairingInput: (pairingInput) => set({ pairingInput: pairingInput.replace(/\D/g, "").slice(0, 6) }),

  submitPairing: () => {
    const s = get();
    if (!s.pairingCode) {
      get().toast("Minta kode pairing dulu.", "warn");
      return;
    }
    if (s.pairingInput !== s.pairingCode) {
      get().toast("Kode salah. Cek banner notifikasi.", "warn");
      return;
    }
    set({
      dpiUnlocked: true,
      pairingBanner: null,
      pairingCode: null,
      pairingInput: "",
    });
    get().persist();
    get().toast("DPI tuner terbuka. Sensitivitas arena bisa diubah.", "ok");
  },

  setDpi: (dpi) => {
    set({ dpi: Math.round(Math.min(640, Math.max(280, dpi))) });
    get().persist();
  },

  toast: (text, tone = "info") => {
    const id = toastSeq++;
    set((s) => ({ toasts: [...s.toasts.slice(-3), { id, text, tone }] }));
    if (typeof window !== "undefined") {
      const prev = toastTimers.get(id);
      if (prev) window.clearTimeout(prev);
      const t = window.setTimeout(() => get().dismissToast(id), 2800);
      toastTimers.set(id, t);
    }
  },

  dismissToast: (id) => {
    set((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) }));
  },

  flushRam: () => {
    get().toast("Buffer arena dibersihkan — 1.4 GB siap.", "ok");
  },
}));

export function comboTitle(combo: MacroCombo) {
  switch (combo) {
    case "glooWall":
      return "Fast Cover Drop";
    case "jumpShot":
      return "Jump Shot Swap";
    case "autoDragBurst":
      return "Auto Drag Burst";
    case "quickScope":
      return "Quick Scope Swap";
  }
}
