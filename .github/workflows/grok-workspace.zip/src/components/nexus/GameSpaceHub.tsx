import { Switch } from "@/components/ui/switch";
import { useNexus } from "@/lib/nexus/store";
import { cn } from "@/lib/utils";
import {
  Crosshair,
  Gauge,
  Play,
  Radio,
  Shield,
  Zap,
} from "lucide-react";
import type { ReactNode } from "react";

export function GameSpaceHub() {
  const overlayActive = useNexus((s) => s.overlayActive);
  const overlayPerm = useNexus((s) => s.overlayPerm);
  const notifPerm = useNexus((s) => s.notifPerm);
  const toggleOverlay = useNexus((s) => s.toggleOverlay);
  const profile = useNexus((s) => s.profile);
  const setProfile = useNexus((s) => s.setProfile);
  const setView = useNexus((s) => s.setView);
  const openC = useNexus((s) => s.setCrosshairOpen);
  const openM = useNexus((s) => s.setMacroOpen);
  const openD = useNexus((s) => s.setDpiOpen);
  const openPerm = useNexus((s) => s.openPermissions);
  const flush = useNexus((s) => s.flushRam);
  const macro = useNexus((s) => s.macro);
  const toast = useNexus((s) => s.toast);
  const dpiUnlocked = useNexus((s) => s.dpiUnlocked);

  function launch() {
    if (overlayPerm !== "granted") {
      openPerm("overlay");
      return;
    }
    if (!overlayActive) {
      useNexus.getState().setOverlayActive(true);
    }
    setView("arena");
    toast("Arena dibuka. Overlay tetap di atas pertandingan.", "ok");
  }

  return (
    <div className="relative min-h-dvh overflow-hidden bg-bg">
      <img
        src="/space-arena.jpg"
        alt=""
        className="pointer-events-none absolute inset-0 h-full w-full object-cover opacity-35 outline-none"
      />
      <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(180deg,rgba(7,9,14,0.55)_0%,rgba(7,9,14,0.88)_55%,rgba(7,9,14,1)_100%)]" />

      <div className="relative mx-auto flex min-h-dvh max-w-lg flex-col px-4 pt-[max(1rem,env(safe-area-inset-top))] pb-28">
        <header className="flex items-center gap-3 py-3">
          <img src="/nexus-logo.png" alt="" className="size-10 object-contain outline-none" />
          <div className="min-w-0 flex-1">
            <p className="font-mono text-[10px] tracking-[0.22em] text-cyan uppercase">
              Game Space
            </p>
            <h1 className="font-display text-xl font-semibold tracking-tight text-fg">
              NEXUS Tools
            </h1>
          </div>
          <button
            type="button"
            onClick={flush}
            className="rounded-[var(--radius-sm)] px-2 py-1 font-mono text-[10px] text-muted shadow-[var(--shadow-border)]"
          >
            FLUSH
          </button>
        </header>

        <div className="mb-4 grid grid-cols-3 gap-2">
          <Chip
            ok={overlayPerm === "granted"}
            label="Overlay"
            onClick={() => openPerm("overlay")}
          />
          <Chip
            ok={notifPerm === "granted"}
            label="Notif"
            onClick={() => openPerm("notif")}
          />
          <Chip ok={dpiUnlocked} label="DPI" onClick={() => openD(true)} />
        </div>

        <section className="rounded-[var(--radius-xl)] bg-surface/90 p-4 shadow-[var(--shadow-border)]">
          <div className="flex items-center justify-between gap-3">
            <div>
              <p className="font-mono text-[10px] tracking-[0.16em] text-cyan uppercase">
                Overlay master
              </p>
              <h2 className="font-display text-lg font-semibold text-fg">
                {overlayActive ? "Aktif di atas arena" : "Matikan / nyalakan"}
              </h2>
              <p className="mt-1 text-xs text-muted text-pretty">
                Saat ON: crosshair, tombol overlay, dan makro muncul. Menu
                lengkap terbuka dari tombol overlay.
              </p>
            </div>
            <Switch
              checked={overlayActive}
              onCheckedChange={() => toggleOverlay()}
              label="Aktifkan overlay"
            />
          </div>
        </section>

        <section className="mt-3 rounded-[var(--radius-xl)] bg-surface/90 p-4 shadow-[var(--shadow-border)]">
          <div className="mb-3 flex items-center justify-between">
            <p className="font-mono text-[11px] font-medium tracking-[0.14em] text-fg">
              Profil performa
            </p>
            <span className="rounded-[var(--radius-xs)] bg-elevated px-2 py-0.5 font-mono text-[9px] text-cyan">
              ENGINE
            </span>
          </div>
          <div className="grid grid-cols-3 gap-2">
            {(
              [
                ["BEAST", "120 FPS"],
                ["BALANCED", "90 FPS"],
                ["SAVER", "Hemat"],
              ] as const
            ).map(([id, sub]) => {
              const on = profile === id;
              return (
                <button
                  key={id}
                  type="button"
                  onClick={() => setProfile(id)}
                  className={cn(
                    "rounded-[var(--radius-md)] px-2 py-2.5 text-center shadow-[var(--shadow-border)]",
                    on ? "bg-elevated" : "bg-bg/60",
                  )}
                  style={
                    on
                      ? {
                          boxShadow:
                            "0 0 0 1px color-mix(in oklab, var(--color-cyan) 50%, transparent)",
                        }
                      : undefined
                  }
                >
                  <p className={cn("font-mono text-[11px] font-semibold", on ? "text-cyan" : "text-muted")}>
                    {id}
                  </p>
                  <p className="text-[10px] text-subtle">{sub}</p>
                </button>
              );
            })}
          </div>
        </section>

        <button
          type="button"
          onClick={launch}
          className="mt-3 flex w-full items-center gap-3 rounded-[var(--radius-xl)] bg-surface/90 p-4 text-left shadow-[var(--shadow-border)]"
        >
          <div className="flex size-12 items-center justify-center rounded-[var(--radius-md)] bg-elevated">
            <Shield className="size-5 text-cyan" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="font-display text-base font-semibold text-fg">NEXUS ARENA</p>
            <p className="font-mono text-[10px] text-cyan">SPACE OPS · 120 FPS LOCK</p>
            <p className="text-xs text-muted">Buka pertandingan. Overlay ikut di atas.</p>
          </div>
          <span className="inline-flex h-9 items-center gap-1 rounded-[var(--radius-sm)] bg-cyan px-3 font-medium text-bg">
            <Play className="size-3.5" />
            BUKA
          </span>
        </button>

        <p className="mt-4 mb-2 font-mono text-[11px] tracking-[0.14em] text-muted uppercase">
          Kontrol overlay
        </p>
        <div className="grid grid-cols-2 gap-2">
          <NavCard
            icon={<Crosshair className="size-5 text-cyan" />}
            title="Crosshair"
            sub="7 reticle · ketuk 3×"
            onClick={() => openC(true)}
          />
          <NavCard
            icon={<Zap className="size-5 text-cyan" />}
            title="Makro"
            sub={`${macro.speedMs}ms hold-fire`}
            onClick={() => openM(true)}
          />
          <NavCard
            icon={<Gauge className="size-5 text-cyan" />}
            title="DPI pairing"
            sub="Kode via notifikasi"
            onClick={() => openD(true)}
          />
          <NavCard
            icon={<Radio className="size-5 text-cyan" />}
            title="Izin"
            sub="Overlay + notif"
            onClick={() => openPerm("overlay")}
          />
        </div>

        <p className="mt-6 text-center text-[11px] leading-relaxed text-subtle text-pretty">
          Overlay berjalan di dalam NEXUS Arena. Tidak mengubah data game di
          perangkat. Browser tidak bisa menempel jendela di atas aplikasi lain.
        </p>
      </div>
    </div>
  );
}

function Chip({
  ok,
  label,
  onClick,
}: {
  ok: boolean;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex items-center justify-center gap-1.5 rounded-full bg-surface/80 px-2 py-1.5 font-mono text-[10px] shadow-[var(--shadow-border)]"
    >
      <span className={cn("size-1.5 rounded-full", ok ? "bg-ok" : "bg-danger")} />
      <span className="text-muted">{label}</span>
    </button>
  );
}

function NavCard({
  icon,
  title,
  sub,
  onClick,
}: {
  icon: ReactNode;
  title: string;
  sub: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="rounded-[var(--radius-lg)] bg-surface/90 p-3.5 text-left shadow-[var(--shadow-border)]"
    >
      {icon}
      <p className="mt-2 text-sm font-medium text-fg">{title}</p>
      <p className="text-xs text-muted">{sub}</p>
    </button>
  );
}
