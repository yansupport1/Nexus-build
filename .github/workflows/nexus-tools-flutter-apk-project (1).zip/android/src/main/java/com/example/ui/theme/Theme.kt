package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val NexusDarkColorScheme = darkColorScheme(
    primary = CyberCyan,
    onPrimary = CarbonDark,
    primaryContainer = SurfaceElevated,
    onPrimaryContainer = CyberCyan,
    secondary = CyberRed,
    onSecondary = CarbonDark,
    secondaryContainer = SurfaceElevated,
    onSecondaryContainer = CyberRed,
    tertiary = TacticalAmber,
    background = CarbonDark,
    onBackground = TextPrimary,
    surface = SurfaceDark,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceElevated,
    onSurfaceVariant = TextSecondary,
    outline = SurfaceBorder
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = NexusDarkColorScheme,
        typography = Typography,
        content = content
    )
}
