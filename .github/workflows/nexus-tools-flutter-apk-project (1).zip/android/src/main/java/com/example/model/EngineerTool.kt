package com.example.model

enum class ToolCategory(val title: String) {
    AIM_AND_DISPLAY("Aim & Visuals"),
    ENGINEERING_DPI("DPI & Performance"),
    NETWORK_HARDWARE("Network & Hardware"),
    TACTICAL_TACTICS("Tactical & Controls")
}

data class EngineerTool(
    val id: String,
    val title: String,
    val subtitle: String,
    val category: ToolCategory,
    val iconName: String,
    val badge: String = "ACTIVE",
    val description: String
)

val ALL_ENGINEER_TOOLS = listOf(
    EngineerTool(
        id = "tool_dpi",
        title = "DPI Engine (Overlay)",
        subtitle = "Ubah DPI tanpa buka opsi pengembang via Wireless Debug / Shizuku",
        category = ToolCategory.ENGINEERING_DPI,
        iconName = "Tune",
        badge = "CORE",
        description = "Ganti kerapatan layar (DPI) langsung dari overlay saat bermain Free Fire tanpa perlu bolak-balik ke Opsi Pengembang."
    ),
    EngineerTool(
        id = "tool_crosshair",
        title = "Crosshair Full Custom",
        subtitle = "16+ reticle styles + mode setting cepat dengan 3× tap",
        category = ToolCategory.AIM_AND_DISPLAY,
        iconName = "GpsFixed",
        badge = "CORE",
        description = "Overlay crosshair akurat anti-geser dengan fitur tap 3× untuk membuka quick setting HUD langsung di atas game."
    ),
    EngineerTool(
        id = "tool_sensitivity",
        title = "FF & FF Max Sens Calculator",
        subtitle = "Rekomendasi Sensitivitas One-Shot Headshot berbasis DPI",
        category = ToolCategory.AIM_AND_DISPLAY,
        iconName = "Speed",
        badge = "PRO",
        description = "Hitung sensitivitas presisi (Lihat Sekeliling, Red Dot, 2x, 4x, AWM) disesuaikan dengan DPI & refresh rate HP Anda."
    ),
    EngineerTool(
        id = "tool_ping",
        title = "Real-Time Ping & Jitter Tester",
        subtitle = "Tes latensi server Free Fire (ID, SG, BR, IN)",
        category = ToolCategory.NETWORK_HARDWARE,
        iconName = "WifiTethering",
        badge = "LIVE",
        description = "Pantau latensi ms real-time, variasi jitter, dan packet loss langsung ke gateway game server Free Fire."
    ),
    EngineerTool(
        id = "tool_dns",
        title = "Gaming DNS Benchmark",
        subtitle = "Bandingkan Cloudflare 1.1.1.1, Google 8.8.8.8, Quad9",
        category = ToolCategory.NETWORK_HARDWARE,
        iconName = "Dns",
        badge = "NET",
        description = "Ukur kecepatan respon DNS publik tercepat untuk mengurangi delay peluru dan registrasi hit di Free Fire."
    ),
    EngineerTool(
        id = "tool_ram",
        title = "RAM & Cache Game Booster",
        subtitle = "Pembersih memori latar belakang & Garbage Collector",
        category = ToolCategory.ENGINEERING_DPI,
        iconName = "Memory",
        badge = "OPTIMIZER",
        description = "Analisis RAM terpakai dan optimalkan alokasi memori sebelum dan saat bertempur di Ranked Match."
    ),
    EngineerTool(
        id = "tool_thermal",
        title = "Thermal & Battery Monitor",
        subtitle = "Suhu baterai (°C), voltase, dan status kesehatan",
        category = ToolCategory.NETWORK_HARDWARE,
        iconName = "Thermostat",
        badge = "HARDWARE",
        description = "Cegah thermal throttling chipset dengan memantau kenaikan suhu baterai dan konsumsi daya real-time."
    ),
    EngineerTool(
        id = "tool_fps",
        title = "FPS & Refresh Rate Meter",
        subtitle = "Monitor FPS Choreographer (60/90/120Hz)",
        category = ToolCategory.AIM_AND_DISPLAY,
        iconName = "MonitorHeart",
        badge = "OVERLAY",
        description = "Hitung frame rate aktual yang dirender layar menggunakan Android Choreographer frame callbacks."
    ),
    EngineerTool(
        id = "tool_touch",
        title = "Touch Latency & Multi-Touch Tester",
        subtitle = "Uji respon sentuhan & deteksi hingga 10 jari",
        category = ToolCategory.TACTICAL_TACTICS,
        iconName = "TouchApp",
        badge = "CALIBRATE",
        description = "Uji respon sensor layar sentuh, visualisasikan titik sentuh multi-finger claw, dan kalibrasi dead-center."
    ),
    EngineerTool(
        id = "tool_gyro",
        title = "Gyroscope & 3-Axis Calibrator",
        subtitle = "Sensor accelerometer & gyro zero-point test",
        category = ToolCategory.TACTICAL_TACTICS,
        iconName = "ScreenRotation",
        badge = "SENSOR",
        description = "Panduan kalibrasi kemiringan X, Y, Z untuk pemain Gyroscope Free Fire agar bidikan stabil tanpa getar (no drift)."
    ),
    EngineerTool(
        id = "tool_aspect",
        title = "Aspect Ratio & Notch Fixer",
        subtitle = "Kalkulator FOV layar penuh (16:9, 19.5:9, 20:9)",
        category = ToolCategory.AIM_AND_DISPLAY,
        iconName = "AspectRatio",
        badge = "DISPLAY",
        description = "Hitung resolusi optimal dan area safe-zone tombol agar UI Free Fire tidak terpotong punch-hole kamera."
    ),
    EngineerTool(
        id = "tool_claw_hud",
        title = "Claw HUD Layout Planner",
        subtitle = "Cetak biru tata letak 2, 3, dan 4 Jari Pro Player",
        category = ToolCategory.TACTICAL_TACTICS,
        iconName = "ViewQuilt",
        badge = "PRESETS",
        description = "Referensi ukuran tombol tembak, tombol lompat, dan analog untuk fast gloo wall dan drag headshot."
    ),
    EngineerTool(
        id = "tool_audio",
        title = "Footstep Audio Equalizer Guide",
        subtitle = "Panduan frekuensi 2kHz-4kHz & generator tes nada",
        category = ToolCategory.AIM_AND_DISPLAY,
        iconName = "GraphicEq",
        badge = "SOUND",
        description = "Pengaturan equalizer frekuensi tinggi untuk memperjelas derap langkah kaki musuh di sekeliling."
    ),
    EngineerTool(
        id = "tool_deadzone",
        title = "Anti-Touch Edge Deadzone",
        subtitle = "Cegah sentuhan telapak tangan (palm rejection)",
        category = ToolCategory.TACTICAL_TACTICS,
        iconName = "DoNotDisturbOn",
        badge = "SAFETY",
        description = "Simulator area tepi layar yang sensitif terhadap sentuhan telapak tangan saat memegang HP posisi claw."
    ),
    EngineerTool(
        id = "tool_notes",
        title = "Floating Match Callout Notes",
        subtitle = "Catatan melayang drop zone & taktik squad",
        category = ToolCategory.TACTICAL_TACTICS,
        iconName = "StickyNote2",
        badge = "SQUAD",
        description = "Notepad mini transparan di atas game untuk mencatat rotasi map Purgatory/Bermuda dan strategi tim."
    ),
    EngineerTool(
        id = "tool_launcher",
        title = "Direct Game Booster Launcher",
        subtitle = "Luncurkan Free Fire & FF Max dengan overlay aktif",
        category = ToolCategory.ENGINEERING_DPI,
        iconName = "RocketLaunch",
        badge = "FAST",
        description = "Deteksi instan APK Free Fire / Free Fire Max dan luncurkan langsung dengan overlay otomatis aktif."
    )
)
