import { drawCrosshair } from "@/lib/nexus/crosshair-draw";
import type { CrosshairConfig } from "@/lib/nexus/types";
import { useEffect, useRef } from "react";

export function CrosshairMark({
  config,
  size,
}: {
  config: Pick<CrosshairConfig, "style" | "color" | "size" | "thickness" | "gap" | "opacity">;
  size?: number;
}) {
  const ref = useRef<HTMLCanvasElement>(null);
  const dim = size ?? Math.ceil(config.size + 8);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    canvas.width = dim * dpr;
    canvas.height = dim * dpr;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, dim, dim);
    drawCrosshair(ctx, dim / 2, dim / 2, { ...config, size: Math.min(config.size, dim - 6) });
  }, [config, dim, config.style, config.color, config.size, config.thickness, config.gap, config.opacity]);

  return (
    <canvas
      ref={ref}
      width={dim}
      height={dim}
      className="block"
      style={{ width: dim, height: dim }}
      aria-hidden
    />
  );
}
