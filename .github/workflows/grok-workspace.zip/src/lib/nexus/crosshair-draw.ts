import type { CrosshairConfig, CrosshairStyle } from "./types";

export function drawCrosshair(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  config: Pick<CrosshairConfig, "style" | "color" | "size" | "thickness" | "gap" | "opacity">,
) {
  const { color, size, thickness, gap, opacity, style } = config;
  ctx.save();
  ctx.globalAlpha = opacity;
  ctx.strokeStyle = color;
  ctx.fillStyle = color;
  ctx.lineWidth = thickness;
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  const half = size / 2;

  switch (style) {
    case "dot":
      ctx.beginPath();
      ctx.arc(cx, cy, Math.max(1.6, thickness + 0.4), 0, Math.PI * 2);
      ctx.fill();
      break;
    case "classicCross":
      ctx.beginPath();
      ctx.moveTo(cx - half, cy);
      ctx.lineTo(cx + half, cy);
      ctx.moveTo(cx, cy - half);
      ctx.lineTo(cx, cy + half);
      ctx.stroke();
      break;
    case "gapCross":
      ctx.beginPath();
      ctx.moveTo(cx - half, cy);
      ctx.lineTo(cx - gap, cy);
      ctx.moveTo(cx + gap, cy);
      ctx.lineTo(cx + half, cy);
      ctx.moveTo(cx, cy - half);
      ctx.lineTo(cx, cy - gap);
      ctx.moveTo(cx, cy + gap);
      ctx.lineTo(cx, cy + half);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(cx, cy, 1.3, 0, Math.PI * 2);
      ctx.fill();
      break;
    case "shotgunRing":
      ctx.beginPath();
      ctx.arc(cx, cy, half, 0, Math.PI * 2);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(cx, cy, thickness + 0.6, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(cx - half - 4, cy);
      ctx.lineTo(cx - half + 2, cy);
      ctx.moveTo(cx + half - 2, cy);
      ctx.lineTo(cx + half + 4, cy);
      ctx.stroke();
      break;
    case "chevronSniper": {
      ctx.beginPath();
      ctx.moveTo(cx - half * 0.72, cy + half * 0.52);
      ctx.lineTo(cx, cy);
      ctx.lineTo(cx + half * 0.72, cy + half * 0.52);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(cx, cy, 1.1, 0, Math.PI * 2);
      ctx.fill();
      break;
    }
    case "predatorAim":
      for (let i = 0; i < 3; i++) {
        const a = ((i * 120 - 90) * Math.PI) / 180;
        ctx.beginPath();
        ctx.moveTo(cx, cy);
        ctx.lineTo(cx + half * Math.cos(a), cy + half * Math.sin(a));
        ctx.stroke();
      }
      ctx.beginPath();
      ctx.arc(cx, cy, 1.5, 0, Math.PI * 2);
      ctx.fill();
      break;
    case "cyberQuad": {
      const d = half * 0.82;
      const c = half * 0.38;
      const corners: [number, number][] = [
        [cx - d, cy - d],
        [cx + d, cy - d],
        [cx - d, cy + d],
        [cx + d, cy + d],
      ];
      corners.forEach(([x, y], i) => {
        const sx = i % 2 === 0 ? 1 : -1;
        const sy = i < 2 ? 1 : -1;
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.lineTo(x + c * sx, y);
        ctx.moveTo(x, y);
        ctx.lineTo(x, y + c * sy);
        ctx.stroke();
      });
      break;
    }
  }
  ctx.restore();
}

export function styleLabel(style: CrosshairStyle) {
  switch (style) {
    case "gapCross":
      return "Tactical Gap";
    case "shotgunRing":
      return "Shotgun Ring";
    case "chevronSniper":
      return "Chevron";
    case "dot":
      return "Dot";
    case "classicCross":
      return "Classic";
    case "predatorAim":
      return "Predator";
    case "cyberQuad":
      return "Cyber Quad";
  }
}
