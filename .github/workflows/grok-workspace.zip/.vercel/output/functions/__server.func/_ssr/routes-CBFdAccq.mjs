import { i as __toESM } from "../_runtime.mjs";
import { L as require_react, v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Shield, c as Play, d as Crosshair, f as Bell, i as Target, l as Layers, n as X, o as Settings, p as ArrowLeft, s as Radio, t as Zap, u as Gauge } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CBFdAccq.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium transition-[opacity,transform,background-color,box-shadow] duration-[var(--motion-quick)] ease-[var(--ease-out)] disabled:pointer-events-none disabled:opacity-40 [&_svg]:size-4 [&_svg]:shrink-0 select-none", {
	variants: {
		variant: {
			default: "bg-fg text-bg shadow-[var(--shadow-border)] hover:opacity-90 active:scale-[0.98]",
			secondary: "bg-elevated text-fg shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)] active:scale-[0.98]",
			ghost: "bg-transparent text-fg hover:bg-elevated",
			outline: "bg-transparent text-fg shadow-[var(--shadow-border)] hover:bg-elevated",
			cyan: "bg-cyan text-bg hover:opacity-90 active:scale-[0.98]",
			danger: "bg-danger text-fg hover:opacity-90 active:scale-[0.98]"
		},
		size: {
			default: "h-11 rounded-[var(--radius-md)] px-4 text-sm",
			sm: "h-9 rounded-[var(--radius-sm)] px-3 text-xs",
			lg: "h-12 rounded-[var(--radius-md)] px-5 text-sm",
			icon: "size-11 rounded-[var(--radius-md)]"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, type = "button", ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
	ref,
	type,
	className: cn(buttonVariants({
		variant,
		size
	}), className),
	...props
}));
Button.displayName = "Button";
function drawCrosshair(ctx, cx, cy, config) {
	const { color, size, thickness, gap, opacity, style } = config;
	ctx.save();
	ctx.globalAlpha = opacity;
	ctx.strokeStyle = color;
	ctx.fillStyle = color;
	ctx.lineWidth = thickness;
	ctx.lineCap = "round";
	ctx.lineJoin = "round";
	const half = size / 2;
	switch (style) {
		case "dot":
			ctx.beginPath();
			ctx.arc(cx, cy, Math.max(1.6, thickness + .4), 0, Math.PI * 2);
			ctx.fill();
			break;
		case "classicCross":
			ctx.beginPath();
			ctx.moveTo(cx - half, cy);
			ctx.lineTo(cx + half, cy);
			ctx.moveTo(cx, cy - half);
			ctx.lineTo(cx, cy + half);
			ctx.stroke();
			break;
		case "gapCross":
			ctx.beginPath();
			ctx.moveTo(cx - half, cy);
			ctx.lineTo(cx - gap, cy);
			ctx.moveTo(cx + gap, cy);
			ctx.lineTo(cx + half, cy);
			ctx.moveTo(cx, cy - half);
			ctx.lineTo(cx, cy - gap);
			ctx.moveTo(cx, cy + gap);
			ctx.lineTo(cx, cy + half);
			ctx.stroke();
			ctx.beginPath();
			ctx.arc(cx, cy, 1.3, 0, Math.PI * 2);
			ctx.fill();
			break;
		case "shotgunRing":
			ctx.beginPath();
			ctx.arc(cx, cy, half, 0, Math.PI * 2);
			ctx.stroke();
			ctx.beginPath();
			ctx.arc(cx, cy, thickness + .6, 0, Math.PI * 2);
			ctx.fill();
			ctx.beginPath();
			ctx.moveTo(cx - half - 4, cy);
			ctx.lineTo(cx - half + 2, cy);
			ctx.moveTo(cx + half - 2, cy);
			ctx.lineTo(cx + half + 4, cy);
			ctx.stroke();
			break;
		case "chevronSniper":
			ctx.beginPath();
			ctx.moveTo(cx - half * .72, cy + half * .52);
			ctx.lineTo(cx, cy);
			ctx.lineTo(cx + half * .72, cy + half * .52);
			ctx.stroke();
			ctx.beginPath();
			ctx.arc(cx, cy, 1.1, 0, Math.PI * 2);
			ctx.fill();
			break;
		case "predatorAim":
			for (let i = 0; i < 3; i++) {
				const a = (i * 120 - 90) * Math.PI / 180;
				ctx.beginPath();
				ctx.moveTo(cx, cy);
				ctx.lineTo(cx + half * Math.cos(a), cy + half * Math.sin(a));
				ctx.stroke();
			}
			ctx.beginPath();
			ctx.arc(cx, cy, 1.5, 0, Math.PI * 2);
			ctx.fill();
			break;
		case "cyberQuad": {
			const d = half * .82;
			const c = half * .38;
			[
				[cx - d, cy - d],
				[cx + d, cy - d],
				[cx - d, cy + d],
				[cx + d, cy + d]
			].forEach(([x, y], i) => {
				const sx = i % 2 === 0 ? 1 : -1;
				const sy = i < 2 ? 1 : -1;
				ctx.beginPath();
				ctx.moveTo(x, y);
				ctx.lineTo(x + c * sx, y);
				ctx.moveTo(x, y);
				ctx.lineTo(x, y + c * sy);
				ctx.stroke();
			});
			break;
		}
	}
	ctx.restore();
}
function createArena(canvas, bg, onStats) {
	const raw = canvas.getContext("2d");
	if (!raw) throw new Error("Canvas 2D tidak tersedia");
	const ctx = raw;
	let w = 1;
	let h = 1;
	let dpr = 1;
	let running = true;
	let last = performance.now();
	let accFire = 0;
	let firing = false;
	let dpi = 420;
	let speedMs = 15;
	let aimX = .5;
	let aimY = .45;
	let crosshair = null;
	let spawnAcc = 0;
	let wave = 1;
	let waveAcc = 0;
	let score = 0;
	let hits = 0;
	let shots = 0;
	let combo = 0;
	let cpsWindow = [];
	let pulse = 0;
	let shipX = .5;
	const enemies = [];
	const bullets = [];
	const sparks = [];
	const stars = Array.from({ length: 90 }, () => ({
		x: Math.random(),
		y: Math.random(),
		z: .25 + Math.random() * .75,
		p: Math.random() * Math.PI * 2
	}));
	function resize() {
		const rect = canvas.getBoundingClientRect();
		dpr = Math.min(2, window.devicePixelRatio || 1);
		w = Math.max(1, rect.width);
		h = Math.max(1, rect.height);
		canvas.width = Math.floor(w * dpr);
		canvas.height = Math.floor(h * dpr);
		ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
	}
	function spread() {
		return Math.max(0, (520 - dpi) / 28);
	}
	function emitSparks(x, y, n, hue) {
		for (let i = 0; i < n; i++) {
			const a = Math.random() * Math.PI * 2;
			const s = 40 + Math.random() * 160;
			sparks.push({
				x,
				y,
				vx: Math.cos(a) * s,
				vy: Math.sin(a) * s,
				life: .18 + Math.random() * .28,
				max: .4,
				hue
			});
		}
	}
	function fireOnce() {
		const px = shipX * w;
		const py = h - 72;
		const tx = aimX * w;
		const ty = aimY * h;
		const dx = tx - px;
		const dy = ty - py;
		const len = Math.hypot(dx, dy) || 1;
		const sp = spread();
		const jx = (Math.random() - .5) * sp;
		const jy = (Math.random() - .5) * sp;
		const vx = dx / len * 920 + jx * 12;
		const vy = dy / len * 920 + jy * 12;
		bullets.push({
			x: px,
			y: py - 8,
			vx,
			vy,
			life: .9
		});
		shots += 1;
		const now = performance.now();
		cpsWindow.push(now);
		emitSparks(px, py - 10, 3, 190);
	}
	function spawnEnemy() {
		const fromTop = Math.random() > .35;
		const kind = Math.random() < .15 ? 2 : Math.random() < .45 ? 1 : 0;
		const r = kind === 2 ? 18 : kind === 1 ? 14 : 11;
		const x = fromTop ? .08 + Math.random() * .84 : Math.random() < .5 ? -.04 : 1.04;
		const y = fromTop ? -.06 : .08 + Math.random() * .45;
		const tx = .2 + Math.random() * .6;
		const ty = .25 + Math.random() * .4;
		const speed = (38 + wave * 8 + Math.random() * 30) * (kind === 2 ? .7 : 1);
		const dx = tx - x;
		const dy = ty - y;
		const len = Math.hypot(dx, dy) || 1;
		enemies.push({
			x,
			y,
			vx: dx / len * (speed / Math.max(w, 1)),
			vy: dy / len * (speed / Math.max(h, 1)),
			r,
			hp: kind === 2 ? 4 : kind === 1 ? 2 : 1,
			kind,
			spin: Math.random() * Math.PI * 2
		});
	}
	function stats() {
		const now = performance.now();
		cpsWindow = cpsWindow.filter((t) => now - t < 1e3);
		return {
			score,
			hits,
			shots,
			combo,
			cps: cpsWindow.length,
			wave,
			alive: enemies.length,
			firing
		};
	}
	function hitTest() {
		for (let i = bullets.length - 1; i >= 0; i--) {
			const b = bullets[i];
			for (let j = enemies.length - 1; j >= 0; j--) {
				const e = enemies[j];
				const ex = e.x * w;
				const ey = e.y * h;
				if (Math.hypot(b.x - ex, b.y - ey) < e.r + 4) {
					e.hp -= 1;
					bullets.splice(i, 1);
					emitSparks(b.x, b.y, 6, 180);
					if (e.hp <= 0) {
						enemies.splice(j, 1);
						hits += 1;
						combo += 1;
						score += 10 + combo * 2 + e.kind * 8;
						emitSparks(ex, ey, 16, e.kind === 2 ? 12 : 175);
					}
					break;
				}
			}
		}
	}
	function drawShip(t) {
		const x = shipX * w;
		const y = h - 64;
		ctx.save();
		ctx.translate(x, y);
		ctx.strokeStyle = "rgba(0, 212, 255, 0.85)";
		ctx.fillStyle = "rgba(8, 14, 24, 0.9)";
		ctx.lineWidth = 1.6;
		ctx.beginPath();
		ctx.moveTo(0, -22);
		ctx.lineTo(16, 14);
		ctx.lineTo(0, 6);
		ctx.lineTo(-16, 14);
		ctx.closePath();
		ctx.fill();
		ctx.stroke();
		ctx.beginPath();
		ctx.moveTo(-10, 10);
		ctx.lineTo(-18, 20);
		ctx.moveTo(10, 10);
		ctx.lineTo(18, 20);
		ctx.stroke();
		if (firing) {
			ctx.globalAlpha = .55 + Math.sin(t * 40) * .25;
			ctx.fillStyle = "#7DD3FC";
			ctx.beginPath();
			ctx.moveTo(-4, 8);
			ctx.lineTo(0, 22 + Math.random() * 8);
			ctx.lineTo(4, 8);
			ctx.fill();
		}
		ctx.restore();
	}
	function drawEnemy(e, t) {
		const x = e.x * w;
		const y = e.y * h;
		ctx.save();
		ctx.translate(x, y);
		ctx.rotate(e.spin + t * (e.kind === 2 ? .6 : 1.4));
		ctx.strokeStyle = e.kind === 2 ? "rgba(239,68,68,0.9)" : "rgba(125,211,252,0.85)";
		ctx.fillStyle = "rgba(10, 14, 22, 0.72)";
		ctx.lineWidth = 1.4;
		ctx.beginPath();
		if (e.kind === 2) {
			for (let i = 0; i < 6; i++) {
				const a = i / 6 * Math.PI * 2;
				const px = Math.cos(a) * e.r;
				const py = Math.sin(a) * e.r;
				if (i === 0) ctx.moveTo(px, py);
				else ctx.lineTo(px, py);
			}
			ctx.closePath();
		} else if (e.kind === 1) {
			ctx.moveTo(0, -e.r);
			ctx.lineTo(e.r, e.r * .7);
			ctx.lineTo(-e.r, e.r * .7);
			ctx.closePath();
		} else ctx.rect(-e.r, -e.r * .55, e.r * 2, e.r * 1.1);
		ctx.fill();
		ctx.stroke();
		ctx.restore();
	}
	function frame(now) {
		if (!running) return;
		const dt = Math.min(.05, (now - last) / 1e3);
		last = now;
		if (firing) {
			accFire += dt * 1e3;
			const interval = Math.max(5, speedMs);
			while (accFire >= interval) {
				accFire -= interval;
				fireOnce();
			}
		} else {
			accFire = 0;
			combo = Math.max(0, combo - dt * 2);
		}
		spawnAcc += dt;
		const spawnEvery = Math.max(.45, 1.15 - wave * .06);
		if (spawnAcc >= spawnEvery && enemies.length < 10 + wave) {
			spawnAcc = 0;
			spawnEnemy();
		}
		waveAcc += dt;
		if (waveAcc > 18) {
			waveAcc = 0;
			wave += 1;
		}
		shipX += (aimX - shipX) * Math.min(1, dt * 3.2);
		for (const e of enemies) {
			e.x += e.vx * dt * 60;
			e.y += e.vy * dt * 60;
			e.spin += dt;
			if (e.x < -.12 || e.x > 1.12 || e.y > 1.12) {
				e.x = .1 + Math.random() * .8;
				e.y = -.08;
				e.vy = Math.abs(e.vy);
			}
		}
		for (let i = bullets.length - 1; i >= 0; i--) {
			const b = bullets[i];
			b.x += b.vx * dt;
			b.y += b.vy * dt;
			b.life -= dt;
			if (b.life <= 0 || b.x < -40 || b.x > w + 40 || b.y < -40 || b.y > h + 40) bullets.splice(i, 1);
		}
		hitTest();
		for (let i = sparks.length - 1; i >= 0; i--) {
			const s = sparks[i];
			s.x += s.vx * dt;
			s.y += s.vy * dt;
			s.vx *= .96;
			s.vy *= .96;
			s.life -= dt;
			if (s.life <= 0) sparks.splice(i, 1);
		}
		pulse = Math.max(0, pulse - dt);
		ctx.clearRect(0, 0, w, h);
		if (bg && bg.complete && bg.naturalWidth) {
			const iw = bg.naturalWidth;
			const ih = bg.naturalHeight;
			const scale = Math.max(w / iw, h / ih);
			const dw = iw * scale;
			const dh = ih * scale;
			ctx.globalAlpha = .55;
			ctx.drawImage(bg, (w - dw) / 2, (h - dh) / 2, dw, dh);
			ctx.globalAlpha = 1;
		} else {
			ctx.fillStyle = "#07090E";
			ctx.fillRect(0, 0, w, h);
		}
		const g = ctx.createRadialGradient(w * .5, h * .35, 20, w * .5, h * .5, Math.max(w, h) * .7);
		g.addColorStop(0, "rgba(7,10,16,0.15)");
		g.addColorStop(1, "rgba(4,6,10,0.72)");
		ctx.fillStyle = g;
		ctx.fillRect(0, 0, w, h);
		ctx.save();
		for (const s of stars) {
			const tw = .35 + Math.sin(now * .002 + s.p) * .25;
			ctx.globalAlpha = tw * s.z;
			ctx.fillStyle = "#E8EEF8";
			ctx.fillRect(s.x * w, (s.y * h + now * .006 * s.z) % h, s.z * 1.6, s.z * 1.6);
		}
		ctx.restore();
		for (const e of enemies) drawEnemy(e, now / 1e3);
		ctx.save();
		ctx.strokeStyle = "rgba(0,212,255,0.85)";
		ctx.lineWidth = 1.4;
		for (const b of bullets) {
			ctx.beginPath();
			ctx.moveTo(b.x, b.y);
			ctx.lineTo(b.x - b.vx * .018, b.y - b.vy * .018);
			ctx.stroke();
		}
		ctx.restore();
		for (const s of sparks) {
			ctx.globalAlpha = Math.max(0, s.life / s.max);
			ctx.fillStyle = `hsl(${s.hue} 90% 70%)`;
			ctx.fillRect(s.x, s.y, 2.2, 2.2);
		}
		ctx.globalAlpha = 1;
		drawShip(now / 1e3);
		if (crosshair) drawCrosshair(ctx, aimX * w, aimY * h, crosshair);
		if (pulse > 0) {
			ctx.fillStyle = `rgba(232,238,248,${pulse * .08})`;
			ctx.fillRect(0, 0, w, h);
		}
		onStats?.(stats());
		requestAnimationFrame(frame);
	}
	resize();
	requestAnimationFrame(frame);
	return {
		setAim: (x, y) => {
			aimX = Math.min(.96, Math.max(.04, x));
			aimY = Math.min(.9, Math.max(.08, y));
		},
		startFire: () => {
			firing = true;
			accFire = speedMs;
		},
		stopFire: () => {
			firing = false;
		},
		setDpi: (v) => {
			dpi = v;
		},
		setSpeedMs: (v) => {
			speedMs = v;
		},
		setCrosshair: (cfg) => {
			crosshair = cfg;
		},
		resize,
		destroy: () => {
			running = false;
		},
		getStats: stats,
		pulse: () => {
			pulse = 1;
		}
	};
}
var CROSSHAIR_COLORS = [
	{
		id: "cyan",
		value: "#00D4FF",
		label: "Cyan"
	},
	{
		id: "ice",
		value: "#E8EEF8",
		label: "Ice"
	},
	{
		id: "crimson",
		value: "#EF4444",
		label: "Crimson"
	},
	{
		id: "emerald",
		value: "#34D399",
		label: "Emerald"
	},
	{
		id: "steel",
		value: "#7DD3FC",
		label: "Steel"
	},
	{
		id: "white",
		value: "#FFFFFF",
		label: "White"
	}
];
var CROSSHAIR_CATALOG = [
	{
		style: "gapCross",
		name: "Tactical Gap Aim",
		weapon: "Semua senjata / AR & SMG",
		desc: "Empat garis dengan celah tengah presisi."
	},
	{
		style: "shotgunRing",
		name: "Shotgun Ring",
		weapon: "Spread close-range",
		desc: "Lingkaran sebaran pellet plus bead tengah."
	},
	{
		style: "chevronSniper",
		name: "Chevron Sniper",
		weapon: "Long range / 1-tap",
		desc: "Chevron V terbalik untuk titik kepala."
	},
	{
		style: "dot",
		name: "Precision Dot",
		weapon: "Pistol & burst",
		desc: "Titik tunggal tanpa menghalangi target."
	},
	{
		style: "classicCross",
		name: "Classic Cross",
		weapon: "SMG drag",
		desc: "Silang klasik, kestabilan visual tinggi."
	},
	{
		style: "predatorAim",
		name: "Predator Tri-HUD",
		weapon: "AR tracking",
		desc: "Tiga jari taktis untuk follow target."
	},
	{
		style: "cyberQuad",
		name: "Cyber Quad Brackets",
		weapon: "Frame target",
		desc: "Kurung empat sudut untuk mengunci siluet."
	}
];
var MACRO_COMBOS = [
	{
		id: "glooWall",
		title: "Fast Cover Drop",
		sequence: "Tembak → jongkok → taruh cover → ganti senjata"
	},
	{
		id: "jumpShot",
		title: "Jump Shot Swap",
		sequence: "Lompat → tembak → ganti senjata instan"
	},
	{
		id: "autoDragBurst",
		title: "Auto Drag Burst",
		sequence: "Burst vertikal beruntun saat tombol ditahan"
	},
	{
		id: "quickScope",
		title: "Quick Scope Swap",
		sequence: "Scope on → tembak → scope off cepat"
	}
];
var DEFAULT_CROSSHAIR = {
	enabled: true,
	style: "gapCross",
	color: "#00D4FF",
	size: 32,
	thickness: 2,
	gap: 6,
	opacity: 1,
	locked: false,
	x: .5,
	y: .48
};
var DEFAULT_MACRO = {
	enabled: true,
	buttonSize: 64,
	speedMs: 15,
	combo: "autoDragBurst",
	x: .86,
	y: .72
};
var DEFAULT_HUD = {
	enabled: true,
	expanded: false,
	x: .04,
	y: .08
};
var DEFAULT_ORB = {
	x: .08,
	y: .72
};
var STORAGE_KEY = "nexus-tools-v1";
function readPersist() {
	if (typeof window === "undefined") return null;
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (!raw) return null;
		return JSON.parse(raw);
	} catch {
		return null;
	}
}
function pickPersist(s) {
	return {
		overlayPerm: s.overlayPerm,
		notifPerm: s.notifPerm,
		overlayActive: s.overlayActive,
		dpiUnlocked: s.dpiUnlocked,
		dpi: s.dpi,
		profile: s.profile,
		crosshair: s.crosshair,
		macro: s.macro,
		hud: s.hud,
		orb: s.orb
	};
}
var toastSeq = 1;
var toastTimers = /* @__PURE__ */ new Map();
function sixDigit() {
	return String(1e5 + Math.floor(Math.random() * 9e5));
}
var useNexus = create((set, get) => ({
	overlayPerm: "needed",
	notifPerm: "needed",
	overlayActive: false,
	dpiUnlocked: false,
	dpi: 420,
	profile: "BEAST",
	crosshair: { ...DEFAULT_CROSSHAIR },
	macro: { ...DEFAULT_MACRO },
	hud: { ...DEFAULT_HUD },
	orb: { ...DEFAULT_ORB },
	view: "hub",
	permOpen: true,
	permStep: "overlay",
	menuOpen: false,
	crosshairOpen: false,
	macroOpen: false,
	dpiOpen: false,
	pairingCode: null,
	pairingInput: "",
	pairingBanner: null,
	firing: false,
	clickCount: 0,
	clicksThisHold: 0,
	toasts: [],
	hydrated: false,
	hydrate: () => {
		const saved = readPersist();
		if (!saved) {
			set({
				hydrated: true,
				permOpen: true,
				permStep: "overlay"
			});
			return;
		}
		set({
			overlayPerm: saved.overlayPerm ?? "needed",
			notifPerm: saved.notifPerm ?? "needed",
			overlayActive: saved.overlayActive ?? false,
			dpiUnlocked: saved.dpiUnlocked ?? false,
			dpi: saved.dpi ?? 420,
			profile: saved.profile ?? "BEAST",
			crosshair: {
				...DEFAULT_CROSSHAIR,
				...saved.crosshair
			},
			macro: {
				...DEFAULT_MACRO,
				...saved.macro
			},
			hud: {
				...DEFAULT_HUD,
				...saved.hud
			},
			orb: {
				...DEFAULT_ORB,
				...saved.orb
			},
			permOpen: saved.overlayPerm !== "granted",
			permStep: "overlay",
			hydrated: true
		});
	},
	persist: () => {
		if (typeof window === "undefined") return;
		try {
			localStorage.setItem(STORAGE_KEY, JSON.stringify(pickPersist(get())));
		} catch {}
	},
	setView: (view) => set({
		view,
		menuOpen: false
	}),
	openPermissions: (step = "overlay") => set({
		permOpen: true,
		permStep: step
	}),
	closePermissions: () => set({ permOpen: false }),
	grantOverlay: () => {
		set({
			overlayPerm: "granted",
			overlayActive: true,
			permStep: "notif"
		});
		get().persist();
		get().toast("Overlay diizinkan. Crosshair dan menu siap muncul.", "ok");
	},
	denyOverlay: () => {
		set({
			overlayPerm: "denied",
			overlayActive: false,
			permOpen: false
		});
		get().persist();
		get().toast("Tanpa izin overlay, crosshair dan menu tidak bisa tampil.", "warn");
	},
	grantNotif: async () => {
		let granted = false;
		try {
			if (typeof Notification !== "undefined") granted = await Notification.requestPermission() === "granted";
		} catch {
			granted = false;
		}
		set({
			notifPerm: granted ? "granted" : "denied",
			permOpen: false
		});
		get().persist();
		get().toast(granted ? "Notifikasi aktif. Kode pairing DPI bisa dikirim ke banner." : "Notifikasi diblokir. Kode pairing tetap muncul di dalam app.", granted ? "ok" : "info");
	},
	skipNotif: () => {
		set({ permOpen: false });
		get().toast("Bisa aktifkan notifikasi nanti dari panel DPI.", "info");
	},
	toggleOverlay: () => {
		const s = get();
		if (s.overlayPerm !== "granted") {
			set({
				permOpen: true,
				permStep: "overlay"
			});
			return;
		}
		const next = !s.overlayActive;
		set({
			overlayActive: next,
			menuOpen: next ? s.menuOpen : false
		});
		get().persist();
		get().toast(next ? "Overlay ON — crosshair, menu, dan makro muncul." : "Overlay OFF.", next ? "ok" : "info");
	},
	setOverlayActive: (on) => {
		const s = get();
		if (on && s.overlayPerm !== "granted") {
			set({
				permOpen: true,
				permStep: "overlay"
			});
			return;
		}
		set({
			overlayActive: on,
			menuOpen: on ? s.menuOpen : false
		});
		get().persist();
	},
	setMenuOpen: (menuOpen) => set({ menuOpen }),
	toggleMenu: () => set({ menuOpen: !get().menuOpen }),
	setCrosshairOpen: (crosshairOpen) => set({
		crosshairOpen,
		menuOpen: false
	}),
	setMacroOpen: (macroOpen) => set({
		macroOpen,
		menuOpen: false
	}),
	setDpiOpen: (dpiOpen) => set({
		dpiOpen,
		menuOpen: false
	}),
	patchCrosshair: (patch) => {
		set({ crosshair: {
			...get().crosshair,
			...patch
		} });
		get().persist();
	},
	patchMacro: (patch) => {
		set({ macro: {
			...get().macro,
			...patch
		} });
		get().persist();
	},
	patchHud: (patch) => {
		set({ hud: {
			...get().hud,
			...patch
		} });
		get().persist();
	},
	setOrb: (orb) => {
		set({ orb });
		get().persist();
	},
	setProfile: (profile) => {
		set({ profile });
		get().persist();
	},
	startFire: () => set({
		firing: true,
		clicksThisHold: 0
	}),
	stopFire: () => set({ firing: false }),
	registerClicks: (n) => set((s) => ({
		clickCount: s.clickCount + n,
		clicksThisHold: s.clicksThisHold + n
	})),
	requestPairing: async () => {
		const code = sixDigit();
		set({
			pairingCode: code,
			pairingInput: "",
			pairingBanner: `Kode pairing DPI: ${code}`
		});
		if (get().notifPerm === "granted" && typeof Notification !== "undefined") try {
			new Notification("NEXUS Pairing Debug", { body: `Masukkan kode ${code} untuk membuka tuner DPI.` });
		} catch {}
		else if (typeof Notification !== "undefined") try {
			const ok = await Notification.requestPermission() === "granted";
			set({ notifPerm: ok ? "granted" : "denied" });
			get().persist();
			if (ok) new Notification("NEXUS Pairing Debug", { body: `Masukkan kode ${code} untuk membuka tuner DPI.` });
		} catch {
			set({ notifPerm: "denied" });
		}
		get().toast("Kode pairing dikirim ke notifikasi.", "info");
	},
	setPairingInput: (pairingInput) => set({ pairingInput: pairingInput.replace(/\D/g, "").slice(0, 6) }),
	submitPairing: () => {
		const s = get();
		if (!s.pairingCode) {
			get().toast("Minta kode pairing dulu.", "warn");
			return;
		}
		if (s.pairingInput !== s.pairingCode) {
			get().toast("Kode salah. Cek banner notifikasi.", "warn");
			return;
		}
		set({
			dpiUnlocked: true,
			pairingBanner: null,
			pairingCode: null,
			pairingInput: ""
		});
		get().persist();
		get().toast("DPI tuner terbuka. Sensitivitas arena bisa diubah.", "ok");
	},
	setDpi: (dpi) => {
		set({ dpi: Math.round(Math.min(640, Math.max(280, dpi))) });
		get().persist();
	},
	toast: (text, tone = "info") => {
		const id = toastSeq++;
		set((s) => ({ toasts: [...s.toasts.slice(-3), {
			id,
			text,
			tone
		}] }));
		if (typeof window !== "undefined") {
			const prev = toastTimers.get(id);
			if (prev) window.clearTimeout(prev);
			const t = window.setTimeout(() => get().dismissToast(id), 2800);
			toastTimers.set(id, t);
		}
	},
	dismissToast: (id) => {
		set((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) }));
	},
	flushRam: () => {
		get().toast("Buffer arena dibersihkan — 1.4 GB siap.", "ok");
	}
}));
function comboTitle(combo) {
	switch (combo) {
		case "glooWall": return "Fast Cover Drop";
		case "jumpShot": return "Jump Shot Swap";
		case "autoDragBurst": return "Auto Drag Burst";
		case "quickScope": return "Quick Scope Swap";
	}
}
function ArenaView({ fireSignal }) {
	const canvasRef = (0, import_react.useRef)(null);
	const api = (0, import_react.useRef)(null);
	const [stats, setStats] = (0, import_react.useState)({
		score: 0,
		hits: 0,
		shots: 0,
		combo: 0,
		cps: 0,
		wave: 1,
		alive: 0,
		firing: false
	});
	const setView = useNexus((s) => s.setView);
	const overlayActive = useNexus((s) => s.overlayActive);
	const crosshair = useNexus((s) => s.crosshair);
	const dpi = useNexus((s) => s.dpi);
	const speedMs = useNexus((s) => s.macro.speedMs);
	const firing = useNexus((s) => s.firing);
	(0, import_react.useEffect)(() => {
		if (!canvasRef.current) return;
		const img = new Image();
		img.src = "/space-arena.jpg";
		img.crossOrigin = "anonymous";
		let engine = null;
		let cancelled = false;
		const boot = () => {
			if (cancelled || !canvasRef.current) return;
			engine = createArena(canvasRef.current, img.complete && img.naturalWidth ? img : null, setStats);
			api.current = engine;
			engine.setDpi(useNexus.getState().dpi);
			engine.setSpeedMs(useNexus.getState().macro.speedMs);
			engine.setCrosshair(null);
		};
		img.onload = boot;
		img.onerror = boot;
		if (img.complete) boot();
		const onResize = () => api.current?.resize();
		window.addEventListener("resize", onResize);
		return () => {
			cancelled = true;
			window.removeEventListener("resize", onResize);
			engine?.destroy();
			api.current = null;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		api.current?.setDpi(dpi);
	}, [dpi]);
	(0, import_react.useEffect)(() => {
		api.current?.setSpeedMs(speedMs);
	}, [speedMs]);
	(0, import_react.useEffect)(() => {
		if (fireSignal || firing) {
			const ch = useNexus.getState().crosshair;
			api.current?.setAim(ch.x, ch.y);
			api.current?.startFire();
		} else api.current?.stopFire();
	}, [
		fireSignal,
		firing,
		crosshair.x,
		crosshair.y
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative h-dvh w-full overflow-hidden bg-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: canvasRef,
				className: "block h-full w-full touch-none",
				onPointerMove: (e) => {
					const rect = e.currentTarget.getBoundingClientRect();
					api.current?.setAim((e.clientX - rect.left) / rect.width, (e.clientY - rect.top) / rect.height);
					if (!useNexus.getState().crosshair.locked) useNexus.getState().patchCrosshair({
						x: (e.clientX - rect.left) / rect.width,
						y: (e.clientY - rect.top) / rect.height
					});
				},
				onPointerDown: (e) => {
					const rect = e.currentTarget.getBoundingClientRect();
					api.current?.setAim((e.clientX - rect.left) / rect.width, (e.clientY - rect.top) / rect.height);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between p-3 pt-[max(0.75rem,env(safe-area-inset-top))]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "secondary",
					size: "sm",
					className: "pointer-events-auto",
					onClick: () => setView("hub"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, {}), " Hub"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-[var(--radius-md)] bg-bg/70 px-3 py-1.5 font-mono text-[11px] tabular-nums text-fg shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-subtle",
							children: "SCORE "
						}),
						stats.score,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mx-2 text-subtle",
							children: "·"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-subtle",
							children: "WAVE "
						}),
						stats.wave,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mx-2 text-subtle",
							children: "·"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-cyan",
							children: [stats.cps, " cps"]
						})
					]
				})]
			}),
			!overlayActive ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "pointer-events-none absolute bottom-8 left-1/2 w-[min(90%,20rem)] -translate-x-1/2 text-center text-xs text-muted",
				children: "Overlay mati. Nyalakan dari Hub supaya crosshair, menu, dan makro muncul."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "pointer-events-none absolute bottom-6 left-1/2 w-[min(90%,22rem)] -translate-x-1/2 text-center text-[11px] text-subtle",
				children: "Geser untuk aim. Tahan tombol makro untuk tembak cepat. Ketuk crosshair 3× untuk setting."
			})
		]
	});
}
function CrosshairMark({ config, size }) {
	const ref = (0, import_react.useRef)(null);
	const dim = size ?? Math.ceil(config.size + 8);
	(0, import_react.useEffect)(() => {
		const canvas = ref.current;
		if (!canvas) return;
		const dpr = Math.min(2, window.devicePixelRatio || 1);
		canvas.width = dim * dpr;
		canvas.height = dim * dpr;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
		ctx.clearRect(0, 0, dim, dim);
		drawCrosshair(ctx, dim / 2, dim / 2, {
			...config,
			size: Math.min(config.size, dim - 6)
		});
	}, [
		config,
		dim,
		config.style,
		config.color,
		config.size,
		config.thickness,
		config.gap,
		config.opacity
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
		ref,
		width: dim,
		height: dim,
		className: "block",
		style: {
			width: dim,
			height: dim
		},
		"aria-hidden": true
	});
}
function Slider({ value, min, max, step = 1, onChange, label }) {
	const pct = (value - min) / (max - min) * 100;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type: "range",
		"aria-label": label,
		min,
		max,
		step,
		value,
		onChange: (e) => onChange(Number(e.target.value)),
		className: cn("nexus-slider w-full"),
		style: { ["--p"]: `${pct}%` }
	});
}
function Switch({ checked, onCheckedChange, id, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		id,
		type: "button",
		role: "switch",
		"aria-checked": checked,
		"aria-label": label,
		onClick: () => onCheckedChange(!checked),
		className: cn("relative h-7 w-12 shrink-0 rounded-full transition-colors duration-[var(--motion-quick)] ease-[var(--ease-out)]", checked ? "bg-cyan" : "bg-elevated shadow-[var(--shadow-border)]"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("absolute top-0.5 size-6 rounded-full bg-fg transition-transform duration-[var(--motion-quick)] ease-[var(--ease-out)]", checked ? "translate-x-5" : "translate-x-0.5") })
	});
}
function CrosshairSettings() {
	const open = useNexus((s) => s.crosshairOpen);
	const cfg = useNexus((s) => s.crosshair);
	const patch = useNexus((s) => s.patchCrosshair);
	const close = useNexus((s) => s.setCrosshairOpen);
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-60 flex items-end justify-center bg-bg/70 sm:items-center sm:p-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex max-h-[92dvh] w-full max-w-lg flex-col rounded-t-[var(--radius-xl)] bg-surface shadow-[var(--shadow-border)] sm:rounded-[var(--radius-xl)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between px-5 pt-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-[11px] tracking-[0.16em] text-cyan uppercase",
						children: "Triple-tap crosshair"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-semibold text-fg",
						children: "Full setting reticle"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						"aria-label": "Tutup",
						onClick: () => close(false),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative mx-5 mt-4 flex h-32 items-center justify-center overflow-hidden rounded-[var(--radius-lg)] bg-bg shadow-[var(--shadow-border)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/space-arena.jpg",
						alt: "",
						className: "absolute inset-0 h-full w-full object-cover opacity-40"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "relative",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CrosshairMark, {
							config: cfg,
							size: 88
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-h-0 flex-1 overflow-y-auto px-5 py-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-2 font-mono text-[11px] font-medium tracking-[0.14em] text-muted uppercase",
							children: "Warna"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-5 flex gap-2",
							children: CROSSHAIR_COLORS.map((c) => {
								const on = cfg.color.toLowerCase() === c.value.toLowerCase();
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": c.label,
									onClick: () => patch({ color: c.value }),
									className: "size-8 rounded-full shadow-[var(--shadow-border)]",
									style: {
										background: c.value,
										outline: on ? "2px solid var(--color-fg)" : "2px solid transparent",
										outlineOffset: 2
									}
								}, c.id);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row$1, {
							label: "Ukuran",
							value: `${Math.round(cfg.size)} px`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
								label: "Ukuran",
								min: 12,
								max: 72,
								value: cfg.size,
								onChange: (v) => patch({ size: v })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row$1, {
							label: "Tebal",
							value: `${cfg.thickness.toFixed(1)}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
								label: "Tebal",
								min: 1,
								max: 5,
								step: .5,
								value: cfg.thickness,
								onChange: (v) => patch({ thickness: v })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row$1, {
							label: "Celah",
							value: `${Math.round(cfg.gap)} px`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
								label: "Gap",
								min: 0,
								max: 16,
								value: cfg.gap,
								onChange: (v) => patch({ gap: v })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row$1, {
							label: "Opacity",
							value: `${Math.round(cfg.opacity * 100)}%`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
								label: "Opacity",
								min: .35,
								max: 1,
								step: .05,
								value: cfg.opacity,
								onChange: (v) => patch({ opacity: v })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-4 flex items-center justify-between rounded-[var(--radius-md)] bg-elevated px-3 py-3 shadow-[var(--shadow-border)]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium text-fg",
								children: "Kunci posisi"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: "Off = geser reticle. On = pin."
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
								checked: cfg.locked,
								onCheckedChange: (v) => patch({ locked: v }),
								label: "Kunci"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-2 font-mono text-[11px] font-medium tracking-[0.14em] text-muted uppercase",
							children: "Katalog reticle"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-2 pb-4",
							children: CROSSHAIR_CATALOG.map((item) => {
								const on = cfg.style === item.style;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => patch({ style: item.style }),
									className: "flex w-full items-center gap-3 rounded-[var(--radius-md)] bg-elevated p-3 text-left shadow-[var(--shadow-border)]",
									style: { boxShadow: on ? "0 0 0 1px color-mix(in oklab, var(--color-cyan) 55%, transparent)" : void 0 },
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex size-12 items-center justify-center rounded-[var(--radius-sm)] bg-bg",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CrosshairMark, {
											config: {
												...cfg,
												style: item.style,
												size: 26,
												thickness: 2,
												gap: 5
											},
											size: 40
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0 flex-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm font-medium text-fg",
												children: item.name
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-mono text-[10px] text-cyan",
												children: item.weapon
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-muted",
												children: item.desc
											})
										]
									})]
								}, item.style);
							})
						})
					]
				})
			]
		})
	});
}
function Row$1({ label, value, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-1 flex items-center justify-between text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-muted",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-mono tabular-nums text-cyan",
				children: value
			})]
		}), children]
	});
}
function DpiPanel() {
	const open = useNexus((s) => s.dpiOpen);
	const close = useNexus((s) => s.setDpiOpen);
	const dpi = useNexus((s) => s.dpi);
	const setDpi = useNexus((s) => s.setDpi);
	const unlocked = useNexus((s) => s.dpiUnlocked);
	const pairingInput = useNexus((s) => s.pairingInput);
	const setPairingInput = useNexus((s) => s.setPairingInput);
	const requestPairing = useNexus((s) => s.requestPairing);
	const submitPairing = useNexus((s) => s.submitPairing);
	const banner = useNexus((s) => s.pairingBanner);
	const notifPerm = useNexus((s) => s.notifPerm);
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-60 flex items-end justify-center bg-bg/70 sm:items-center sm:p-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-lg rounded-t-[var(--radius-xl)] bg-surface p-5 shadow-[var(--shadow-border)] sm:rounded-[var(--radius-xl)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-[11px] tracking-[0.16em] text-cyan uppercase",
						children: "Pairing debug"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-semibold text-fg",
						children: "Tuner DPI"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						"aria-label": "Tutup",
						onClick: () => close(false),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted text-pretty",
					children: "DPI di sini mengubah kepadatan HUD dan sebaran tembakan di arena — tanpa membuka opsi pengembang perangkat. Minta kode lewat notifikasi, lalu masukkan 6 digit."
				}),
				banner ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex items-start gap-3 rounded-[var(--radius-md)] bg-elevated p-3 shadow-[var(--shadow-border)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "mt-0.5 size-4 shrink-0 text-cyan" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium text-fg",
						children: "Notifikasi NEXUS"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-sm tracking-[0.2em] text-cyan",
						children: banner
					})] })]
				}) : null,
				!unlocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "cyan",
							className: "w-full",
							onClick: () => void requestPairing(),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, {}), "Minta kode pairing"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-subtle",
							children: ["Status notifikasi: ", notifPerm === "granted" ? "aktif" : notifPerm === "denied" ? "diblokir, kode tetap di banner" : "belum diminta"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs text-muted",
							htmlFor: "pair-code",
							children: "Masukkan kode"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "pair-code",
							inputMode: "numeric",
							autoComplete: "one-time-code",
							value: pairingInput,
							onChange: (e) => setPairingInput(e.target.value),
							placeholder: "000000",
							className: "h-12 w-full rounded-[var(--radius-md)] bg-elevated px-4 text-center font-mono text-lg tracking-[0.4em] text-fg outline-none shadow-[var(--shadow-border)] placeholder:text-subtle"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "w-full",
							onClick: submitPairing,
							disabled: pairingInput.length !== 6,
							children: "Buka tuner"
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-2 flex items-center justify-between text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted",
								children: "DPI arena"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono tabular-nums text-cyan",
								children: dpi
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							label: "DPI",
							min: 280,
							max: 640,
							step: 10,
							value: dpi,
							onChange: setDpi
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 grid grid-cols-3 gap-2",
							children: [
								320,
								420,
								560
							].map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setDpi(v),
								className: "h-9 rounded-[var(--radius-sm)] font-mono text-xs shadow-[var(--shadow-border)]",
								style: {
									background: dpi === v ? "var(--color-cyan)" : "var(--color-elevated)",
									color: dpi === v ? "var(--color-bg)" : "var(--color-fg)"
								},
								children: v
							}, v))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-xs text-subtle",
							children: "Lebih tinggi = overlay lebih rapat, sebaran tembakan lebih ketat."
						})
					]
				})
			]
		})
	});
}
function GameSpaceHub() {
	const overlayActive = useNexus((s) => s.overlayActive);
	const overlayPerm = useNexus((s) => s.overlayPerm);
	const notifPerm = useNexus((s) => s.notifPerm);
	const toggleOverlay = useNexus((s) => s.toggleOverlay);
	const profile = useNexus((s) => s.profile);
	const setProfile = useNexus((s) => s.setProfile);
	const setView = useNexus((s) => s.setView);
	const openC = useNexus((s) => s.setCrosshairOpen);
	const openM = useNexus((s) => s.setMacroOpen);
	const openD = useNexus((s) => s.setDpiOpen);
	const openPerm = useNexus((s) => s.openPermissions);
	const flush = useNexus((s) => s.flushRam);
	const macro = useNexus((s) => s.macro);
	const toast = useNexus((s) => s.toast);
	const dpiUnlocked = useNexus((s) => s.dpiUnlocked);
	function launch() {
		if (overlayPerm !== "granted") {
			openPerm("overlay");
			return;
		}
		if (!overlayActive) useNexus.getState().setOverlayActive(true);
		setView("arena");
		toast("Arena dibuka. Overlay tetap di atas pertandingan.", "ok");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative min-h-dvh overflow-hidden bg-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/space-arena.jpg",
				alt: "",
				className: "pointer-events-none absolute inset-0 h-full w-full object-cover opacity-35"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-[linear-gradient(180deg,rgba(7,9,14,0.55)_0%,rgba(7,9,14,0.88)_55%,rgba(7,9,14,1)_100%)]" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto flex min-h-dvh max-w-lg flex-col px-4 pt-[max(1rem,env(safe-area-inset-top))] pb-28",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "flex items-center gap-3 py-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/nexus-logo.png",
								alt: "",
								className: "size-10 object-contain"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-mono text-[10px] tracking-[0.22em] text-cyan uppercase",
									children: "Game Space"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: "font-display text-xl font-semibold tracking-tight text-fg",
									children: "NEXUS Tools"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: flush,
								className: "rounded-[var(--radius-sm)] px-2 py-1 font-mono text-[10px] text-muted shadow-[var(--shadow-border)]",
								children: "FLUSH"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-4 grid grid-cols-3 gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
								ok: overlayPerm === "granted",
								label: "Overlay",
								onClick: () => openPerm("overlay")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
								ok: notifPerm === "granted",
								label: "Notif",
								onClick: () => openPerm("notif")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
								ok: dpiUnlocked,
								label: "DPI",
								onClick: () => openD(true)
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "rounded-[var(--radius-xl)] bg-surface/90 p-4 shadow-[var(--shadow-border)]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-mono text-[10px] tracking-[0.16em] text-cyan uppercase",
									children: "Overlay master"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-lg font-semibold text-fg",
									children: overlayActive ? "Aktif di atas arena" : "Matikan / nyalakan"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs text-muted text-pretty",
									children: "Saat ON: crosshair, tombol overlay, dan makro muncul. Menu lengkap terbuka dari tombol overlay."
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
								checked: overlayActive,
								onCheckedChange: () => toggleOverlay(),
								label: "Aktifkan overlay"
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mt-3 rounded-[var(--radius-xl)] bg-surface/90 p-4 shadow-[var(--shadow-border)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-3 flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-mono text-[11px] font-medium tracking-[0.14em] text-fg",
								children: "Profil performa"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-[var(--radius-xs)] bg-elevated px-2 py-0.5 font-mono text-[9px] text-cyan",
								children: "ENGINE"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-3 gap-2",
							children: [
								["BEAST", "120 FPS"],
								["BALANCED", "90 FPS"],
								["SAVER", "Hemat"]
							].map(([id, sub]) => {
								const on = profile === id;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setProfile(id),
									className: cn("rounded-[var(--radius-md)] px-2 py-2.5 text-center shadow-[var(--shadow-border)]", on ? "bg-elevated" : "bg-bg/60"),
									style: on ? { boxShadow: "0 0 0 1px color-mix(in oklab, var(--color-cyan) 50%, transparent)" } : void 0,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: cn("font-mono text-[11px] font-semibold", on ? "text-cyan" : "text-muted"),
										children: id
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] text-subtle",
										children: sub
									})]
								}, id);
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: launch,
						className: "mt-3 flex w-full items-center gap-3 rounded-[var(--radius-xl)] bg-surface/90 p-4 text-left shadow-[var(--shadow-border)]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex size-12 items-center justify-center rounded-[var(--radius-md)] bg-elevated",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "size-5 text-cyan" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-display text-base font-semibold text-fg",
										children: "NEXUS ARENA"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-mono text-[10px] text-cyan",
										children: "SPACE OPS · 120 FPS LOCK"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted",
										children: "Buka pertandingan. Overlay ikut di atas."
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex h-9 items-center gap-1 rounded-[var(--radius-sm)] bg-cyan px-3 font-medium text-bg",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-3.5" }), "BUKA"]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 mb-2 font-mono text-[11px] tracking-[0.14em] text-muted uppercase",
						children: "Kontrol overlay"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavCard, {
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crosshair, { className: "size-5 text-cyan" }),
								title: "Crosshair",
								sub: "7 reticle · ketuk 3×",
								onClick: () => openC(true)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavCard, {
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "size-5 text-cyan" }),
								title: "Makro",
								sub: `${macro.speedMs}ms hold-fire`,
								onClick: () => openM(true)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavCard, {
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gauge, { className: "size-5 text-cyan" }),
								title: "DPI pairing",
								sub: "Kode via notifikasi",
								onClick: () => openD(true)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavCard, {
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, { className: "size-5 text-cyan" }),
								title: "Izin",
								sub: "Overlay + notif",
								onClick: () => openPerm("overlay")
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 text-center text-[11px] leading-relaxed text-subtle text-pretty",
						children: "Overlay berjalan di dalam NEXUS Arena. Tidak mengubah data game di perangkat. Browser tidak bisa menempel jendela di atas aplikasi lain."
					})
				]
			})
		]
	});
}
function Chip({ ok, label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: "flex items-center justify-center gap-1.5 rounded-full bg-surface/80 px-2 py-1.5 font-mono text-[10px] shadow-[var(--shadow-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-1.5 rounded-full", ok ? "bg-ok" : "bg-danger") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted",
			children: label
		})]
	});
}
function NavCard({ icon, title, sub, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: "rounded-[var(--radius-lg)] bg-surface/90 p-3.5 text-left shadow-[var(--shadow-border)]",
		children: [
			icon,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm font-medium text-fg",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: sub
			})
		]
	});
}
function MacroSettings() {
	const open = useNexus((s) => s.macroOpen);
	const cfg = useNexus((s) => s.macro);
	const patch = useNexus((s) => s.patchMacro);
	const close = useNexus((s) => s.setMacroOpen);
	const firing = useNexus((s) => s.firing);
	const clicks = useNexus((s) => s.clicksThisHold);
	const startFire = useNexus((s) => s.startFire);
	const stopFire = useNexus((s) => s.stopFire);
	const holdRef = (0, import_react.useRef)(null);
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-60 flex items-end justify-center bg-bg/70 sm:items-center sm:p-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex max-h-[92dvh] w-full max-w-lg flex-col rounded-t-[var(--radius-xl)] bg-surface shadow-[var(--shadow-border)] sm:rounded-[var(--radius-xl)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between px-5 pt-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-[11px] tracking-[0.16em] text-cyan uppercase",
					children: "Makro overlay"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-semibold text-fg",
					children: "Hold to fire"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "icon",
					"aria-label": "Tutup",
					onClick: () => close(false),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-h-0 flex-1 overflow-y-auto px-5 py-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-4 rounded-[var(--radius-lg)] bg-elevated p-4 shadow-[var(--shadow-border)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium text-fg",
							children: "Tombol ditahan = klik beruntun"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-muted text-pretty",
							children: "Setiap tick menembak di arena sesuai delay. Lepas tombol, tembakan berhenti. Tidak menyentuh data pertandingan di luar NEXUS."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex items-center justify-between text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							children: "Ukuran tombol"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-mono tabular-nums text-cyan",
							children: [Math.round(cfg.buttonSize), " px"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
						label: "Ukuran tombol",
						min: 40,
						max: 96,
						value: cfg.buttonSize,
						onChange: (v) => patch({ buttonSize: v })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "my-4 flex justify-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex items-center justify-center rounded-full bg-cyan text-bg shadow-[var(--shadow-border)]",
							style: {
								width: cfg.buttonSize,
								height: cfg.buttonSize
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { style: {
								width: cfg.buttonSize * .42,
								height: cfg.buttonSize * .42
							} })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex items-center justify-between text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							children: "Delay klik"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-mono tabular-nums text-cyan",
							children: [cfg.speedMs, " ms"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
						label: "Delay makro",
						min: 5,
						max: 150,
						step: 5,
						value: cfg.speedMs,
						onChange: (v) => patch({ speedMs: v })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 mb-4 grid grid-cols-4 gap-2",
						children: [
							5,
							15,
							30,
							60
						].map((ms) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => patch({ speedMs: ms }),
							className: "h-9 rounded-[var(--radius-sm)] font-mono text-xs shadow-[var(--shadow-border)]",
							style: {
								background: cfg.speedMs === ms ? "var(--color-cyan)" : "var(--color-elevated)",
								color: cfg.speedMs === ms ? "var(--color-bg)" : "var(--color-fg)"
							},
							children: [ms, "ms"]
						}, ms))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 font-mono text-[11px] font-medium tracking-[0.14em] text-muted uppercase",
						children: "Preset combo"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-2",
						children: MACRO_COMBOS.map((c) => {
							const on = cfg.combo === c.id;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => patch({ combo: c.id }),
								className: "w-full rounded-[var(--radius-md)] bg-elevated p-3 text-left shadow-[var(--shadow-border)]",
								style: { boxShadow: on ? "0 0 0 1px color-mix(in oklab, var(--color-cyan) 55%, transparent)" : void 0 },
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-medium text-fg",
									children: c.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-mono text-[10px] text-muted",
									children: c.sequence
								})]
							}, c.id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						ref: holdRef,
						variant: "cyan",
						className: "mt-5 h-14 w-full",
						onPointerDown: (e) => {
							e.preventDefault();
							e.currentTarget.setPointerCapture(e.pointerId);
							startFire();
						},
						onPointerUp: stopFire,
						onPointerCancel: stopFire,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, {}), firing ? `MENEMBAK ${clicks} klik` : "TAHAN UNTUK TES MAKRO"]
					})
				]
			})]
		})
	});
}
function OverlayLayer({ onFireChange }) {
	const overlayActive = useNexus((s) => s.overlayActive);
	const overlayPerm = useNexus((s) => s.overlayPerm);
	const menuOpen = useNexus((s) => s.menuOpen);
	const crosshair = useNexus((s) => s.crosshair);
	const macro = useNexus((s) => s.macro);
	const hud = useNexus((s) => s.hud);
	const orb = useNexus((s) => s.orb);
	const firing = useNexus((s) => s.firing);
	const clicks = useNexus((s) => s.clicksThisHold);
	const clickCount = useNexus((s) => s.clickCount);
	if (!overlayActive || overlayPerm !== "granted") return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none fixed inset-0 z-40",
		children: [
			hud.enabled ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TelemetryChip, {}) : null,
			crosshair.enabled ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FloatingCrosshair, {}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OverlayOrbButton, {
				x: orb.x,
				y: orb.y
			}),
			macro.enabled ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MacroPad, { onFireChange }) : null,
			menuOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModMenu, {}) : null,
			firing ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-none absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-[120%] rounded-full bg-bg/80 px-3 py-1 font-mono text-[11px] text-cyan shadow-[var(--shadow-border)]",
				children: [
					clicks,
					" klik · ",
					clickCount,
					" total · ",
					macro.speedMs,
					"ms"
				]
			}) : null
		]
	});
}
function FloatingCrosshair() {
	const cfg = useNexus((s) => s.crosshair);
	const patch = useNexus((s) => s.patchCrosshair);
	const open = useNexus((s) => s.setCrosshairOpen);
	const view = useNexus((s) => s.view);
	const taps = (0, import_react.useRef)([]);
	const drag = (0, import_react.useRef)(null);
	const scale = useNexus((s) => 420 / s.dpi);
	const size = Math.round(cfg.size * (view === "arena" ? 1 : scale));
	function onTriple() {
		const now = Date.now();
		taps.current = taps.current.filter((t) => now - t < 520);
		taps.current.push(now);
		if (taps.current.length >= 3) {
			taps.current = [];
			open(true);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "pointer-events-auto absolute",
		style: {
			left: `${cfg.x * 100}%`,
			top: `${cfg.y * 100}%`,
			transform: "translate(-50%, -50%)",
			touchAction: "none"
		},
		onPointerDown: (e) => {
			if (cfg.locked) return;
			e.currentTarget.setPointerCapture(e.pointerId);
			drag.current = {
				ox: e.clientX,
				oy: e.clientY,
				moved: false
			};
		},
		onPointerMove: (e) => {
			if (!drag.current || cfg.locked) return;
			const dx = e.clientX - drag.current.ox;
			const dy = e.clientY - drag.current.oy;
			if (Math.hypot(dx, dy) > 8) drag.current.moved = true;
			if (drag.current.moved) patch({
				x: Math.min(.92, Math.max(.08, e.clientX / window.innerWidth)),
				y: Math.min(.9, Math.max(.08, e.clientY / window.innerHeight))
			});
		},
		onPointerUp: () => {
			const moved = drag.current?.moved;
			drag.current = null;
			if (!moved) onTriple();
		},
		role: "button",
		"aria-label": "Crosshair. Ketuk 3 kali untuk setting penuh.",
		title: "Ketuk 3 kali untuk setting penuh",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex items-center justify-center",
			style: {
				width: Math.max(48, size + 16),
				height: Math.max(48, size + 16)
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CrosshairMark, {
				config: {
					...cfg,
					size
				},
				size: Math.max(48, size + 8)
			})
		})
	});
}
function OverlayOrbButton({ x, y }) {
	const setOrb = useNexus((s) => s.setOrb);
	const toggleMenu = useNexus((s) => s.toggleMenu);
	const menuOpen = useNexus((s) => s.menuOpen);
	const drag = (0, import_react.useRef)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": "Tombol overlay",
		"aria-pressed": menuOpen,
		className: "pointer-events-auto absolute flex size-14 items-center justify-center overflow-hidden rounded-full bg-elevated shadow-[var(--shadow-border)]",
		style: {
			left: `${x * 100}%`,
			top: `${y * 100}%`,
			transform: "translate(-50%, -50%)",
			boxShadow: menuOpen ? "0 0 0 1px color-mix(in oklab, var(--color-cyan) 70%, transparent)" : void 0,
			touchAction: "none"
		},
		onPointerDown: (e) => {
			e.currentTarget.setPointerCapture(e.pointerId);
			drag.current = {
				ox: e.clientX,
				oy: e.clientY,
				moved: false
			};
		},
		onPointerMove: (e) => {
			if (!drag.current) return;
			if (Math.hypot(e.clientX - drag.current.ox, e.clientY - drag.current.oy) > 8) {
				drag.current.moved = true;
				setOrb({
					x: Math.min(.92, Math.max(.08, e.clientX / window.innerWidth)),
					y: Math.min(.9, Math.max(.12, e.clientY / window.innerHeight))
				});
			}
		},
		onPointerUp: () => {
			const moved = drag.current?.moved;
			drag.current = null;
			if (!moved) toggleMenu();
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: "/nexus-logo.png",
			alt: "",
			className: "size-9 object-contain"
		})
	});
}
function MacroPad({ onFireChange }) {
	const cfg = useNexus((s) => s.macro);
	const patch = useNexus((s) => s.patchMacro);
	const startFire = useNexus((s) => s.startFire);
	const stopFire = useNexus((s) => s.stopFire);
	const register = useNexus((s) => s.registerClicks);
	const firing = useNexus((s) => s.firing);
	const openSettings = useNexus((s) => s.setMacroOpen);
	const dpi = useNexus((s) => s.dpi);
	const drag = (0, import_react.useRef)(null);
	const fireTimer = (0, import_react.useRef)(null);
	const holdTimer = (0, import_react.useRef)(null);
	const size = Math.round(Math.min(96, Math.max(40, cfg.buttonSize * (420 / dpi))));
	function clearFire() {
		if (fireTimer.current) {
			window.clearInterval(fireTimer.current);
			fireTimer.current = null;
		}
		stopFire();
		onFireChange?.(false);
	}
	function beginFire() {
		startFire();
		onFireChange?.(true);
		register(1);
		fireTimer.current = window.setInterval(() => {
			register(1);
		}, Math.max(5, cfg.speedMs));
	}
	(0, import_react.useEffect)(() => () => clearFire(), []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		"aria-label": "Tombol makro. Tahan untuk klik cepat.",
		className: cn("pointer-events-auto absolute flex flex-col items-center justify-center rounded-full text-bg", firing ? "bg-danger" : "bg-cyan"),
		style: {
			width: size,
			height: size,
			left: `${cfg.x * 100}%`,
			top: `${cfg.y * 100}%`,
			transform: "translate(-50%, -50%)",
			touchAction: "none"
		},
		onPointerDown: (e) => {
			e.preventDefault();
			e.currentTarget.setPointerCapture(e.pointerId);
			drag.current = {
				ox: e.clientX,
				oy: e.clientY,
				moved: false
			};
			holdTimer.current = window.setTimeout(() => {
				holdTimer.current = null;
				if (!drag.current?.moved) beginFire();
			}, 40);
		},
		onPointerMove: (e) => {
			if (!drag.current) return;
			if (Math.hypot(e.clientX - drag.current.ox, e.clientY - drag.current.oy) > 14) {
				drag.current.moved = true;
				if (holdTimer.current) {
					window.clearTimeout(holdTimer.current);
					holdTimer.current = null;
				}
				clearFire();
				patch({
					x: Math.min(.92, Math.max(.08, e.clientX / window.innerWidth)),
					y: Math.min(.9, Math.max(.12, e.clientY / window.innerHeight))
				});
			}
		},
		onPointerUp: () => {
			if (holdTimer.current) {
				window.clearTimeout(holdTimer.current);
				holdTimer.current = null;
			}
			clearFire();
			drag.current = null;
		},
		onPointerCancel: () => {
			clearFire();
			drag.current = null;
		},
		onContextMenu: (e) => {
			e.preventDefault();
			openSettings(true);
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { style: {
			width: size * .42,
			height: size * .42
		} }), size >= 52 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "font-mono text-[9px] font-semibold",
			children: [cfg.speedMs, "ms"]
		}) : null]
	});
}
function TelemetryChip() {
	const hud = useNexus((s) => s.hud);
	const patch = useNexus((s) => s.patchHud);
	const flush = useNexus((s) => s.flushRam);
	const fps = useLiveFps();
	const drag = (0, import_react.useRef)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "pointer-events-auto absolute rounded-[var(--radius-md)] bg-bg/85 px-2.5 py-1.5 shadow-[var(--shadow-border)]",
		style: {
			left: `${hud.x * 100}%`,
			top: `${hud.y * 100}%`,
			touchAction: "none"
		},
		onPointerDown: (e) => {
			e.currentTarget.setPointerCapture(e.pointerId);
			drag.current = { moved: false };
		},
		onPointerMove: (e) => {
			if (!drag.current || e.buttons === 0) return;
			drag.current.moved = true;
			patch({
				x: Math.min(.7, Math.max(.02, e.clientX / window.innerWidth - .08)),
				y: Math.min(.85, Math.max(.02, e.clientY / window.innerHeight - .02))
			});
		},
		onPointerUp: () => {
			if (!drag.current?.moved) patch({ expanded: !hud.expanded });
			drag.current = null;
		},
		children: hud.expanded ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-1 flex items-center gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-danger" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-mono text-[9px] tracking-[0.14em] text-danger",
					children: "NEXUS LINK"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "rounded px-1.5 py-0.5 font-mono text-[8px] text-ok shadow-[var(--shadow-border)]",
					onClick: (e) => {
						e.stopPropagation();
						flush();
					},
					children: "FLUSH"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-3 font-mono text-[10px] tabular-nums",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					k: "FPS",
					v: String(fps),
					c: "text-ok"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					k: "CPU",
					v: "18%",
					c: "text-cyan"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					k: "TEMP",
					v: "36.4",
					c: "text-fg"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					k: "PING",
					v: "16ms",
					c: "text-cyan"
				})
			]
		})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2 font-mono text-[10px] tabular-nums",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-danger" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					k: "FPS",
					v: String(fps),
					c: "text-ok"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-subtle",
					children: "|"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					k: "CPU",
					v: "18%",
					c: "text-cyan"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-subtle",
					children: "|"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					k: "TEMP",
					v: "36.4",
					c: "text-fg"
				})
			]
		})
	});
}
function Stat({ k, v, c }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "text-subtle",
		children: [k, " "]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: c,
		children: v
	})] });
}
function useLiveFps() {
	const profile = useNexus((s) => s.profile);
	const base = profile === "BEAST" ? 120 : profile === "BALANCED" ? 90 : 60;
	const [fps, setFps] = (0, import_react.useState)(base);
	(0, import_react.useEffect)(() => {
		setFps(base);
		const t = window.setInterval(() => {
			setFps(base - Math.floor(Math.random() * 3));
		}, 900);
		return () => window.clearInterval(t);
	}, [base]);
	return fps;
}
function ModMenu() {
	const close = useNexus((s) => s.setMenuOpen);
	const crosshair = useNexus((s) => s.crosshair);
	const macro = useNexus((s) => s.macro);
	const hud = useNexus((s) => s.hud);
	const patchC = useNexus((s) => s.patchCrosshair);
	const patchM = useNexus((s) => s.patchMacro);
	const patchH = useNexus((s) => s.patchHud);
	const openC = useNexus((s) => s.setCrosshairOpen);
	const openM = useNexus((s) => s.setMacroOpen);
	const openD = useNexus((s) => s.setDpiOpen);
	const setOverlay = useNexus((s) => s.setOverlayActive);
	const view = useNexus((s) => s.view);
	const setView = useNexus((s) => s.setView);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "pointer-events-auto absolute inset-x-3 bottom-24 z-50 mx-auto max-w-sm sm:inset-x-auto sm:right-4 sm:bottom-8 sm:left-auto",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-[var(--radius-xl)] bg-surface p-4 shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-[10px] tracking-[0.16em] text-cyan uppercase",
						children: "Overlay menu"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-lg font-semibold text-fg",
						children: "NEXUS Mod"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						"aria-label": "Tutup menu",
						onClick: () => close(false),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crosshair, { className: "size-4 text-cyan" }),
					title: "Crosshair",
					sub: "Ketuk reticle 3× untuk setting penuh",
					checked: crosshair.enabled,
					onChecked: (v) => patchC({ enabled: v })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "size-4 text-cyan" }),
					title: "Makro hold-fire",
					sub: `${macro.speedMs}ms · ${comboTitle(macro.combo)}`,
					checked: macro.enabled,
					onChecked: (v) => patchM({ enabled: v })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gauge, { className: "size-4 text-cyan" }),
					title: "Telemetry HUD",
					sub: "FPS / CPU / suhu",
					checked: hud.enabled,
					onChecked: (v) => patchH({ enabled: v })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 grid grid-cols-2 gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "secondary",
							size: "sm",
							onClick: () => openC(true),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Target, {}), " Reticle"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "secondary",
							size: "sm",
							onClick: () => openM(true),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, {}), " Makro"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "secondary",
							size: "sm",
							onClick: () => openD(true),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, {}), " DPI"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "secondary",
							size: "sm",
							onClick: () => setView(view === "arena" ? "hub" : "arena"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, {}),
								" ",
								view === "arena" ? "Hub" : "Arena"
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					className: "mt-3 w-full",
					onClick: () => {
						setOverlay(false);
						close(false);
					},
					children: "Matikan overlay"
				})
			]
		})
	});
}
function Row({ icon, title, sub, checked, onChecked }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3 border-t border-border py-2.5 first:border-t-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex size-9 items-center justify-center rounded-[var(--radius-sm)] bg-elevated",
				children: icon
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-fg",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate text-xs text-muted",
					children: sub
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
				checked,
				onCheckedChange: onChecked,
				label: title
			})
		]
	});
}
function PermissionOverlay() {
	const open = useNexus((s) => s.permOpen);
	const step = useNexus((s) => s.permStep);
	const overlayPerm = useNexus((s) => s.overlayPerm);
	const grantOverlay = useNexus((s) => s.grantOverlay);
	const denyOverlay = useNexus((s) => s.denyOverlay);
	const grantNotif = useNexus((s) => s.grantNotif);
	const skipNotif = useNexus((s) => s.skipNotif);
	if (!open) return null;
	const overlayStep = step === "overlay" && overlayPerm !== "granted";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-70 flex items-end justify-center bg-bg/80 p-4 sm:items-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": "perm-title",
			className: "w-full max-w-md rounded-[var(--radius-xl)] bg-surface p-5 shadow-[var(--shadow-border)] sm:p-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-4 flex size-12 items-center justify-center rounded-[var(--radius-md)] bg-elevated shadow-[var(--shadow-border)]",
				children: overlayStep ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, { className: "size-5 text-cyan" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "size-5 text-cyan" })
			}), overlayStep ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-1 font-mono text-[11px] font-medium tracking-[0.18em] text-cyan uppercase",
					children: "Izin overlay"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					id: "perm-title",
					className: "font-display text-2xl font-semibold tracking-tight text-fg text-balance",
					children: "Tampilkan di atas arena"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-sm leading-relaxed text-muted text-pretty",
					children: [
						"Izin ini satu-satunya tujuan overlay: supaya",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-fg",
							children: "crosshair"
						}),
						" dan",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-fg",
							children: "menu overlay"
						}),
						" bisa muncul di atas pertandingan. Tanpa izin, keduanya tidak ditampilkan. Tidak mengubah data pertandingan."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-4 space-y-2 text-sm text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-1.5 size-1.5 shrink-0 rounded-full bg-cyan" }), "Crosshair reticle di atas medan"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-1.5 size-1.5 shrink-0 rounded-full bg-cyan" }), "Tombol overlay membuka mod menu"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-1.5 size-1.5 shrink-0 rounded-full bg-cyan" }), "Makro hold-to-fire di lapisan yang sama"]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex flex-col gap-2 sm:flex-row-reverse",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "flex-1",
						variant: "cyan",
						onClick: grantOverlay,
						children: "Izinkan overlay"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "flex-1",
						variant: "secondary",
						onClick: denyOverlay,
						children: "Nanti"
					})]
				})
			] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-1 font-mono text-[11px] font-medium tracking-[0.18em] text-cyan uppercase",
					children: "Izin notifikasi"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					id: "perm-title",
					className: "font-display text-2xl font-semibold tracking-tight text-fg text-balance",
					children: "Kode pairing DPI"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-relaxed text-muted text-pretty",
					children: "Notifikasi dipakai untuk mengirim kode pairing debug — membuka tuner DPI tanpa masuk opsi pengembang. Kode 6 digit muncul di banner, lalu kamu masukkan di panel DPI."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex flex-col gap-2 sm:flex-row-reverse",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "flex-1",
						variant: "cyan",
						onClick: () => void grantNotif(),
						children: "Izinkan notifikasi"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "flex-1",
						variant: "secondary",
						onClick: skipNotif,
						children: "Lewati"
					})]
				})
			] })]
		})
	});
}
function NexusApp() {
	const view = useNexus((s) => s.view);
	const hydrate = useNexus((s) => s.hydrate);
	const hydrated = useNexus((s) => s.hydrated);
	const toasts = useNexus((s) => s.toasts);
	const dismiss = useNexus((s) => s.dismissToast);
	const firing = useNexus((s) => s.firing);
	const [fireSignal, setFireSignal] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		hydrate();
	}, [hydrate]);
	(0, import_react.useEffect)(() => {
		setFireSignal(firing);
	}, [firing]);
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-dvh items-center justify-center bg-bg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/nexus-logo.png",
				alt: "",
				className: "mx-auto size-16 object-contain"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 font-mono text-xs tracking-[0.2em] text-cyan uppercase",
				children: "NEXUS"
			})]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg antialiased",
		children: [
			view === "hub" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameSpaceHub, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArenaView, { fireSignal }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OverlayLayer, { onFireChange: setFireSignal }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionOverlay, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CrosshairSettings, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MacroSettings, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DpiPanel, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none fixed top-3 right-3 z-80 flex max-w-xs flex-col gap-2",
				children: toasts.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "pointer-events-auto rounded-[var(--radius-md)] bg-surface px-3 py-2 text-left text-xs text-fg shadow-[var(--shadow-border)]",
					onClick: () => dismiss(t.id),
					children: t.text
				}, t.id))
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NexusApp, {});
}
//#endregion
export { Home as component };
