import { ArenaView } from "@/components/nexus/ArenaView";
import { CrosshairSettings } from "@/components/nexus/CrosshairSettings";
import { DpiPanel } from "@/components/nexus/DpiPanel";
import { GameSpaceHub } from "@/components/nexus/GameSpaceHub";
import { MacroSettings } from "@/components/nexus/MacroSettings";
import { OverlayLayer } from "@/components/nexus/OverlayLayer";
import { PermissionOverlay } from "@/components/nexus/PermissionOverlay";
import { useNexus } from "@/lib/nexus/store";
import { useEffect, useState } from "react";

export function NexusApp() {
  const view = useNexus((s) => s.view);
  const hydrate = useNexus((s) => s.hydrate);
  const toasts = useNexus((s) => s.toasts);
  const dismiss = useNexus((s) => s.dismissToast);
  const firing = useNexus((s) => s.firing);
  const [fireSignal, setFireSignal] = useState(false);

  useEffect(() => {
    hydrate();
  }, [hydrate]);

  useEffect(() => {
    setFireSignal(firing);
  }, [firing]);

  return (
    <div className="min-h-dvh bg-bg text-fg antialiased">
      {view === "hub" ? <GameSpaceHub /> : <ArenaView fireSignal={fireSignal} />}
      <OverlayLayer onFireChange={setFireSignal} />
      <PermissionOverlay />
      <CrosshairSettings />
      <MacroSettings />
      <DpiPanel />
      <div className="pointer-events-none nexus-toast fixed top-3 right-3 flex max-w-xs flex-col gap-2">
        {toasts.map((t) => (
          <button
            key={t.id}
            type="button"
            className="pointer-events-auto rounded-[var(--radius-md)] bg-surface px-3 py-2 text-left text-xs text-fg shadow-[var(--shadow-border)]"
            onClick={() => dismiss(t.id)}
          >
            {t.text}
          </button>
        ))}
      </div>
    </div>
  );
}
