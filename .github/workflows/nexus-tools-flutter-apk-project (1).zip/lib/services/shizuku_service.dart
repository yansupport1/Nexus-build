import 'dart:async';
import 'package:flutter/services.dart';

class ShizukuService {
  static const MethodChannel _channel = MethodChannel('nexus.tools/shizuku');

  static Future<bool> isShizukuInstalled() async {
    try {
      final bool result = await _channel.invokeMethod('isShizukuInstalled');
      return result;
    } on PlatformException catch (_) {
      // Return false instead of crashing if channel is not implemented natively yet
      return false;
    }
  }

  static Future<bool> checkPermission() async {
    try {
      final bool result = await _channel.invokeMethod('checkPermission');
      return result;
    } on PlatformException catch (_) {
      return false;
    }
  }

  static Future<bool> requestPermission() async {
    try {
      final bool result = await _channel.invokeMethod('requestPermission');
      return result;
    } on PlatformException catch (_) {
      return false;
    }
  }

  static Future<String> executeCommand(String command) async {
    try {
      final String result = await _channel.invokeMethod('executeCommand', {'command': command});
      return result;
    } on PlatformException catch (e) {
      return "Error: ${e.message}";
    }
  }
}
