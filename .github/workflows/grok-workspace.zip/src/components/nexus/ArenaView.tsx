import { Button } from "@/components/ui/button";
import { createArena, type ArenaApi, type ArenaStats } from "@/lib/nexus/arena-engine";
import { useNexus } from "@/lib/nexus/store";
import { ArrowLeft } from "lucide-react";
import { useEffect, useRef, useState } from "react";

export function ArenaView({ fireSignal }: { fireSignal: boolean }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const api = useRef<ArenaApi | null>(null);
  const [stats, setStats] = useState<ArenaStats>({
    score: 0,
    hits: 0,
    shots: 0,
    combo: 0,
    cps: 0,
    wave: 1,
    alive: 0,
    firing: false,
  });
  const setView = useNexus((s) => s.setView);
  const overlayActive = useNexus((s) => s.overlayActive);
  const crosshair = useNexus((s) => s.crosshair);
  const dpi = useNexus((s) => s.dpi);
  const speedMs = useNexus((s) => s.macro.speedMs);
  const firing = useNexus((s) => s.firing);

  useEffect(() => {
    if (!canvasRef.current) return;
    const img = new Image();
    img.src = "/space-arena.jpg";
    img.crossOrigin = "anonymous";
    let engine: ArenaApi | null = null;
    let cancelled = false;
    const boot = () => {
      if (cancelled || !canvasRef.current) return;
      engine = createArena(canvasRef.current, img.complete && img.naturalWidth ? img : null, setStats);
      api.current = engine;
      engine.setDpi(useNexus.getState().dpi);
      engine.setSpeedMs(useNexus.getState().macro.speedMs);
      engine.setCrosshair(null);
    };
    img.onload = boot;
    img.onerror = boot;
    if (img.complete) boot();
    const onResize = () => api.current?.resize();
    window.addEventListener("resize", onResize);
    return () => {
      cancelled = true;
      window.removeEventListener("resize", onResize);
      engine?.destroy();
      api.current = null;
    };
  }, []);

  useEffect(() => {
    api.current?.setDpi(dpi);
  }, [dpi]);

  useEffect(() => {
    api.current?.setSpeedMs(speedMs);
  }, [speedMs]);

  useEffect(() => {
    if (fireSignal || firing) {
      const ch = useNexus.getState().crosshair;
      api.current?.setAim(ch.x, ch.y);
      api.current?.startFire();
    } else {
      api.current?.stopFire();
    }
  }, [fireSignal, firing, crosshair.x, crosshair.y]);

  return (
    <div className="relative h-dvh w-full overflow-hidden bg-bg">
      <canvas
        ref={canvasRef}
        className="block h-full w-full touch-none"
        onPointerMove={(e) => {
          const rect = e.currentTarget.getBoundingClientRect();
          api.current?.setAim(
            (e.clientX - rect.left) / rect.width,
            (e.clientY - rect.top) / rect.height,
          );
          if (!useNexus.getState().crosshair.locked) {
            useNexus.getState().patchCrosshair({
              x: (e.clientX - rect.left) / rect.width,
              y: (e.clientY - rect.top) / rect.height,
            });
          }
        }}
        onPointerDown={(e) => {
          const rect = e.currentTarget.getBoundingClientRect();
          api.current?.setAim(
            (e.clientX - rect.left) / rect.width,
            (e.clientY - rect.top) / rect.height,
          );
        }}
      />

      <div className="pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between p-3 pt-[max(0.75rem,env(safe-area-inset-top))]">
        <Button
          variant="secondary"
          size="sm"
          className="pointer-events-auto"
          onClick={() => setView("hub")}
        >
          <ArrowLeft /> Hub
        </Button>
        <div className="rounded-[var(--radius-md)] bg-bg/70 px-3 py-1.5 font-mono text-[11px] tabular-nums text-fg shadow-[var(--shadow-border)]">
          <span className="text-subtle">SCORE </span>
          {stats.score}
          <span className="mx-2 text-subtle">·</span>
          <span className="text-subtle">WAVE </span>
          {stats.wave}
          <span className="mx-2 text-subtle">·</span>
          <span className="text-cyan">{stats.cps} cps</span>
        </div>
      </div>

      {!overlayActive ? (
        <p className="pointer-events-none absolute bottom-8 left-1/2 w-[min(90%,20rem)] -translate-x-1/2 text-center text-xs text-muted">
          Overlay mati. Nyalakan dari Hub supaya crosshair, menu, dan makro muncul.
        </p>
      ) : (
        <p className="pointer-events-none absolute bottom-6 left-1/2 w-[min(90%,22rem)] -translate-x-1/2 text-center text-[11px] text-subtle">
          Geser untuk aim. Tahan tombol makro untuk tembak cepat. Ketuk crosshair 3× untuk setting.
        </p>
      )}
    </div>
  );
}
