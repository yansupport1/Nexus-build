package com.yanz.nexustools

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
