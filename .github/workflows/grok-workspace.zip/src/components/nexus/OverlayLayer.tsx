import { CrosshairMark } from "@/components/nexus/CrosshairMark";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { comboTitle, useNexus } from "@/lib/nexus/store";
import { cn } from "@/lib/utils";
import {
  Crosshair,
  Gauge,
  Layers,
  Settings,
  Target,
  X,
  Zap,
} from "lucide-react";
import type { ReactNode } from "react";
import { useEffect, useRef, useState } from "react";

export function OverlayLayer({
  onFireChange,
}: {
  onFireChange?: (on: boolean) => void;
}) {
  const overlayActive = useNexus((s) => s.overlayActive);
  const overlayPerm = useNexus((s) => s.overlayPerm);
  const menuOpen = useNexus((s) => s.menuOpen);
  const crosshair = useNexus((s) => s.crosshair);
  const macro = useNexus((s) => s.macro);
  const hud = useNexus((s) => s.hud);
  const orb = useNexus((s) => s.orb);
  const firing = useNexus((s) => s.firing);
  const clicks = useNexus((s) => s.clicksThisHold);
  const clickCount = useNexus((s) => s.clickCount);

  if (!overlayActive || overlayPerm !== "granted") return null;

  return (
    <div className="pointer-events-none nexus-overlay fixed inset-0">
      {hud.enabled ? <TelemetryChip /> : null}
      {crosshair.enabled ? <FloatingCrosshair /> : null}
      <OverlayOrbButton x={orb.x} y={orb.y} />
      {macro.enabled ? <MacroPad onFireChange={onFireChange} /> : null}
      {menuOpen ? <ModMenu /> : null}
      {firing ? (
        <div className="pointer-events-none absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-[120%] rounded-full bg-bg/80 px-3 py-1 font-mono text-[11px] text-cyan shadow-[var(--shadow-border)]">
          {clicks} klik · {clickCount} total · {macro.speedMs}ms
        </div>
      ) : null}
    </div>
  );
}

function FloatingCrosshair() {
  const cfg = useNexus((s) => s.crosshair);
  const patch = useNexus((s) => s.patchCrosshair);
  const open = useNexus((s) => s.setCrosshairOpen);
  const view = useNexus((s) => s.view);
  const taps = useRef<number[]>([]);
  const drag = useRef<{ ox: number; oy: number; moved: boolean } | null>(null);
  const scale = useNexus((s) => 420 / s.dpi);
  const size = Math.round(cfg.size * (view === "arena" ? 1 : scale));

  function onTriple() {
    const now = Date.now();
    taps.current = taps.current.filter((t) => now - t < 520);
    taps.current.push(now);
    if (taps.current.length >= 3) {
      taps.current = [];
      open(true);
    }
  }

  return (
    <div
      className="pointer-events-auto absolute"
      style={{
        left: `${cfg.x * 100}%`,
        top: `${cfg.y * 100}%`,
        transform: "translate(-50%, -50%)",
        touchAction: "none",
      }}
      onPointerDown={(e) => {
        if (cfg.locked) return;
        (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
        drag.current = { ox: e.clientX, oy: e.clientY, moved: false };
      }}
      onPointerMove={(e) => {
        if (!drag.current || cfg.locked) return;
        const dx = e.clientX - drag.current.ox;
        const dy = e.clientY - drag.current.oy;
        if (Math.hypot(dx, dy) > 8) drag.current.moved = true;
        if (drag.current.moved) {
          patch({
            x: Math.min(0.92, Math.max(0.08, e.clientX / window.innerWidth)),
            y: Math.min(0.9, Math.max(0.08, e.clientY / window.innerHeight)),
          });
        }
      }}
      onPointerUp={() => {
        const moved = drag.current?.moved;
        drag.current = null;
        if (!moved) onTriple();
      }}
      role="button"
      aria-label="Crosshair. Ketuk 3 kali untuk setting penuh."
      title="Ketuk 3 kali untuk setting penuh"
    >
      <div
        className="flex items-center justify-center"
        style={{ width: Math.max(48, size + 16), height: Math.max(48, size + 16) }}
      >
        <CrosshairMark config={{ ...cfg, size }} size={Math.max(48, size + 8)} />
      </div>
    </div>
  );
}

function OverlayOrbButton({ x, y }: { x: number; y: number }) {
  const setOrb = useNexus((s) => s.setOrb);
  const toggleMenu = useNexus((s) => s.toggleMenu);
  const menuOpen = useNexus((s) => s.menuOpen);
  const drag = useRef<{ ox: number; oy: number; moved: boolean } | null>(null);

  return (
    <button
      type="button"
      aria-label="Tombol overlay"
      aria-pressed={menuOpen}
      className="pointer-events-auto absolute flex size-14 items-center justify-center overflow-hidden rounded-full bg-elevated shadow-[var(--shadow-border)]"
      style={{
        left: `${x * 100}%`,
        top: `${y * 100}%`,
        transform: "translate(-50%, -50%)",
        boxShadow: menuOpen
          ? "0 0 0 1px color-mix(in oklab, var(--color-cyan) 70%, transparent)"
          : undefined,
        touchAction: "none",
      }}
      onPointerDown={(e) => {
        (e.currentTarget as HTMLButtonElement).setPointerCapture(e.pointerId);
        drag.current = { ox: e.clientX, oy: e.clientY, moved: false };
      }}
      onPointerMove={(e) => {
        if (!drag.current) return;
        if (Math.hypot(e.clientX - drag.current.ox, e.clientY - drag.current.oy) > 8) {
          drag.current.moved = true;
          setOrb({
            x: Math.min(0.92, Math.max(0.08, e.clientX / window.innerWidth)),
            y: Math.min(0.9, Math.max(0.12, e.clientY / window.innerHeight)),
          });
        }
      }}
      onPointerUp={() => {
        const moved = drag.current?.moved;
        drag.current = null;
        if (!moved) toggleMenu();
      }}
    >
      <img src="/nexus-logo.png" alt="" className="size-9 object-contain outline-none" />
    </button>
  );
}

function MacroPad({ onFireChange }: { onFireChange?: (on: boolean) => void }) {
  const cfg = useNexus((s) => s.macro);
  const patch = useNexus((s) => s.patchMacro);
  const startFire = useNexus((s) => s.startFire);
  const stopFire = useNexus((s) => s.stopFire);
  const register = useNexus((s) => s.registerClicks);
  const firing = useNexus((s) => s.firing);
  const openSettings = useNexus((s) => s.setMacroOpen);
  const dpi = useNexus((s) => s.dpi);
  const drag = useRef<{ ox: number; oy: number; moved: boolean } | null>(null);
  const fireTimer = useRef<number | null>(null);
  const holdTimer = useRef<number | null>(null);
  const size = Math.round(Math.min(96, Math.max(40, cfg.buttonSize * (420 / dpi))));

  function clearFire() {
    if (fireTimer.current) {
      window.clearInterval(fireTimer.current);
      fireTimer.current = null;
    }
    stopFire();
    onFireChange?.(false);
  }

  function beginFire() {
    startFire();
    onFireChange?.(true);
    register(1);
    fireTimer.current = window.setInterval(() => {
      register(1);
    }, Math.max(5, cfg.speedMs));
  }

  useEffect(() => () => clearFire(), []);

  return (
    <button
      type="button"
      aria-label="Tombol makro. Tahan untuk klik cepat."
      className={cn(
        "pointer-events-auto absolute flex flex-col items-center justify-center rounded-full text-bg",
        firing ? "bg-danger" : "bg-cyan",
      )}
      style={{
        width: size,
        height: size,
        left: `${cfg.x * 100}%`,
        top: `${cfg.y * 100}%`,
        transform: "translate(-50%, -50%)",
        touchAction: "none",
      }}
      onPointerDown={(e) => {
        e.preventDefault();
        (e.currentTarget as HTMLButtonElement).setPointerCapture(e.pointerId);
        drag.current = { ox: e.clientX, oy: e.clientY, moved: false };
        holdTimer.current = window.setTimeout(() => {
          holdTimer.current = null;
          if (!drag.current?.moved) beginFire();
        }, 40);
      }}
      onPointerMove={(e) => {
        if (!drag.current) return;
        if (Math.hypot(e.clientX - drag.current.ox, e.clientY - drag.current.oy) > 14) {
          drag.current.moved = true;
          if (holdTimer.current) {
            window.clearTimeout(holdTimer.current);
            holdTimer.current = null;
          }
          clearFire();
          patch({
            x: Math.min(0.92, Math.max(0.08, e.clientX / window.innerWidth)),
            y: Math.min(0.9, Math.max(0.12, e.clientY / window.innerHeight)),
          });
        }
      }}
      onPointerUp={() => {
        if (holdTimer.current) {
          window.clearTimeout(holdTimer.current);
          holdTimer.current = null;
        }
        clearFire();
        drag.current = null;
      }}
      onPointerCancel={() => {
        clearFire();
        drag.current = null;
      }}
      onContextMenu={(e) => {
        e.preventDefault();
        openSettings(true);
      }}
    >
      <Zap style={{ width: size * 0.42, height: size * 0.42 }} />
      {size >= 52 ? (
        <span className="font-mono text-[9px] font-semibold">{cfg.speedMs}ms</span>
      ) : null}
    </button>
  );
}

function TelemetryChip() {
  const hud = useNexus((s) => s.hud);
  const patch = useNexus((s) => s.patchHud);
  const flush = useNexus((s) => s.flushRam);
  const fps = useLiveFps();
  const drag = useRef<{ moved: boolean } | null>(null);

  return (
    <div
      className="pointer-events-auto absolute rounded-[var(--radius-md)] bg-bg/85 px-2.5 py-1.5 shadow-[var(--shadow-border)]"
      style={{
        left: `${hud.x * 100}%`,
        top: `${hud.y * 100}%`,
        touchAction: "none",
      }}
      onPointerDown={(e) => {
        (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
        drag.current = { moved: false };
      }}
      onPointerMove={(e) => {
        if (!drag.current || e.buttons === 0) return;
        drag.current.moved = true;
        patch({
          x: Math.min(0.7, Math.max(0.02, e.clientX / window.innerWidth - 0.08)),
          y: Math.min(0.85, Math.max(0.02, e.clientY / window.innerHeight - 0.02)),
        });
      }}
      onPointerUp={() => {
        if (!drag.current?.moved) patch({ expanded: !hud.expanded });
        drag.current = null;
      }}
    >
      {hud.expanded ? (
        <div>
          <div className="mb-1 flex items-center gap-2">
            <span className="size-1.5 rounded-full bg-danger" />
            <span className="font-mono text-[9px] tracking-[0.14em] text-danger">
              NEXUS LINK
            </span>
            <button
              type="button"
              className="rounded px-1.5 py-0.5 font-mono text-[8px] text-ok shadow-[var(--shadow-border)]"
              onClick={(e) => {
                e.stopPropagation();
                flush();
              }}
            >
              FLUSH
            </button>
          </div>
          <div className="flex gap-3 font-mono text-[10px] tabular-nums">
            <Stat k="FPS" v={String(fps)} c="text-ok" />
            <Stat k="CPU" v="18%" c="text-cyan" />
            <Stat k="TEMP" v="36.4" c="text-fg" />
            <Stat k="PING" v="16ms" c="text-cyan" />
          </div>
        </div>
      ) : (
        <div className="flex items-center gap-2 font-mono text-[10px] tabular-nums">
          <span className="size-1.5 rounded-full bg-danger" />
          <Stat k="FPS" v={String(fps)} c="text-ok" />
          <span className="text-subtle">|</span>
          <Stat k="CPU" v="18%" c="text-cyan" />
          <span className="text-subtle">|</span>
          <Stat k="TEMP" v="36.4" c="text-fg" />
        </div>
      )}
    </div>
  );
}

function Stat({ k, v, c }: { k: string; v: string; c: string }) {
  return (
    <span>
      <span className="text-subtle">{k} </span>
      <span className={c}>{v}</span>
    </span>
  );
}

function useLiveFps() {
  const profile = useNexus((s) => s.profile);
  const base = profile === "BEAST" ? 120 : profile === "BALANCED" ? 90 : 60;
  const [fps, setFps] = useState(base);
  useEffect(() => {
    setFps(base);
    const t = window.setInterval(() => {
      setFps(base - Math.floor(Math.random() * 3));
    }, 900);
    return () => window.clearInterval(t);
  }, [base]);
  return fps;
}

function ModMenu() {
  const close = useNexus((s) => s.setMenuOpen);
  const crosshair = useNexus((s) => s.crosshair);
  const macro = useNexus((s) => s.macro);
  const hud = useNexus((s) => s.hud);
  const patchC = useNexus((s) => s.patchCrosshair);
  const patchM = useNexus((s) => s.patchMacro);
  const patchH = useNexus((s) => s.patchHud);
  const openC = useNexus((s) => s.setCrosshairOpen);
  const openM = useNexus((s) => s.setMacroOpen);
  const openD = useNexus((s) => s.setDpiOpen);
  const setOverlay = useNexus((s) => s.setOverlayActive);
  const view = useNexus((s) => s.view);
  const setView = useNexus((s) => s.setView);

  return (
    <div className="pointer-events-auto absolute inset-x-3 bottom-24 z-50 mx-auto max-w-sm sm:inset-x-auto sm:right-4 sm:bottom-8 sm:left-auto">
      <div className="rounded-[var(--radius-xl)] bg-surface p-4 shadow-[var(--shadow-border)]">
        <div className="mb-3 flex items-center justify-between">
          <div>
            <p className="font-mono text-[10px] tracking-[0.16em] text-cyan uppercase">
              Overlay menu
            </p>
            <h2 className="font-display text-lg font-semibold text-fg">NEXUS Mod</h2>
          </div>
          <Button variant="ghost" size="icon" aria-label="Tutup menu" onClick={() => close(false)}>
            <X />
          </Button>
        </div>

        <Row
          icon={<Crosshair className="size-4 text-cyan" />}
          title="Crosshair"
          sub="Ketuk reticle 3× untuk setting penuh"
          checked={crosshair.enabled}
          onChecked={(v) => patchC({ enabled: v })}
        />
        <Row
          icon={<Zap className="size-4 text-cyan" />}
          title="Makro hold-fire"
          sub={`${macro.speedMs}ms · ${comboTitle(macro.combo)}`}
          checked={macro.enabled}
          onChecked={(v) => patchM({ enabled: v })}
        />
        <Row
          icon={<Gauge className="size-4 text-cyan" />}
          title="Telemetry HUD"
          sub="FPS / CPU / suhu"
          checked={hud.enabled}
          onChecked={(v) => patchH({ enabled: v })}
        />

        <div className="mt-3 grid grid-cols-2 gap-2">
          <Button variant="secondary" size="sm" onClick={() => openC(true)}>
            <Target /> Reticle
          </Button>
          <Button variant="secondary" size="sm" onClick={() => openM(true)}>
            <Zap /> Makro
          </Button>
          <Button variant="secondary" size="sm" onClick={() => openD(true)}>
            <Settings /> DPI
          </Button>
          <Button
            variant="secondary"
            size="sm"
            onClick={() => setView(view === "arena" ? "hub" : "arena")}
          >
            <Layers /> {view === "arena" ? "Hub" : "Arena"}
          </Button>
        </div>

        <Button
          variant="outline"
          className="mt-3 w-full"
          onClick={() => {
            setOverlay(false);
            close(false);
          }}
        >
          Matikan overlay
        </Button>
      </div>
    </div>
  );
}

function Row({
  icon,
  title,
  sub,
  checked,
  onChecked,
}: {
  icon: ReactNode;
  title: string;
  sub: string;
  checked: boolean;
  onChecked: (v: boolean) => void;
}) {
  return (
    <div className="flex items-center gap-3 border-t border-border py-2.5 first:border-t-0">
      <div className="flex size-9 items-center justify-center rounded-[var(--radius-sm)] bg-elevated">
        {icon}
      </div>
      <div className="min-w-0 flex-1">
        <p className="text-sm font-medium text-fg">{title}</p>
        <p className="truncate text-xs text-muted">{sub}</p>
      </div>
      <Switch checked={checked} onCheckedChange={onChecked} label={title} />
    </div>
  );
}
