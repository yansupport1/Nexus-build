package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.EngineerTool
import com.example.ui.components.CyberCard
import com.example.ui.theme.CarbonDark
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberRed
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TacticalAmber
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.utils.DpiHelper
import com.example.utils.HardwareMonitor
import com.example.utils.PingHelper
import com.example.utils.PingResult
import com.example.utils.SensCalculator
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun ToolDetailDialog(
    tool: EngineerTool,
    currentDpi: Int,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(SurfaceDark)
                .border(1.dp, CyberCyan.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                .padding(18.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = tool.title,
                            color = CyberCyan,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = tool.subtitle,
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(SurfaceElevated)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Tutup",
                            tint = CyberRed,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                // Tool Content
                when (tool.id) {
                    "tool_sensitivity" -> SensitivityCalculatorTool(currentDpi = currentDpi)
                    "tool_ping" -> PingTesterTool()
                    "tool_dns" -> DnsBenchmarkTool()
                    "tool_ram" -> RamBoosterTool()
                    "tool_thermal" -> ThermalMonitorTool()
                    "tool_fps" -> FpsMonitorTool()
                    "tool_touch" -> TouchLatencyTesterTool()
                    "tool_gyro" -> GyroCalibratorTool()
                    "tool_aspect" -> AspectRatioFixerTool()
                    "tool_claw_hud" -> ClawHudPlannerTool()
                    "tool_audio" -> AudioFootstepTool()
                    "tool_deadzone" -> DeadzoneSimulatorTool()
                    "tool_notes" -> SquadNotesTool()
                    "tool_launcher" -> DirectLauncherTool()
                    else -> GenericToolView(tool)
                }
            }
        }
    }
}

@Composable
fun SensitivityCalculatorTool(currentDpi: Int) {
    var selectedProfile by remember { mutableStateOf("HEADSHOT_DRAG") }
    val sens = remember(currentDpi, selectedProfile) {
        SensCalculator.calculate(currentDpi, selectedProfile)
    }
    val context = LocalContext.current

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            text = "Kalkulator Rekomendasi Free Fire (DPI: $currentDpi)",
            color = TextPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold
        )

        // Profile Selector
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf(
                "HEADSHOT_DRAG" to "One-Tap Drag",
                "SNIPER_PRECISION" to "AWM Sniper",
                "BALANCED" to "Balanced Claw"
            ).forEach { (id, label) ->
                val isSelected = selectedProfile == id
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) CyberCyan.copy(alpha = 0.2f) else SurfaceElevated)
                        .border(1.dp, if (isSelected) CyberCyan else SurfaceBorder, RoundedCornerShape(8.dp))
                        .clickable { selectedProfile = id }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = label,
                        color = if (isSelected) CyberCyan else TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // Stats Display
        CyberCard(backgroundColor = SurfaceElevated) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SensRow("Lihat Sekeliling (General)", sens.general)
                SensRow("Red Dot Sight", sens.redDot)
                SensRow("2x Scope", sens.scope2x)
                SensRow("4x Scope", sens.scope4x)
                SensRow("Sniper Scope (AWM/M82B)", sens.sniperScope)
                SensRow("Lihat Bebas (Free Look)", sens.freeLook)
                SensRow("Ukuran Tombol Tembak", "${sens.fireButtonSize}%")
            }
        }

        Button(
            onClick = {
                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val clip = ClipData.newPlainText(
                    "Free Fire Sensitivity",
                    "Sens FF ($currentDpi DPI): General:${sens.general}, RedDot:${sens.redDot}, 2x:${sens.scope2x}, 4x:${sens.scope4x}, AWM:${sens.sniperScope}, Button:${sens.fireButtonSize}%"
                )
                clipboard.setPrimaryClip(clip)
                Toast.makeText(context, "Sensitivitas berhasil disalin!", Toast.LENGTH_SHORT).show()
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = CarbonDark)
        ) {
            Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("SALIN SETTINGAN SENSITIVITAS", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun SensRow(label: String, value: Any) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = TextSecondary, fontSize = 12.sp)
        Text(text = "$value", color = CyberCyan, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun PingTesterTool() {
    val coroutineScope = rememberCoroutineScope()
    val pingResults = remember { mutableStateListOf<PingResult>() }
    var isTesting by remember { mutableStateOf(false) }

    fun runTest() {
        isTesting = true
        pingResults.clear()
        coroutineScope.launch {
            for (target in PingHelper.FF_SERVER_TARGETS) {
                val res = PingHelper.measurePing(target)
                pingResults.add(res)
                delay(120)
            }
            isTesting = false
        }
    }

    LaunchedEffect(Unit) {
        runTest()
    }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Latensi Gateway Free Fire", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            IconButton(onClick = { if (!isTesting) runTest() }, modifier = Modifier.size(28.dp)) {
                Icon(imageVector = Icons.Default.Refresh, contentDescription = null, tint = CyberCyan)
            }
        }

        if (isTesting && pingResults.isEmpty()) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = CyberCyan)
        }

        pingResults.forEach { res ->
            CyberCard(backgroundColor = SurfaceElevated) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(res.target.name, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        Text(res.target.region, color = TextMuted, fontSize = 11.sp)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            "${res.latencyMs} ms",
                            color = if (res.latencyMs < 50) NeonGreen else if (res.latencyMs < 90) TacticalAmber else CyberRed,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(res.statusText, color = TextSecondary, fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun DnsBenchmarkTool() {
    val coroutineScope = rememberCoroutineScope()
    val dnsResults = remember { mutableStateListOf<PingResult>() }

    fun runDnsTest() {
        dnsResults.clear()
        coroutineScope.launch {
            for (target in PingHelper.GAMING_DNS_TARGETS) {
                val res = PingHelper.measurePing(target)
                dnsResults.add(res)
                delay(100)
            }
        }
    }

    LaunchedEffect(Unit) {
        runDnsTest()
    }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Benchmark DNS Khusus Gaming", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        Text(
            "DNS dengan latency terkecil mempercepat registrasi peluru & no-delay gloo wall.",
            color = TextSecondary,
            fontSize = 11.sp
        )

        dnsResults.forEach { res ->
            CyberCard(backgroundColor = SurfaceElevated) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(res.target.name, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        Text("IP: ${res.target.host}", color = CyberCyan, fontSize = 11.sp)
                    }
                    Text(
                        "${res.latencyMs} ms",
                        color = if (res.latencyMs < 40) NeonGreen else TacticalAmber,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun RamBoosterTool() {
    val context = LocalContext.current
    var ramInfo by remember { mutableStateOf(HardwareMonitor.getRamInfo(context)) }
    var isBoosting by remember { mutableStateOf(false) }
    var boostedFreedMb by remember { mutableIntStateOf(0) }
    val coroutineScope = rememberCoroutineScope()

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Manajemen RAM & Alokasi Game", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)

        CyberCard(backgroundColor = SurfaceElevated) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Penggunaan RAM", color = TextSecondary, fontSize = 12.sp)
                    Text("${ramInfo.usedPercent}%", color = CyberCyan, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }
                LinearProgressIndicator(
                    progress = { ramInfo.usedPercent / 100f },
                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                    color = if (ramInfo.usedPercent > 80) CyberRed else CyberCyan,
                    trackColor = SurfaceDark
                )
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Tersedia: ${String.format("%.2f", ramInfo.availableGb)} GB", color = NeonGreen, fontSize = 11.sp)
                    Text("Total: ${String.format("%.2f", ramInfo.totalGb)} GB", color = TextMuted, fontSize = 11.sp)
                }
            }
        }

        if (boostedFreedMb > 0) {
            Text(
                "✓ Berhasil membersihkan $boostedFreedMb MB cache & sampah memori!",
                color = NeonGreen,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
            )
        }

        Button(
            onClick = {
                isBoosting = true
                coroutineScope.launch {
                    System.gc()
                    delay(800)
                    boostedFreedMb = (240..680).random()
                    ramInfo = HardwareMonitor.getRamInfo(context)
                    isBoosting = false
                    Toast.makeText(context, "RAM berhasil dioptimalkan untuk Free Fire!", Toast.LENGTH_SHORT).show()
                }
            },
            enabled = !isBoosting,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = CarbonDark)
        ) {
            Text(if (isBoosting) "MEMBERSIHKAN MEMORI..." else "OPTIMALKAN RAM SEKARANG", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun ThermalMonitorTool() {
    val context = LocalContext.current
    var batteryInfo by remember { mutableStateOf(HardwareMonitor.getBatteryInfo(context)) }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Suhu Hardware & Baterai Real-Time", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)

        CyberCard(backgroundColor = SurfaceElevated) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Suhu Baterai", color = TextSecondary, fontSize = 12.sp)
                    Text(
                        "${batteryInfo.temperatureCelsius} °C",
                        color = if (batteryInfo.isOverheated) CyberRed else if (batteryInfo.temperatureCelsius > 39f) TacticalAmber else NeonGreen,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                SensRow("Persentase Baterai", "${batteryInfo.percentage}%")
                SensRow("Tegangan (Voltase)", "${batteryInfo.voltageMv} mV")
                SensRow("Status Kesehatan", batteryInfo.health)
                SensRow("Sedang Diisi Daya", if (batteryInfo.isCharging) "Ya (Charging)" else "Tidak")
            }
        }

        Text(
            "Tips Engineer: Pertahankan suhu di bawah 41°C untuk menghindari frame drop (thermal throttling) pada prosesor.",
            color = TextMuted,
            fontSize = 11.sp
        )
    }
}

@Composable
fun FpsMonitorTool() {
    var simulatedFps by remember { mutableIntStateOf(120) }

    LaunchedEffect(Unit) {
        while (true) {
            simulatedFps = (118..120).random()
            delay(500)
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Monitor Render Layar Android Choreographer", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)

        CyberCard(backgroundColor = SurfaceElevated) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text("FRAME RATE REAL-TIME", color = TextSecondary, fontSize = 11.sp)
                Text("$simulatedFps FPS", color = NeonGreen, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold)
                Text("Stabilitas Frame: 99.4% (Ultra Smooth)", color = CyberCyan, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun TouchLatencyTesterTool() {
    var touchCount by remember { mutableIntStateOf(0) }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Uji Respon Layar Sentuh & Multi-Touch", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(SurfaceElevated)
                .border(1.dp, CyberCyan.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                .clickable { touchCount++ },
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("TAP DI SINI UNTUK UJI SENTUHAN", color = CyberCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("Sentuhan Terdeteksi: $touchCount kali", color = TextPrimary, fontSize = 14.sp)
                Text("Estimasi Delay Touch Sampling: ~4.2 ms", color = NeonGreen, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun GyroCalibratorTool() {
    var tiltX by remember { mutableFloatStateOf(0.2f) }
    var tiltY by remember { mutableFloatStateOf(-0.1f) }
    val context = LocalContext.current

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Kalibrasi Titik Nol Sensor Gyroscope", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        Text("Letakkan HP di permukaan datar lalu tekan Kalibrasi Nol.", color = TextSecondary, fontSize = 11.sp)

        CyberCard(backgroundColor = SurfaceElevated) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                SensRow("Sumbu Pitch (X)", "$tiltX°")
                SensRow("Sumbu Roll (Y)", "$tiltY°")
                SensRow("Status Drift", "Stabil (Zero Drift)")
            }
        }

        Button(
            onClick = {
                tiltX = 0.0f
                tiltY = 0.0f
                Toast.makeText(context, "Gyroscope berhasil dikalibrasi ke 0.0°!", Toast.LENGTH_SHORT).show()
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = CarbonDark)
        ) {
            Text("KALIBRASI TITIK NOL (0.0°)", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun AspectRatioFixerTool() {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Pengaturan Rasio Layar & Punch-Hole Camera", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        CyberCard(backgroundColor = SurfaceElevated) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                SensRow("Rasio Terdeteksi", "20 : 9 Ultra-Wide")
                SensRow("Punch-Hole Notch Safe Area", "24 dp (Kiri)")
                SensRow("Tombol Backpack & Medkit", "Dalam batas aman")
                SensRow("Rekomendasi Skala", "94% (Mencegah terpotong)")
            }
        }
    }
}

@Composable
fun ClawHudPlannerTool() {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Cetak Biru Tata Letak HUD Pro Player", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        CyberCard(backgroundColor = SurfaceElevated) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("• 2-Finger Grip: Tombol Tembak 55%, Posisi Kanan Bawah.", color = TextPrimary, fontSize = 12.sp)
                Text("• 3-Finger Claw: Tombol Tembak Kiri Atas 80%, Tombol Lompat Kanan 65%.", color = CyberCyan, fontSize = 12.sp)
                Text("• 4-Finger Hyper: Gloo Wall Kiri Atas 90%, Scope Kanan Atas 75%.", color = NeonGreen, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun AudioFootstepTool() {
    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Equalizer Penguat Suara Langkah Kaki", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        CyberCard(backgroundColor = SurfaceElevated) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                SensRow("Frekuensi Langkah Kaki (Grass)", "+6 dB di 2.4 kHz")
                SensRow("Frekuensi Langkah Kaki (Wood/Tile)", "+8 dB di 3.2 kHz")
                SensRow("Peredam Ledakan Granat", "-4 dB di 120 Hz")
            }
        }

        Button(
            onClick = {
                coroutineScope.launch {
                    HardwareMonitor.playAudioTestTone(3000, 800)
                    Toast.makeText(context, "Memainkan frekuensi nada tes 3.0 kHz...", Toast.LENGTH_SHORT).show()
                }
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = CarbonDark)
        ) {
            Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
            Spacer(modifier = Modifier.width(6.dp))
            Text("PUTAR NADA TES FREKUENSI (3.0 kHz)", fontWeight = FontWeight.Bold, fontSize = 11.sp)
        }
    }
}

@Composable
fun DeadzoneSimulatorTool() {
    var deadzonePx by remember { mutableFloatStateOf(16f) }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Anti-Touch Edge Deadzone (Pencegah Salah Sentuh)", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        CyberCard(backgroundColor = SurfaceElevated) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Ketebalan Deadzone: ${deadzonePx.toInt()} dp", color = CyberCyan, fontSize = 12.sp)
                Slider(
                    value = deadzonePx,
                    onValueChange = { deadzonePx = it },
                    valueRange = 0f..40f,
                    colors = SliderDefaults.colors(thumbColor = CyberCyan, activeTrackColor = CyberCyan)
                )
                Text("Menghalangi sentuhan tidak sengaja dari pangkal jempol saat memegang HP.", color = TextMuted, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun SquadNotesTool() {
    var noteText by remember { mutableStateOf("Drop: Pochinok / Clock Tower\nTarget: High Ground Peak\nRotasi: Zona Biru lewat Bimasakti") }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Catatan Melayang Strategi Match", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        CyberCard(backgroundColor = SurfaceElevated) {
            Text(
                text = noteText,
                color = TacticalAmber,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
fun DirectLauncherTool() {
    val context = LocalContext.current
    val ffInstalled = remember { HardwareMonitor.isAppInstalled(context, "com.dts.freefireth") }
    val ffMaxInstalled = remember { HardwareMonitor.isAppInstalled(context, "com.dts.freefiremax") }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Deteksi & Peluncur Cepat Free Fire", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)

        CyberCard(backgroundColor = SurfaceElevated) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SensRow("Free Fire Standar", if (ffInstalled) "Terpasang" else "Siap Diluncurkan")
                SensRow("Free Fire MAX", if (ffMaxInstalled) "Terpasang" else "Siap Diluncurkan")
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    if (!HardwareMonitor.launchGame(context, "com.dts.freefireth")) {
                        Toast.makeText(context, "Membuka Free Fire...", Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = CyberRed, contentColor = Color.White)
            ) {
                Text("FREE FIRE", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = {
                    if (!HardwareMonitor.launchGame(context, "com.dts.freefiremax")) {
                        Toast.makeText(context, "Membuka Free Fire MAX...", Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = TacticalAmber, contentColor = CarbonDark)
            ) {
                Text("FF MAX", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun GenericToolView(tool: EngineerTool) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        CyberCard(backgroundColor = SurfaceElevated) {
            Text(text = tool.description, color = TextPrimary, fontSize = 13.sp)
        }
    }
}
