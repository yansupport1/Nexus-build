# Nexus Tools - Flutter APK Build Guide (Android)

Aplikasi ini adalah **Flutter APK Native Android** dengan fitur:
1. **Game Space Hub 100%**: ROG Armoury Crate themed gaming launcher & performance mode (Ultra Beast 120 FPS).
2. **Floating Crosshair Overlay**: 7 model foto reticle presisi (Dot, Tactical Gap, Shotgun M1887 Ring, AWM Chevron, Predator Tri-HUD, Cyber Quad).
3. **Floating Makro Overlay Button**: Kebesaran tombol (36px-96px) dan kecepatan respon milidetik (5ms, 15ms, 30ms) dengan haptic feedback untuk kombo Fast Gloo Wall, Jump Shot, dan Auto Drag Burst.
4. **ROG Armoury Crate Telemetry HUD**: Monitor realtime FPS, suhu HP (thermals), CPU/GPU, RAM, dan Ping melayang di atas layar game.

---

## 🚀 Cara Build APK Menggunakan Flutter

### Opsi 1: Build Langsung di Komputer (Windows / macOS / Linux)
1. Install Flutter SDK (versi 3.0 ke atas): https://flutter.dev
2. Buka terminal di folder project ini:
```bash
# 1. Download dependencies
flutter pub get

# 2. Build APK Release
flutter build apk --release
```
3. File APK siap install akan berada di:
`build/app/outputs/flutter-apk/app-release.apk`
4. Kirim file `app-release.apk` ke HP Android Anda dan install!

---

### Opsi 2: Build Menggunakan Android Studio / VS Code
1. Buka folder ini di **Android Studio** atau **VS Code** (dengan ekstensi Flutter).
2. Hubungkan HP Android Anda via kabel USB dengan **USB Debugging** aktif.
3. Jalankan:
```bash
flutter run --release
```
Aplikasi akan langsung terpasang di HP Anda.

---

## 📱 Permission Android yang Dibutuhkan
Agar overlay dan makro bisa melayang di atas game Free Fire:
1. **SYSTEM_ALERT_WINDOW**: `Izin Menampilkan di Atas Aplikasi Lain` (Display over other apps).
2. **FOREGROUND_SERVICE**: Menjaga service overlay tetap aktif tanpa di-kill oleh sistem Android.
