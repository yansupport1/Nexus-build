package com.example.service

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.model.CrosshairConfig
import com.example.model.CrosshairStyle
import kotlin.math.cos
import kotlin.math.sin

class OverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var crosshairView: View? = null
    private var crosshairParams: WindowManager.LayoutParams? = null
    private var quickHudView: View? = null
    private var floatingBubbleView: View? = null

    companion object {
        var isRunning = false
            private set

        var activeConfig = CrosshairConfig()
            private set

        var onConfigChangedListener: ((CrosshairConfig) -> Unit)? = null

        fun updateConfig(config: CrosshairConfig, context: Context? = null) {
            activeConfig = config
            onConfigChangedListener?.invoke(config)
            if (isRunning && context != null) {
                val intent = Intent(context, OverlayService::class.java).apply {
                    action = ACTION_UPDATE_CONFIG
                }
                context.startService(intent)
            }
        }

        const val ACTION_START = "ACTION_START"
        const val ACTION_STOP = "ACTION_STOP"
        const val ACTION_UPDATE_CONFIG = "ACTION_UPDATE_CONFIG"
        const val NOTIFICATION_CHANNEL_ID = "nexus_tools_channel"
        const val NOTIFICATION_ID = 1001
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_UPDATE_CONFIG -> {
                crosshairParams?.let { params ->
                    params.x = activeConfig.offsetX.toInt()
                    params.y = activeConfig.offsetY.toInt()
                    if (activeConfig.isLocked) {
                        params.flags = params.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    } else {
                        params.flags = params.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
                    }
                    try {
                        crosshairView?.let { windowManager?.updateViewLayout(it, params) }
                    } catch (_: Exception) {}
                }
                crosshairView?.invalidate()
                updateQuickHudVisibility()
            }
            else -> {
                startForeground(NOTIFICATION_ID, buildNotification())
                isRunning = true
                showOverlayViews()
            }
        }
        return START_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                "Nexus Tools Overlay",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Status overlay game Free Fire & crosshair aktif"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java)
        val pendingOpenApp = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, OverlayService::class.java).apply {
            action = ACTION_STOP
        }
        val pendingStop = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setContentTitle("Nexus Tools Gaming Overlay Aktif")
            .setContentText("Crosshair & Menu Engineer berjalan di atas Free Fire")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(pendingOpenApp)
            .addAction(android.R.drawable.ic_delete, "Matikan Overlay", pendingStop)
            .setOngoing(true)
            .build()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun showOverlayViews() {
        if (!Settings.canDrawOverlays(this)) return

        removeOverlayViews()

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        // 1. Crosshair View
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (activeConfig.isLocked) {
            flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }

        val crosshairParams = WindowManager.LayoutParams(
            260,
            260,
            layoutType,
            flags,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
            x = activeConfig.offsetX.toInt()
            y = activeConfig.offsetY.toInt()
        }
        this.crosshairParams = crosshairParams

        val nativeCrosshair = object : View(this) {
            private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
            }
            private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.FILL
            }

            override fun onDraw(canvas: Canvas) {
                super.onDraw(canvas)
                val cX = width / 2f
                val cY = height / 2f
                val colorInt = activeConfig.colorHex.toInt()
                val alphaInt = (activeConfig.alpha * 255).toInt().coerceIn(0, 255)

                paint.color = colorInt
                paint.alpha = alphaInt
                paint.strokeWidth = activeConfig.thickness
                fillPaint.color = colorInt
                fillPaint.alpha = alphaInt

                canvas.save()
                canvas.rotate(activeConfig.rotation, cX, cY)

                val size = activeConfig.size
                val gap = activeConfig.gap

                // Center dot
                if (activeConfig.hasCenterDot) {
                    canvas.drawCircle(cX, cY, activeConfig.centerDotSize, fillPaint)
                }

                // Outer ring
                if (activeConfig.hasOuterRing) {
                    canvas.drawCircle(cX, cY, activeConfig.ringRadius, paint)
                }

                when (activeConfig.style) {
                    CrosshairStyle.DOT -> {
                        canvas.drawCircle(cX, cY, size * 0.35f, fillPaint)
                    }
                    CrosshairStyle.CLASSIC_CROSS -> {
                        canvas.drawLine(cX - size, cY, cX + size, cY, paint)
                        canvas.drawLine(cX, cY - size, cX, cY + size, paint)
                    }
                    CrosshairStyle.GAP_CROSS, CrosshairStyle.T_SHAPE -> {
                        canvas.drawLine(cX - gap - size, cY, cX - gap, cY, paint)
                        canvas.drawLine(cX + gap, cY, cX + gap + size, cY, paint)
                        canvas.drawLine(cX, cY + gap, cX, cY + gap + size, paint)
                        if (activeConfig.style != CrosshairStyle.T_SHAPE) {
                            canvas.drawLine(cX, cY - gap - size, cX, cY - gap, paint)
                        }
                    }
                    CrosshairStyle.CIRCLE_DOT -> {
                        canvas.drawCircle(cX, cY, size * 0.7f, paint)
                        canvas.drawCircle(cX, cY, 3f, fillPaint)
                    }
                    CrosshairStyle.SHOTGUN_RING -> {
                        canvas.drawCircle(cX, cY, size, paint)
                        canvas.drawCircle(cX, cY, size * 0.45f, paint)
                        canvas.drawCircle(cX, cY, 3f, fillPaint)
                    }
                    CrosshairStyle.CHEVRON_SNIPER -> {
                        val path = Path().apply {
                            moveTo(cX - size * 0.7f, cY + size * 0.4f)
                            lineTo(cX, cY - size * 0.5f)
                            lineTo(cX + size * 0.7f, cY + size * 0.4f)
                        }
                        canvas.drawPath(path, paint)
                    }
                    CrosshairStyle.TRIANGLE_AIM -> {
                        val path = Path().apply {
                            moveTo(cX, cY - size)
                            lineTo(cX + size * 0.866f, cY + size * 0.5f)
                            lineTo(cX - size * 0.866f, cY + size * 0.5f)
                            close()
                        }
                        canvas.drawPath(path, paint)
                    }
                    CrosshairStyle.HOLLOW_DIAMOND -> {
                        val path = Path().apply {
                            moveTo(cX, cY - size)
                            lineTo(cX + size, cY)
                            lineTo(cX, cY + size)
                            lineTo(cX - size, cY)
                            close()
                        }
                        canvas.drawPath(path, paint)
                    }
                    else -> {
                        canvas.drawLine(cX - size, cY, cX + size, cY, paint)
                        canvas.drawLine(cX, cY - size, cX, cY + size, paint)
                    }
                }

                canvas.restore()
            }
        }

        // Gesture: Tap 3x on crosshair to open Quick Setting Mode!
        var tapCount = 0
        var lastTapTime = 0L
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f

        nativeCrosshair.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = crosshairParams.x
                    initialY = crosshairParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY

                    val now = System.currentTimeMillis()
                    if (now - lastTapTime < 500) {
                        tapCount++
                    } else {
                        tapCount = 1
                    }
                    lastTapTime = now

                    if (tapCount >= 3) {
                        tapCount = 0
                        triggerHapticFeedback()
                        // Toggle quick setting mode!
                        val nextMode = !activeConfig.quickSettingMode
                        activeConfig = activeConfig.copy(quickSettingMode = nextMode)
                        updateQuickHudVisibility()
                        onConfigChangedListener?.invoke(activeConfig)
                    }
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!activeConfig.isLocked && !activeConfig.quickSettingMode) {
                        crosshairParams.x = initialX + (event.rawX - initialTouchX).toInt()
                        crosshairParams.y = initialY + (event.rawY - initialTouchY).toInt()
                        windowManager?.updateViewLayout(nativeCrosshair, crosshairParams)
                        activeConfig = activeConfig.copy(
                            offsetX = crosshairParams.x.toFloat(),
                            offsetY = crosshairParams.y.toFloat()
                        )
                        onConfigChangedListener?.invoke(activeConfig)
                    }
                    true
                }
                else -> false
            }
        }

        crosshairView = nativeCrosshair
        try {
            windowManager?.addView(nativeCrosshair, crosshairParams)
        } catch (_: Exception) {}

        // 2. Floating Quick HUD (Opens on 3x tap!)
        createQuickHudView(layoutType, crosshairParams)

        // 3. Floating Nexus Bubble Menu Button
        createFloatingBubble(layoutType)
    }

    @SuppressLint("SetTextI18n")
    private fun createQuickHudView(layoutType: Int, anchorParams: WindowManager.LayoutParams) {
        val hudParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
            x = anchorParams.x
            y = anchorParams.y + 200 // Positioned right beneath the crosshair
        }

        val hudLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 16, 24, 16)
            setBackgroundColor(0xEE111722.toInt())
            visibility = if (activeConfig.quickSettingMode) View.VISIBLE else View.GONE
        }

        val title = TextView(this).apply {
            text = "⚡ QUICK CROSSHAIR HUD (Tap 3x Active)"
            setTextColor(0xFF00F0FF.toInt())
            textSize = 11f
        }
        hudLayout.addView(title)

        // Quick Size Slider
        val sizeLabel = TextView(this).apply {
            text = "Ukuran: ${activeConfig.size.toInt()}px"
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 10f
        }
        hudLayout.addView(sizeLabel)

        val sizeBar = SeekBar(this).apply {
            max = 80
            progress = (activeConfig.size - 10).toInt().coerceIn(0, 80)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val newSize = 10f + progress
                    sizeLabel.text = "Ukuran: ${newSize.toInt()}px"
                    activeConfig = activeConfig.copy(size = newSize)
                    crosshairView?.invalidate()
                    onConfigChangedListener?.invoke(activeConfig)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        hudLayout.addView(sizeBar)

        // Quick Style Buttons Row
        val buttonRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 8, 0, 0)
        }

        val nextStyleBtn = TextView(this).apply {
            text = "Style: ${activeConfig.style.displayName}"
            setTextColor(0xFF00E676.toInt())
            textSize = 11f
            setPadding(12, 8, 12, 8)
            setBackgroundColor(0xFF1E293B.toInt())
            setOnClickListener {
                val styles = CrosshairStyle.values()
                val nextIdx = (activeConfig.style.ordinal + 1) % styles.size
                val nextStyle = styles[nextIdx]
                text = "Style: ${nextStyle.displayName}"
                activeConfig = activeConfig.copy(style = nextStyle)
                crosshairView?.invalidate()
                onConfigChangedListener?.invoke(activeConfig)
            }
        }
        buttonRow.addView(nextStyleBtn)

        val closeBtn = TextView(this).apply {
            text = "TUTUP (✕)"
            setTextColor(0xFFFF2A5F.toInt())
            textSize = 11f
            setPadding(16, 8, 16, 8)
            setBackgroundColor(0xFF1E293B.toInt())
            setOnClickListener {
                activeConfig = activeConfig.copy(quickSettingMode = false)
                updateQuickHudVisibility()
                onConfigChangedListener?.invoke(activeConfig)
            }
        }
        buttonRow.addView(closeBtn)

        hudLayout.addView(buttonRow)

        quickHudView = hudLayout
        try {
            windowManager?.addView(hudLayout, hudParams)
        } catch (_: Exception) {}
    }

    private fun updateQuickHudVisibility() {
        quickHudView?.visibility = if (activeConfig.quickSettingMode) View.VISIBLE else View.GONE
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createFloatingBubble(layoutType: Int) {
        val bubbleParams = WindowManager.LayoutParams(
            140,
            140,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 20
            y = 300
        }

        val bubbleLayout = FrameLayout(this).apply {
            setBackgroundColor(0xCC0A0D14.toInt())
            setPadding(10, 10, 10, 10)
        }

        val icon = ImageView(this).apply {
            setImageResource(android.R.drawable.ic_menu_compass)
            setColorFilter(0xFF00F0FF.toInt())
        }
        bubbleLayout.addView(icon)

        var bInitialX = 0
        var bInitialY = 0
        var bTouchX = 0f
        var bTouchY = 0f
        var isClick = true

        bubbleLayout.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    bInitialX = bubbleParams.x
                    bInitialY = bubbleParams.y
                    bTouchX = event.rawX
                    bTouchY = event.rawY
                    isClick = true
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val diffX = (event.rawX - bTouchX).toInt()
                    val diffY = (event.rawY - bTouchY).toInt()
                    if (Math.abs(diffX) > 10 || Math.abs(diffY) > 10) {
                        isClick = false
                    }
                    bubbleParams.x = bInitialX + diffX
                    bubbleParams.y = bInitialY + diffY
                    windowManager?.updateViewLayout(bubbleLayout, bubbleParams)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (isClick) {
                        // Open main app
                        val intent = Intent(this@OverlayService, MainActivity::class.java).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                        }
                        startActivity(intent)
                    }
                    true
                }
                else -> false
            }
        }

        floatingBubbleView = bubbleLayout
        try {
            windowManager?.addView(bubbleLayout, bubbleParams)
        } catch (_: Exception) {}
    }

    private fun triggerHapticFeedback() {
        try {
            val vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(50, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(50)
            }
        } catch (_: Exception) {}
    }

    private fun removeOverlayViews() {
        try {
            crosshairView?.let { windowManager?.removeView(it) }
            quickHudView?.let { windowManager?.removeView(it) }
            floatingBubbleView?.let { windowManager?.removeView(it) }
        } catch (_: Exception) {}
        crosshairView = null
        quickHudView = null
        floatingBubbleView = null
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        removeOverlayViews()
    }
}
