import 'package:flutter/material.dart';

enum CrosshairStyle {
  dot,
  classicCross,
  gapCross,
  shotgunRing,
  chevronSniper,
  predatorAim,
  cyberQuad,
}

class CrosshairConfig {
  CrosshairStyle style;
  Color color;
  double size;
  double thickness;
  double gap;
  double opacity;
  bool isLocked;

  CrosshairConfig({
    this.style = CrosshairStyle.gapCross,
    this.color = const Color(0xFF00E5FF),
    this.size = 28.0,
    this.thickness = 2.0,
    this.gap = 6.0,
    this.opacity = 1.0,
    this.isLocked = false,
  });

  Map<String, dynamic> toJson() => {
    'style': style.name,
    'color': color.value,
    'size': size,
    'thickness': thickness,
    'gap': gap,
    'opacity': opacity,
    'isLocked': isLocked,
  };

  factory CrosshairConfig.fromJson(Map<String, dynamic> json) => CrosshairConfig(
    style: CrosshairStyle.values.firstWhere(
      (e) => e.name == json['style'],
      orElse: () => CrosshairStyle.gapCross,
    ),
    color: Color(json['color'] ?? 0xFF00E5FF),
    size: (json['size'] as num?)?.toDouble() ?? 28.0,
    thickness: (json['thickness'] as num?)?.toDouble() ?? 2.0,
    gap: (json['gap'] as num?)?.toDouble() ?? 6.0,
    opacity: (json['opacity'] as num?)?.toDouble() ?? 1.0,
    isLocked: json['isLocked'] ?? false,
  );
}
