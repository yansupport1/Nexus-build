package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Nexus Modern Cyber Gaming Palette
val CyberCyan = Color(0xFF00F0FF)
val CyberCyanDim = Color(0xFF00A3B0)
val CyberRed = Color(0xFFFF2A5F)
val CyberRedGlow = Color(0xFFFF4B7A)
val TacticalAmber = Color(0xFFFFB800)
val NeonGreen = Color(0xFF00E676)
val ToxicPurple = Color(0xFF9D4EDD)

// Backgrounds & Surface (Matte Obsidian)
val CarbonDark = Color(0xFF0A0D14)
val SurfaceDark = Color(0xFF111722)
val SurfaceElevated = Color(0xFF172030)
val SurfaceBorder = Color(0xFF223147)
val SurfaceBorderActive = Color(0xFF00F0FF)

// Text
val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// Accent Colors for Crosshair
val CrosshairCyan = Color(0xFF00F0FF)
val CrosshairRed = Color(0xFFFF1744)
val CrosshairGreen = Color(0xFF00E676)
val CrosshairYellow = Color(0xFFFFEA00)
val CrosshairWhite = Color(0xFFFFFFFF)
val CrosshairPurple = Color(0xFFD500F9)
val CrosshairOrange = Color(0xFFFF6D00)
val CrosshairBlack = Color(0xFF000000)
