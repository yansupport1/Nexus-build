import 'package:flutter/material.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';

class TrueOverlayScreen extends StatefulWidget {
  const TrueOverlayScreen({Key? key}) : super(key: key);

  @override
  State<TrueOverlayScreen> createState() => _TrueOverlayScreenState();
}

class _TrueOverlayScreenState extends State<TrueOverlayScreen> {
  bool _isMenuOpen = false;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: Stack(
        children: [
          // If menu is open, show full-screen gesture detector to close
          if (_isMenuOpen)
            GestureDetector(
              onTap: () {
                setState(() => _isMenuOpen = false);
                // Resize back to small floating button
                FlutterOverlayWindow.resizeOverlay(180, 180);
              },
              child: Container(
                color: Colors.transparent,
                width: double.infinity,
                height: double.infinity,
              ),
            ),
          
          // Main Floating Content
          Align(
            alignment: Alignment.topLeft,
            child: _isMenuOpen ? _buildExpandedMenu() : _buildFloatingButton(),
          ),
        ],
      ),
    );
  }

  Widget _buildFloatingButton() {
    return GestureDetector(
      onTap: () {
        setState(() => _isMenuOpen = true);
        // Expand overlay window size so the menu can be drawn
        FlutterOverlayWindow.resizeOverlay(320, 500);
      },
      child: Container(
        margin: const EdgeInsets.all(12),
        width: 48,
        height: 48,
        decoration: BoxDecoration(
          color: const Color(0xFFEF4444),
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFEF4444).withOpacity(0.5),
              blurRadius: 10,
              spreadRadius: 2,
            )
          ],
        ),
        child: const Icon(Icons.gamepad, color: Colors.white, size: 24),
      ),
    );
  }

  Widget _buildExpandedMenu() {
    return Container(
      margin: const EdgeInsets.all(12),
      width: 240,
      decoration: BoxDecoration(
        color: const Color(0xFF0E131E).withOpacity(0.95),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFEF4444).withOpacity(0.5)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: const BoxDecoration(
              border: Border(bottom: BorderSide(color: Colors.white10)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'NEXUS OVERLAY',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'monospace',
                  ),
                ),
                GestureDetector(
                  onTap: () {
                    setState(() => _isMenuOpen = false);
                    FlutterOverlayWindow.resizeOverlay(180, 180);
                  },
                  child: const Icon(Icons.close, color: Colors.white54, size: 20),
                )
              ],
            ),
          ),
          _buildMenuItem(Icons.track_changes, 'Custom Crosshair', Colors.cyanAccent),
          _buildMenuItem(Icons.touch_app, 'Makro Gloo Wall', Colors.amberAccent),
          _buildMenuItem(Icons.speed, 'RAM Booster', Colors.greenAccent),
          _buildMenuItem(Icons.network_ping, 'Network Optimizer', Colors.blueAccent),
          _buildMenuItem(Icons.battery_charging_full, 'Battery Saver', Colors.yellow),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: ElevatedButton(
              onPressed: () {
                FlutterOverlayWindow.closeOverlay();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFEF4444),
                minimumSize: const Size(double.infinity, 36),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
              ),
              child: const Text('STOP OVERLAY', style: TextStyle(color: Colors.white, fontSize: 12)),
            ),
          )
        ],
      ),
    );
  }

  Widget _buildMenuItem(IconData icon, String title, Color color) {
    return ListTile(
      leading: Icon(icon, color: color, size: 22),
      title: Text(
        title,
        style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600),
      ),
      onTap: () {
        // Feature logic here
      },
    );
  }
}
